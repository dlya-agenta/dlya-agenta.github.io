// Окно расширения: 1) вход и тариф, 2) взять со страницы (фильтр, 3·10·20·30), 3) список с галочками, 4) перенос в ДомКлик.
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[<>&"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[c]));
const SITE = 'https://dlya-agenta.github.io/';
const send = m => chrome.runtime.sendMessage(m);
let ACCT = null, SET = null, TAB = null;
const rub = v => v ? Math.round(v).toLocaleString('ru-RU') + ' ₽' : '';

// ---------- 1. Вход и тариф ----------
async function renderAcct() {
  const a = ACCT = await send({ type: 'account' });
  if (!a?.ok) {
    const login = !a || ['no_auth', 'kicked', 'expired', 'off', 'no_access', 'net'].includes(a.error);
    $('#acct').innerHTML = `<h3>${login ? '🔐&nbsp;Войдите в «Для Агента»' : '💳&nbsp;Нужна подписка'}</h3>
      <div class="muted">${esc(login ? 'Откройте сайт и войдите как обычно — через бота или по паролю. Расширение подхватит вход само.' : a.message)}</div>
      <div class="row" style="margin-top:8px">${login ? `<a class="btn main" href="${SITE}" target="_blank">Войти на сайте</a>` : `<a class="btn go" href="${esc(a.pay || SITE + 'pay.html?plan=sub')}" target="_blank">Оформить подписку</a><a class="btn" href="${SITE}#plans" target="_blank">Тарифы</a>`}</div>
      <div class="muted small" style="margin-top:6px">Пробный доступ — 3 объявления. Подписчик — 50, PRO — 150, MAX — 400 в месяц (вместе с «Рекламой» сайта).</div>`;
    return;
  }
  const lim = a.limit, full = lim != null && a.used >= lim;
  $('#acct').innerHTML = `<div class="row"><b>👤&nbsp;${esc(a.name)}</b><span class="tag">${esc(a.plan)}</span><span class="sp" style="flex:1"></span>
      <span class="small ${full ? 'bad' : 'muted'}">${lim == null ? 'без лимита' : `${a.used} из ${lim}${a.period === 'all' ? ' всего' : ' в месяц'}`}</span></div>
    ${lim != null ? `<div class="quota${full ? ' full' : ''}"><i style="width:${Math.min(100, Math.round(a.used / Math.max(1, lim) * 100))}%"></i></div>` : ''}
    ${full ? `<div class="row" style="margin-top:6px"><span class="bad small">Лимит исчерпан.</span><a class="btn go" href="${esc(a.pay)}" target="_blank">${a.trial ? 'Оформить подписку' : 'Тариф выше'}</a></div>` : ''}
    <div class="muted small" style="margin-top:4px">Квота общая с «Рекламой» на сайте.</div>`;
}

// ---------- v0.7: сообщения из сайта через мессенджеры этого браузера ----------
async function renderMsgs() {
  const r = await send({ type: 'sendState' }).catch(() => null), el = $('#msgs');
  if (!r) { el.hidden = true; return; }
  const M = [['wa', 'WhatsApp', 'https://web.whatsapp.com/'], ['tg', 'Telegram', 'https://web.telegram.org/k/'], ['max', 'MAX', 'https://web.max.ru/']], sv = r.state?.svcs || {};
  const st = k => sv[k] === 'ok' ? '<span class="ok small">✓ вход есть</span>' : sv[k] === 'auth' ? '<span class="bad small">войдите</span>' : '<span class="muted small">не открыт</span>';
  el.innerHTML = `<h3>💬&nbsp;Сообщения из сайта ${r.on ? '' : '<span class="tag">выключено</span>'}</h3>
    <div class="row" style="gap:6px;flex-wrap:wrap">${M.map(([k, t, u]) => `<a class="btn" href="${u}" target="_blank" title="Открыть ${t} Web и войти один раз">${t} ${st(k)}</a>`).join('')}</div>
    ${r.job ? `<div class="small" style="margin-top:6px">Идёт отправка: ${r.job.i} из ${r.job.n}${r.job.last && !r.job.last.ok ? ` · <span class="bad">${esc(r.job.last.error || '')}</span>` : ''}</div>` : ''}
    <div class="muted small" style="margin-top:6px">${r.state?.error === 'need_pro' ? 'Сообщения собственникам — в тарифах PRO и MAX.' : 'На сайте при отправке выберите «💻 Через мой браузер». Компьютер должен быть включён — тогда можно отправлять и с телефона.'}</div>`;
}

// ---------- 2. Взять со страницы ----------
async function getFilt() { return { ...DA.FILTER0, ...((await chrome.storage.local.get('filt')).filt || {}) }; }
async function renderTake() {
  [TAB] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = TAB?.url || '', one = DA.sourceOf(url), kind = DA.listOf(url);
  const def = +SET.batchSize || 10;
  if (one && one !== 'vt') {
    $('#take').innerHTML = `<h3><span class="n">1</span>Это объявление (${DA.SOURCES[one].name})</h3>
      <button class="btn main" id="grab" style="width:100%;justify-content:center">⇪ Взять это объявление</button><div id="gmsg" class="small" style="margin-top:6px"></div>`;
    $('#grab').onclick = async () => {
      $('#grab').disabled = true; $('#gmsg').textContent = 'Читаю страницу…';
      const r = await send({ type: 'grab' });
      $('#grab').disabled = false;
      $('#gmsg').innerHTML = r.ok ? `<span class="okc">✓ ${r.updated ? 'Обновлено' : 'Взято'}: ${esc(r.item.title)}, фото ${r.item.photos}</span>` : `<span class="bad">⚠️ ${esc(r.error)}</span>`;
      render(); renderAcct();
    };
    return;
  }
  if (kind === 'vt') {
    $('#take').innerHTML = `<h3><span class="n">1</span>💎 Перенести свои Эксклюзивы ВТОРИЧЕК</h3>
      <div class="muted small">Ваши объявления из профиля → файл для раздела «Эксклюзивы». Учитывается фильтр (ниже — при сборе со списков).</div>
      <div class="row sizes" style="margin-top:8px"><span>Сколько:</span>${[3, 10, 20, 30, 'all'].map(n => `<button class="chip${n === 3 ? ' def' : ''}" data-vt="${n}">${n === 'all' ? 'все' : n}</button>`).join('')}</div><div id="gmsg" class="small" style="margin-top:6px"></div>`;
    document.querySelectorAll('[data-vt]').forEach(b => b.onclick = async () => {
      $('#gmsg').textContent = 'Беру из профиля…';
      const r = await send({ type: 'collect', tabId: TAB.id, n: b.dataset.vt === 'all' ? 'all' : +b.dataset.vt });
      if (!r.ok) { $('#gmsg').innerHTML = `<span class="bad">⚠️ ${esc(r.error)}</span>`; return; }
      if (!r.ids?.length) { $('#gmsg').textContent = 'Подходящих нет' + (r.filtered ? ` (не подошли под фильтр: ${r.filtered})` : ''); return; }
      await send({ type: 'exclOpen', ids: r.ids }); window.close();
    });
    return;
  }
  if (!kind) {
    $('#take').innerHTML = `<h3><span class="n">1</span>Откуда брать</h3>
      <div class="muted">Откройте список — расширение возьмёт объявления прямо из него, не заходя внутрь:</div>
      <div class="row" style="margin-top:6px"><a class="btn" href="https://www.avito.ru/sochi/kvartiry/prodam-ASgBAgICAUSSA8YQ" target="_blank">Авито</a>
      <a class="btn" href="https://sochi.cian.ru/cat.php?deal_type=sale&engine_version=2&offer_type=flat&region=4998" target="_blank">Циан</a>
      <a class="btn" href="${SITE}" target="_blank">Сайт «Для Агента»</a></div>
      <div class="muted small" style="margin-top:6px">Или откройте одно объявление Авито / Циана — «⇪ Для Агента».</div>`;
    return;
  }
  const f = await getFilt(), tier = ACCT?.tier, pro = DA.proTier(tier);
  const R = ['Студия', '1', '2', '3', '4+'];
  $('#take').innerHTML = `<h3><span class="n">1</span>Взять со страницы · ${kind === 'site' ? 'сайт «Для Агента»' : kind === 'cian' ? 'Циан' : 'Авито'}</h3>
    <div class="muted small">${kind === 'avito' ? 'Из списка, без захода внутрь. Полные фото Авито — при переносе, само в фоне.' : 'Из списка, без захода внутрь.'} Уже выставленные другими — пропускаются.</div>
    ${kind === 'cian' ? '<div class="warn small" style="margin-top:4px">⚠️ С Циана в рекламу (ДомКлик) не берём — на фото логотипы. Взятые объявления можно перенести в Эксклюзивы.</div>' : ''}
    <details id="fd"><summary>Фильтр${DA.filterText(f, tier) ? ': ' + esc(DA.filterText(f, tier)) : ''}</summary>
      <div class="fl"><span>Комнаты</span><div class="chips" id="rooms">${R.map(r => `<button class="chip${f.rooms.includes(r) ? ' on' : ''}" data-r="${r}">${r}</button>`).join('')}</div>
        <span>Площадь</span><div class="row"><input type="number" id="amin" placeholder="от" value="${esc(f.areaMin)}" style="width:70px"> – <input type="number" id="amax" placeholder="до" value="${esc(f.areaMax)}" style="width:70px"> м²</div></div>
      <div class="${pro ? '' : 'locked'}">
        ${pro ? '' : `<div class="lock" style="margin-top:6px">🔒 Район, ЖК, адрес${kind === 'site' ? ', современный ремонт' : ''} — в PRO и MAX · <a href="${SITE}#plans" target="_blank">Что даёт PRO</a></div>`}
        <div class="fl"><span>Район</span><input type="text" id="fdist" placeholder="Центральный, Светлана…" value="${esc(f.district)}"${pro ? '' : ' disabled'}>
          <span>ЖК</span><input type="text" id="fzk" placeholder="Светлана Парк…" value="${esc(f.zk)}"${pro ? '' : ' disabled'}>
          <span>Адрес</span><input type="text" id="faddr" placeholder="улица, дом" value="${esc(f.addr)}"${pro ? '' : ' disabled'}></div>
        ${kind === 'site' ? `<label class="chk"><input type="checkbox" id="fmod"${f.modern ? ' checked' : ''}${pro ? '' : ' disabled'}> Только «Современный ремонт»</label>` : ''}
      </div>
      <div class="row" style="margin-top:6px"><button class="btn ghost" id="freset">Сбросить фильтр</button></div>
    </details>
    <div class="row sizes" style="margin-top:8px"><span>Взять:</span>${DA.SIZES.map(n => `<button class="chip${n === def ? ' def' : ''}" data-take="${n}">${n}</button>`).join('')}</div>
    <div id="gmsg" class="small" style="margin-top:6px"></div>`;
  const save = async () => {
    const nf = { areaMin: $('#amin').value, areaMax: $('#amax').value, rooms: [...document.querySelectorAll('#rooms .chip.on')].map(b => b.dataset.r),
      district: $('#fdist').value.trim(), zk: $('#fzk').value.trim(), addr: $('#faddr').value.trim(), modern: !!$('#fmod')?.checked };
    await chrome.storage.local.set({ filt: nf });
    $('#fd summary').textContent = 'Фильтр' + (DA.filterText(nf, tier) ? ': ' + DA.filterText(nf, tier) : '');
  };
  document.querySelectorAll('#rooms .chip').forEach(b => b.onclick = () => { b.classList.toggle('on'); save(); });
  ['#amin', '#amax', '#fdist', '#fzk', '#faddr', '#fmod'].forEach(s => { const e = $(s); if (e) e.onchange = save; });
  $('#freset').onclick = async () => { await chrome.storage.local.set({ filt: DA.FILTER0 }); renderTake(); };
  document.querySelectorAll('[data-take]').forEach(b => b.onclick = async () => {
    await save();
    document.querySelectorAll('[data-take]').forEach(x => x.disabled = true);
    $('#gmsg').textContent = 'Беру со страницы…';
    const r = await send({ type: 'collect', tabId: TAB.id, n: +b.dataset.take });
    document.querySelectorAll('[data-take]').forEach(x => x.disabled = false);
    $('#gmsg').innerHTML = r.ok
      ? `<span class="okc">✓ Взято: ${r.added}</span>${r.filtered ? ` · не подошли под фильтр: ${r.filtered}` : ''}${r.taken ? ` · уже выставили другие: ${r.taken}` : ''}${r.already ? ` · уже в списке: ${r.already}` : ''}${r.skipped ? ` · не квартиры: ${r.skipped}` : ''}${r.short ? '<br><span class="warn">Подходящих на странице меньше — откройте следующую страницу и нажмите ещё раз.</span>' : ''}`
      : `<span class="bad">⚠️ ${esc(r.error)}</span>${r.gate ? ` <a href="${esc(r.login ? SITE : r.pay)}" target="_blank">${r.login ? 'Войти' : 'Оформить подписку'}</a>` : ''}`;
    render();
  });
}

// ---------- 3. Список ----------
async function render() {
  const q = (await chrome.storage.local.get('queue')).queue || [];
  const onN = q.filter(x => x.on !== false && !x.domclick?.ok).length;
  $('#cnt').innerHTML = q.length ? `— ${q.length}, отмечено ${onN}` : '';
  if (!q.length) { $('#list').innerHTML = '<div class="muted">Пока пусто. Возьмите объявления со страницы (шаг 1).</div>'; renderBatch(q); return; }
  $('#list').innerHTML = `<div class="row" style="margin-bottom:4px"><button class="btn ghost" id="allon">☑ Отметить все</button><button class="btn ghost" id="alloff">☐ Снять все</button></div>` + q.map(it => {
    const done = it.domclick?.ok, ph = it.photos?.[0];
    return `<div class="it${it.on === false || done ? ' off' : ''}">
      <input type="checkbox" data-on="${esc(it.id)}"${it.on !== false && !done ? ' checked' : ''}${done ? ' disabled' : ''} title="Переносить">
      ${ph ? `<img src="${esc(ph)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<span class="ph"></span>'}
      <div><b>${esc(it.title || 'без названия')}</b>
        <span class="tag">${esc(DA.SOURCES[it.source]?.name || it.source)}</span>${it.light ? '<span class="tag" title="Полные фото — при переносе">из списка</span>' : ''}${DA.SOURCES[it.source]?.targets.includes('domclick') ? '' : '<span class="tag" title="Не в рекламу — только в Эксклюзивы">→ Эксклюзивы</span>'}${it.exclAt ? '<span class="tag ok">в файле</span>' : ''}${done ? `<span class="tag ok">в ДомКлике ${esc(it.domclick.draft || '')}</span>` : ''}
        <div class="muted small">${[rub(it.price), it.total ? it.total + ' м²' : '', it.photos?.length && !it.light ? 'фото ' + it.photos.length : ''].filter(Boolean).join(' · ')}</div>
        <div class="muted small">${esc(it.address?.full || '')}</div>
        ${(it.notes || []).filter(n => !/при переносе/.test(n)).map(n => `<div class="warn small">• ${esc(n)}</div>`).join('')}</div>
      <div><a class="x" href="${esc(it.url)}" target="_blank" title="Открыть объявление">↗</a><button class="x" data-del="${esc(it.id)}" title="Убрать из списка">✕</button></div></div>`;
  }).join('');
  const upd = async fn => { const q2 = (await chrome.storage.local.get('queue')).queue || []; fn(q2); await chrome.storage.local.set({ queue: q2 }); render(); };
  document.querySelectorAll('[data-on]').forEach(c => c.onchange = () => upd(q2 => { const x = q2.find(y => y.id === c.dataset.on); if (x) x.on = c.checked; }));
  document.querySelectorAll('[data-del]').forEach(b => b.onclick = () => upd(q2 => { const i = q2.findIndex(y => y.id === b.dataset.del); if (i >= 0) q2.splice(i, 1); }));
  $('#allon').onclick = () => upd(q2 => q2.forEach(x => { if (!x.domclick?.ok) x.on = true; }));
  $('#alloff').onclick = () => upd(q2 => q2.forEach(x => { x.on = false; }));
  renderBatch(q);
}

// ---------- 4. Перенос ----------
async function renderBatch(q) {
  const def = +SET.batchSize || 10;
  const { batch } = await chrome.storage.local.get('batch');
  const pend = q.filter(x => DA.SOURCES[x.source]?.targets.includes('domclick') && !x.domclick?.ok && x.on !== false);
  const needOk = pend.some(x => x.source === 'avito' || x.source === 'cian');
  const running = batch && !batch.done;
  const left = ACCT?.limit == null ? Infinity : Math.max(0, ACCT.limit - ACCT.used), none = left <= 0;
  const cianOn = q.filter(x => x.source === 'cian' && x.on !== false).length;
  let html = `<h3><span class="n">3</span>Перенос в ДомКлик <span class="muted small">отмечено ${pend.length}</span></h3>
    ${cianOn ? `<div class="warn small">⚠️ Циан (${cianOn}) в рекламу не идёт — на фото логотипы. Их — кнопкой «💎 Перенести свои Эксклюзивы ВТОРИЧЕК» внизу.</div>` : ''}`;
  if (running) {
    html += `<div>⏳ Идёт: <b>${batch.i + 1} из ${batch.ids.length}</b> · черновиков ${batch.results.filter(r => r.ok).length}</div>
      <div class="row" style="margin-top:6px"><button class="btn" id="bstop">⏹ Остановить</button><span class="muted small">вкладку ДомКлика не закрывайте</span></div>`;
  } else {
    html += `<div class="muted small">По очереди в одной вкладке, каждое — «Сохранить как черновик». «Опубликовать» нажимаете вы.</div>
      ${needOk ? '<label class="chk small"><input type="checkbox" id="consent"> Объявления Авито / Циана — мои или есть согласие владельца</label>' : ''}
      <div class="row sizes" style="margin-top:8px"><span>Перенести:</span>${DA.SIZES.map(n => `<button class="chip${n === def ? ' def' : ''}" data-batch="${n}"${pend.length && !none ? '' : ' disabled'}>${n}</button>`).join('')}</div>
      ${none ? `<div class="bad small" style="margin-top:4px">Лимит подписки исчерпан — <a href="${esc(ACCT.pay)}" target="_blank">${ACCT.trial ? 'оформить подписку' : 'тариф выше'}</a></div>` : left < Infinity ? `<div class="muted small" style="margin-top:4px">Осталось по подписке: ${left}</div>` : ''}`;
  }
  if (batch?.results?.length) {
    const bad = batch.results.filter(r => !r.ok);
    html += `<div class="small" style="margin-top:6px">${batch.done ? (batch.stop ? '⏹ Остановлен' : '✅ Последний пакет готов') : ''} · готово ${batch.results.filter(r => r.ok).length}${bad.length ? `, проверить ${bad.length}` : ''}</div>
      ${bad.map(r => `<div class="${r.taken ? 'muted' : 'warn'} small">• ${esc((q.find(x => x.id === r.id) || {}).title || r.id)}: ${esc(r.taken ? 'уже выставил другой пользователь — взято следующее' : r.error || (r.problems || []).join(', ') || 'проверьте')}${r.draft ? ` (черновик ${esc(r.draft)})` : ''}</div>`).join('')}`;
  }
  $('#batch').innerHTML = html;
  document.querySelectorAll('[data-batch]').forEach(b => b.onclick = async () => {
    if ($('#consent') && !$('#consent').checked) { $('#consent').parentElement.classList.add('bad'); return; }
    const r = await send({ type: 'batchStart', n: +b.dataset.batch });
    if (!r.ok) { alert(r.error); renderAcct(); } else window.close();
  });
  const st = $('#bstop'); if (st) st.onclick = async () => { await send({ type: 'batchStop' }); render(); };
}

$('#excl').onclick = async () => {
  const r = await send({ type: 'exclOpen' });
  if (!r.ok) alert(r.error); else window.close();
};
$('#clear').onclick = async () => { if (confirm('Убрать все объявления из списка расширения? На площадках ничего не удаляется.')) { await chrome.storage.local.set({ queue: [] }); render(); } };
chrome.storage.onChanged.addListener(ch => { if (ch.batch || ch.queue) render(); if (ch.acct) renderAcct(); if (ch.sendState || ch.sendJob) renderMsgs(); });

(async () => {
  SET = await DA.getSettings(); await renderAcct(); renderMsgs();
  const on = !!ACCT?.ok;   // без входа и подписки — только вход / оплата
  ['#take', '#listc', '#batch'].forEach(s => { $(s).hidden = !on; }); document.querySelector('.foot').hidden = !on;
  if (on) { renderTake(); render(); }
})();
