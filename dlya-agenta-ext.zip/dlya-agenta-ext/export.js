// Сборка файла «Эксклюзивов»: поля — под фильтр сайта (тип, комнаты, район из 6, отделка), фото — JPEG до 490 КБ, до 15 на объект.
(async () => {
  const $ = s => document.querySelector(s), esc = s => String(s ?? '').replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
  const { exclIds = [], queue = [] } = await chrome.storage.local.get(['exclIds', 'queue']);
  const s = await DA.getSettings();
  const items = queue.filter(x => exclIds.includes(x.id));
  if (!items.length) { $('#st').textContent = 'Нет объявлений для переноса.'; return; }
  $('#list').innerHTML = items.map(x => `<div>• ${esc(x.title)} — ${x.price ? x.price.toLocaleString('ru-RU') + ' ₽' : ''} · фото ${Math.min(15, x.photos.length)}</div>`).join('');
  const getBlob = async u => { for (let t = 0; t < 3; t++) { try { const r = await fetch(u, { credentials: 'omit' }); if (r.ok) return await r.blob(); } catch (e) {} await new Promise(r => setTimeout(r, 700)); } return null; };
  const file = await DA.buildExcl(items, getBlob, s.cropBottom !== false, (i, n) => { $('#st').textContent = `Готовлю ${i} из ${n}…`; $('#pb').style.width = Math.round(i / n * 100) + '%'; });
  const blob = new Blob([JSON.stringify(file)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = `eksklyuzivy-vtorichek-${new Date().toISOString().slice(0, 10)}-${file.count}.json`; document.body.appendChild(a); a.click();
  const ph = file.items.reduce((k, x) => k + x.photos.length, 0);
  $('#st').innerHTML = `<b class="okc">✓ Файл скачан</b>: объектов ${file.count}, фото ${ph}, ${(blob.size / 1048576).toFixed(1)} МБ.`;
  $('#done').innerHTML = 'Загрузите его в разделе «💎 Эксклюзивы» → «⬆ Загрузить файл». Объекты появятся черновиками — проверьте и опубликуйте.';
  const q2 = (await chrome.storage.local.get('queue')).queue || [];
  q2.forEach(x => { if (exclIds.includes(x.id)) x.exclAt = new Date().toISOString(); });
  await chrome.storage.local.set({ queue: q2 });
})();
