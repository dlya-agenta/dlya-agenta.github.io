// Shared protocol-2 state machine. Keep the extension copy byte-identical.
(() => {
  if (globalThis.DA_DISPATCH_FLOW) return;
  const flights = new Map(), durable = new Map();
  const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
  const FINAL = new Set(['sent', 'failed', 'unknown']);
  function evidence(result) {
    const parts = {};
    for (const name of ['photo', 'text']) {
      const part = result?.parts?.[name];
      if (!part || !['observed', 'unknown', 'not_sent'].includes(part.state)) continue;
      const valid = typeof part.message_key === 'string' && part.message_key.trim() && part.message_key.length <= 300;
      parts[name] = {state: part.state === 'observed' && !valid ? 'unknown' : part.state, ...(part.state === 'observed' && valid ? {message_key: part.message_key.trim()} : {})};
    }
    return {...(Object.keys(parts).length ? {parts} : {}), ...(typeof result?.warn === 'string' && result.warn.trim() ? {warning: result.warn.replace(/\u0000/g, '').trim().slice(0, 900)} : {})};
  }
  const unknown = meta => ({outcome: 'unknown', proof: {kind: 'unconfirmed', ...meta}});
  function outcome(result) {
    const meta = evidence(result), observed = Object.values(meta.parts || {}).some(p => p.state === 'observed');
    if (result?.unknown === true || Object.values(meta.parts || {}).some(p => p.state === 'unknown')) return unknown(meta);
    if (result?.defer === true) return observed ? unknown(meta) : {outcome: 'deferred', proof: {kind: 'not_sent', code: 'PRECHECK', ...meta}};
    const p = result?.proof;
    if (result?.unknown !== true && result?.ok === true && p && ['chat_observed', 'provider_ack'].includes(p.kind) && typeof p.message_key === 'string' && p.message_key.trim() && p.message_key.length <= 300 && (p.kind !== 'provider_ack' || typeof p.ack === 'number' && Number.isFinite(p.ack) && p.ack >= 1)) {
      const proof = {kind: p.kind, message_key: p.message_key.trim()};
      if (p.kind === 'provider_ack') proof.ack = p.ack;
      if (['text', 'photo', 'photo_and_text'].includes(p.media)) proof.media = p.media;
      if (typeof p.observed_at === 'string' && Number.isFinite(Date.parse(p.observed_at))) proof.observed_at = new Date(p.observed_at).toISOString();
      return {outcome: 'sent', proof: {...proof, ...meta}};
    }
    if (!observed && result?.unknown !== true && result?.ok === false && p?.kind === 'not_sent' && ['AUTH', 'NOUSER', 'INVALID', 'PRECHECK'].includes(p.code)) return {outcome: 'failed', proof: {kind: 'not_sent', code: p.code, ...meta}};
    return unknown(meta);
  }
  async function runOnce({key, snapshot, persist, begin, send, finish}) {
    snapshot = durable.get(key) || snapshot;
    if (typeof key !== 'string' || !key) throw new Error('Missing dispatch identity');
    let s = snapshot ? structuredClone(snapshot) : {key, phase: 'claiming', attempt: crypto.randomUUID()};
    if (s.key !== key || !UUID.test(s.attempt || '') || !['claiming', 'dispatching', 'ack', 'done', 'ready'].includes(s.phase)) throw new Error('Dispatch snapshot does not belong to this item');
    const save = async next => {await persist(structuredClone(next)); s = next; if (next.phase === 'done') durable.delete(key); else durable.set(key, structuredClone(next));};
    if (!snapshot) await save(s);
    if (s.phase === 'done') {
      if (!FINAL.has(s.receipt?.state)) throw new Error('Invalid saved dispatch receipt');
      return s.receipt;
    }
    if (s.phase === 'ready') await save({key, phase: 'claiming', attempt: crypto.randomUUID()});
    if (s.phase === 'claiming') {
      const permit = await begin(s.attempt);
      if (permit?.state !== 'claimed') {
        const receipt = {state: permit?.state || 'unknown'};
        if (FINAL.has(receipt.state)) await save({key, phase: 'done', attempt: s.attempt, receipt});
        return receipt;
      }
      // Failure before this durable transition cannot have sent a message.
      await save({key, phase: 'dispatching', attempt: s.attempt});
      let result;
      try {result = outcome(await send());} catch {result = unknown();}
      // A lost finish response must retry this receipt, never the external action.
      await save({...s, phase: 'ack', result});
    } else if (s.phase === 'dispatching') {
      // Restarted after permission: absence in incomplete chat history is not proof.
      await save({...s, phase: 'ack', result: unknown()});
    }
    if (s.phase !== 'ack' || !['sent', 'failed', 'unknown', 'deferred'].includes(s.result?.outcome)) throw new Error('Invalid dispatch acknowledgement');
    const received = await finish(s.attempt, s.result), receipt = {state: received?.state || 'unknown'};
    if (receipt.state === 'ready') await save({key, phase: 'ready', attempt: s.attempt, receipt});
    else if (FINAL.has(receipt.state)) await save({key, phase: 'done', attempt: s.attempt, receipt});
    return receipt;
  }
  function run(options) {
    const key = options?.key, s = options?.snapshot;
    if (typeof key !== 'string' || !key || s && (s.key !== key || !UUID.test(s.attempt || '') || !['claiming', 'dispatching', 'ack', 'done', 'ready'].includes(s.phase))) return Promise.reject(new Error('Invalid dispatch snapshot identity'));
    if (flights.has(key)) return flights.get(key);
    const task = Promise.resolve().then(() => runOnce(options));
    flights.set(key, task);
    const clear = () => {if (flights.get(key) === task) flights.delete(key);};
    task.then(clear, clear);
    return task;
  }
  globalThis.DA_DISPATCH_FLOW = {run, outcome};
})();
