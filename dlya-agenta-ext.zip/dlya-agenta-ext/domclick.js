// Вкладка ДомКлика: заполняет форму «Продать квартиру» из взятого объявления.
// Порт проверенного fill.js (~/avito-domclick). «Опубликовать» не нажимает никогда.
(() => {
  const sleep = ms => new Promise(s => setTimeout(s, ms));
  const vis = e => !!(e && (e.offsetWidth || e.offsetHeight || e.getClientRects().length));
  const byText = (txt, sel = 'button,[role=option],[role=button],label,a,div,span') =>
    [...document.querySelectorAll(sel)].filter(e => vis(e) && !(panel && panel.contains(e)) && e.innerText && e.innerText.trim() === txt);
  const FORBID = /опубликов|разместить|удалить|продвин|оплат|подключить/i;
  const press = e => {
    if (FORBID.test(e.innerText || '')) throw new Error('защита: не нажимаю «' + e.innerText.trim() + '»');
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t =>
      e.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
  };
  const el = k => document.querySelector(`[data-k="${k}"]`);
  const setNative = (e, v) => {
    const proto = e.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(e, String(v));
    e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const setText = async (k, v) => { const e = el(k); if (!e) return false; e.focus(); setNative(e, v);
    e.blur(); e.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); await sleep(1500); return e.value; };
  const tick = async k => { const e = el(k); if (!e) return false; if (!e.checked) (e.closest('label') || e).click(); await sleep(1500); return e.checked; };
  const esc = s => String(s ?? '').replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));

  // ---------- Панель ----------
  let panel, logEl, extraEl;
  function ui(it) {
    if (panel) return;
    panel = document.createElement('div'); panel.dataset.da = '1';
    panel.style.cssText = 'position:fixed;right:16px;bottom:16px;width:340px;max-height:70vh;overflow:auto;z-index:2147483647;background:#fff;color:#121722;border:0;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.2);font:13px/1.4 -apple-system,Segoe UI,Roboto,sans-serif';
    panel.innerHTML = `<div style="background:#0f1b2d;color:#fff;padding:9px 12px;border-radius:14px 14px 0 0;display:flex;justify-content:space-between;font-family:Prata,Georgia,serif">
      <b data-min style="cursor:pointer" title="Свернуть / развернуть">Для Агента → ДомКлик ▾</b><a href="#" data-x style="color:#fff;text-decoration:none">✕</a></div>
      <div style="padding:8px 12px"><b>${esc(it.title)}</b><div style="color:#666">${esc(it.address?.full)}</div>
      <div data-extra></div><div data-log style="margin-top:6px;white-space:pre-wrap"></div></div>`;
    document.body.appendChild(panel);
    logEl = panel.querySelector('[data-log]'); extraEl = panel.querySelector('[data-extra]');
    // свернуть до строки заголовка — панель не закрывает форму ДомКлика
    panel.querySelector('[data-min]').onclick = () => { const b = panel.children[1]; const hide = b.style.display !== 'none'; b.style.display = hide ? 'none' : ''; panel.style.width = hide ? '230px' : '340px'; };
    panel.querySelector('[data-x]').onclick = async ev => { ev.preventDefault(); stopped = true;
      const { job } = await chrome.storage.local.get('job');
      if (job?.batch) await chrome.runtime.sendMessage({ type: 'batchStop' }); else await chrome.storage.local.remove('job');
      panel.remove(); panel = null; };
  }
  const log = (t, color) => { if (!logEl) return; const d = document.createElement('div'); d.textContent = t; if (color) d.style.color = color; logEl.appendChild(d); panel.scrollTop = 1e6; };
  let stopped = false;
  let lastErr = '';
  const stop = msg => { lastErr = msg; log('⛔ ' + msg, '#c00'); return false; };

  // ---------- Шаги ----------
  // Нажать кнопку с текстом и дождаться результата. Страница может быть видна, но ещё не «ожить» (React) —
  // поэтому повторяем, пробуя разные элементы (сам текст, его карточку) и обычный click().
  async function clickUntil(txt, done, tries = 6) {
    for (let t = 0; t < tries; t++) {
      const c = byText(txt);
      if (!c.length) { await sleep(700); continue; }
      const order = [...c].sort((a, b) => b.querySelectorAll('*').length - a.querySelectorAll('*').length); // карточка, потом текст
      const e = order[t % order.length];
      const target = e.closest('button,[role=button],a,label') || e;
      press(target); if (t % 2) target.click();
      for (let w = 0; w < 6; w++) { await sleep(400); if (done()) return true; }
    }
    return done();
  }

  async function stepStart() {
    for (let t = 0; t < 30 && !byText('Продать').length; t++) await sleep(500);
    if (/необычно|подозрительн/i.test(document.body.innerText)) return stop('ДомКлик показал проверку — пройдите её сами и нажмите «→ ДомКлик» ещё раз.');
    if (!byText('Продать').length) return stop('Не нашёл кнопку «Продать». Вы вошли в ДомКлик?');
    await sleep(2500); // дать странице «ожить»
    const flatShown = () => byText('Квартира').length > 0;
    if (!(await clickUntil('Продать', flatShown))) {
      log('Не получилось нажать «Продать». Нажмите его сами — дальше продолжу.', '#b25a00');
      if (!(await waitManual(flatShown))) return stop('Не дождался выбора «Квартира».');
    }
    const addrShown = () => [...document.querySelectorAll('input')].some(e => vis(e) && /адрес/i.test(e.placeholder || ''));
    if (!(await clickUntil('Квартира', addrShown))) {
      log('Не получилось нажать «Квартира». Нажмите её сами — дальше продолжу.', '#b25a00');
      if (!(await waitManual(addrShown))) return stop('Не дождался поля адреса.');
    }
    const ns = byText('Не сейчас')[0]; if (ns) { press(ns); await sleep(800); }
    log('✓ Продать → Квартира');
    return true;
  }
  // Человек нажал сам — ждём до 2 минут и продолжаем
  async function waitManual(cond) {
    for (let t = 0; t < 240; t++) { if (stopped) return false; if (cond()) { log('✓ Продолжаю'); return true; } await sleep(500); }
    return false;
  }

  async function stepAddress(it) {
    const a = it.address || {};
    const inp = [...document.querySelectorAll('input')].find(e => /адрес/i.test(e.placeholder || ''));
    if (!inp) return stop('Не нашёл поле адреса.');
    const norm = s => String(s || '').toLowerCase().replace(/ё/g, 'е');
    // дом: без пробелов и точек, «корпус/корп.» = «к», «строение/стр.» = «с», «литер» = «лит»
    const nH = v => norm(v).replace(/^\s*(д|дом)\.?\s*/, '').replace(/корпус|корп\.?/g, 'к').replace(/строение|стр\.?/g, 'с').replace(/литера?|лит\.?/g, 'лит').replace(/[\s.]+/g, '');
    const H = a.house ? nH(a.house) : '';
    const base = h => (h.match(/^\d+[а-я]?(?=к|с|лит|\/|$)/) || h.match(/^\d+/) || [''])[0];
    const HB = base(H);
    // тип улицы из адреса объявления: «пер.» → переулок и т.п. (у ДомКлика — полными словами)
    const TYPES = [[/(^|\s)(ул\.?|улица)(\s|$)/, 'улиц'], [/(^|\s)(пер\.?|переулок)(\s|$)/, 'переул'], [/(^|\s)(пр-т|просп\.?|проспект)(\s|$)/, 'проспект'],
      [/(^|\s)(б-р|бульвар)(\s|$)/, 'бульвар'], [/(^|\s)(наб\.?|набережная)(\s|$)/, 'набережн'], [/(^|\s)(ш\.?|шоссе)(\s|$)/, 'шоссе'], [/(^|\s)проезд(\s|$)/, 'проезд'],
      [/(^|\s)тупик(\s|$)/, 'тупик'], [/(^|\s)(пл\.?|площадь)(\s|$)/, 'площад'], [/(^|\s)(мкр\.?|микрорайон)(\s|$)/, 'микрорайон']];
    const st = norm(a.street);
    const myType = (TYPES.find(([re]) => re.test(st)) || [])[1] || '';
    const distWords = norm(a.full).split(',').filter(x => /мкр|р-н|район|микрорайон|жилой/.test(x)).flatMap(x => x.split(/\s+/)).filter(w => w.length > 3 && !/мкр|район|микрорайон|жилой/.test(w));
    const SW = a.streetWords || [];
    // очки подсказки: улица (все слова), тип улицы, дом (точно / тот же номер), район
    const score = el => {
      const t = norm(el.innerText.replace(/\n/g, ', ')), segs = t.split(',').map(x => x.trim());
      const sw = SW.length ? SW.filter(w => t.includes(w)).length / SW.length : 0;
      let sc = sw === 1 ? 10 : sw * 6;
      if (myType) { if (t.includes(myType)) sc += 3; else if (TYPES.some(([, k]) => k !== myType && segs.some(x => x.includes(k)))) sc -= 3; }
      const hs = segs.map(nH).filter(x => /^\d/.test(x));
      let house = 'none';
      if (H && hs.includes(H)) { sc += 20; house = 'exact'; }
      else if (HB && hs.some(x => base(x) === HB)) { sc += 8; house = 'base'; }
      else if (H && hs.length) sc -= 5;
      for (const w of distWords) if (t.includes(w)) sc += 2;
      if (/сочи/.test(t)) sc += 1;
      return { el, sc, house, streetOk: sw === 1, text: el.innerText.trim().replace(/\n/g, ', ') };
    };
    // Подсказки ДомКлика — div без ролей и с зашифрованными классами (12.11). Ищем строки высотой до 90 px прямо под полем.
    const options = () => {
      const ir = inp.getBoundingClientRect();
      let c = [...document.querySelectorAll('body *')].filter(e => {
        if (!vis(e) || e.contains(inp) || panel.contains(e)) return false;
        const r = e.getBoundingClientRect(), t = e.innerText || '';
        return r.top >= ir.bottom - 4 && r.top < ir.bottom + 450 && r.height > 0 && r.height < 90 && r.left < ir.right && r.right > ir.left
          && /,/.test(t) && /Сочи|край|область|район|округ/.test(t);
      });
      return c.filter(e => !c.some(o => o !== e && o.contains(e)));
    };
    const typeIn = async q => {
      inp.focus(); inp.click(); inp.select(); document.execCommand('delete'); await sleep(250);
      document.execCommand('insertText', false, q);
      if (inp.value !== q) setNative(inp, q);
      let o = []; for (let t = 0; t < 10 && !o.length; t++) { await sleep(450); o = options(); }
      await sleep(600); return options();
    };
    // запросы: как в объявлении → без типа улицы → корпус через пробел
    const houseSp = String(a.house || '').replace(/(\d[а-яa-zА-ЯA-Z]?)\s*(?:к|корп\.?|корпус)\s*(\d+)/i, '$1 к$2');
    const queries = [...new Set([a.query, ['Сочи', SW.join(' '), a.house].filter(Boolean).join(', '), ['Сочи', a.street, houseSp].filter(Boolean).join(', ')])].filter(Boolean);
    let best = null;
    for (const q of queries) {
      const sc = (await typeIn(q)).map(score).sort((x, y) => y.sc - x.sc);
      // ничья по дому без точного совпадения (6 → «6 к1» и «6 к9») — угадывать нельзя
      const tie = sc.length > 1 && sc[1].sc === sc[0].sc && sc[0].house !== 'exact';
      if (sc[0] && (!best || sc[0].sc > best.sc)) best = { ...sc[0], q, tie };
      if (best?.house === 'exact' && best.streetOk) break;
    }
    const good = best && best.streetOk && !best.tie && (best.house === 'exact' || best.house === 'base' || !H);
    if (good) {
      if (inp.value !== best.q) { await typeIn(best.q); const again = options().map(score).sort((x, y) => y.sc - x.sc)[0]; if (again) best = { ...again, q: best.q }; }
      // onClick у ДомКлика висит на самом внутреннем div подсказки (12.11) — наводим мышь и кликаем по нему
      let t = best.el; while (t.firstElementChild) t = t.firstElementChild;
      for (let k = 0; k < 3 && !/\/offers\/\d+/.test(location.pathname); k++) {
        const r = t.getBoundingClientRect(), mo = { bubbles: true, cancelable: true, view: window, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2, button: 0 };
        t.dispatchEvent(new MouseEvent('mouseover', mo)); t.dispatchEvent(new MouseEvent('mousemove', mo)); await sleep(200);
        t.click(); await sleep(1500);
      }
      log('✓ Адрес: ' + best.text);
      if (best.house !== 'exact' && H) log(`⚠️ Дома «${a.house}» в подсказках нет — выбран ближайший: проверьте корпус.`, '#b25a00');
    } else {
      try { await navigator.clipboard.writeText(a.query); } catch (e) {}
      log(best?.tie ? `Несколько корпусов дома «${a.house}» — выберите нужный в списке сами.` : best ? `Не нашёл подходящую подсказку (улица/дом). Выберите адрес сами — «${a.query}» в буфере.` : `Введите адрес в поле сами (уже в буфере — ⌘V / Ctrl+V):\n${a.query}\nи выберите подсказку.`, '#b25a00');
    }
    // ждём ID черновика (подсказку мог выбрать и человек) — до 3 минут
    for (let t = 0; t < 360 && !/\/offers\/\d+/.test(location.pathname); t++) { if (stopped) return false; await sleep(500); }
    const m = location.pathname.match(/\/offers\/(\d+)/);
    if (!m) return stop('ДомКлик не создал черновик — адрес не выбран.');
    log('✓ Черновик ' + m[1]);
    return m[1];
  }

  async function markFields() {
    await sleep(1500);
    const next = byText('Далее', 'button')[0]; if (next) { press(next); await sleep(2500); }
    const ns = byText('Не сейчас')[0]; if (ns) { press(ns); await sleep(800); }
    let els = [];
    for (let t = 0; t < 10; t++) {
      els = [...document.querySelectorAll('input,textarea')].filter(e => e.type !== 'hidden' && !/gender|ios-|Search|Translation|Please enter/.test((e.id || '') + (e.placeholder || '') + (e.name || '')) && !panel.contains(e));
      if (els.length >= DA.FIELD_COUNT) break; await sleep(700);
    }
    els.forEach((e, k) => e.setAttribute('data-k', k));
    const lab = k => ((els[k]?.closest('label')?.innerText || els[k]?.placeholder || '').trim());
    const bad = Object.entries(DA.EXPECT).filter(([k, v]) => !lab(+k).startsWith(v)).map(([k]) => k + ':' + lab(+k).slice(0, 12));
    // Число полей ДомКлик меняет (12.11 было 95 вместо 96) — главное, чтобы совпали подписи контрольных полей
    if (els.length < 92 || bad.length) return stop(`ДомКлик изменил форму (полей ${els.length}, не совпало: ${bad.join(', ') || '—'}). Заполните вручную и сообщите в «Для Агента».`);
    if (!document.body.innerText.includes('продаже квартиры')) return stop('Это не форма продажи квартиры.');
    return true;
  }

  let lastFiles = [];
  const putFiles = files => { const fin = [...document.querySelectorAll('input[type=file]')].find(x => /jpeg|image/.test(x.accept || '')); if (!fin || !files.length) return false;
    const dt = new DataTransfer(); files.forEach(f => dt.items.add(f)); fin.files = dt.files; fin.dispatchEvent(new Event('change', { bubbles: true })); return true; };
  async function photos(urls, crop) {
    const files = [], errs = [];
    for (let n = 0; n < urls.length; n++) {
      if (stopped) break;
      const r = await chrome.runtime.sendMessage({ type: 'photo', url: urls[n] });
      if (!r?.ok) { errs.push(n + 1); continue; }
      const bin = atob(r.b64), buf = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
      let blob = new Blob([buf], { type: r.type });
      if (crop || !/jpe?g/.test(r.type)) { // обрезка низа 1/20 и/или webp/png → jpeg (форма принимает jpeg)
        try {
          const bm = await createImageBitmap(blob);
          const h = crop ? Math.round(bm.height * 19 / 20) : bm.height;
          const c = new OffscreenCanvas(bm.width, h);
          c.getContext('2d').drawImage(bm, 0, 0, bm.width, h, 0, 0, bm.width, h);
          blob = await c.convertToBlob({ type: 'image/jpeg', quality: 0.92 });
        } catch (e) { errs.push(n + 1); continue; }
      }
      files.push(new File([blob], `photo_${String(n + 1).padStart(2, '0')}.jpg`, { type: 'image/jpeg' }));
      if (n % 5 === 4) log(`  фото ${n + 1}/${urls.length}`);
    }
    if (files.length && !putFiles(files)) log('Не нашёл поле фото.', '#c00');
    lastFiles = files;
    return { n: files.length, errs };
  }

  async function api(draft) {
    try {
      const o = (await (await fetch('/api/v7/offers/' + draft, { credentials: 'include' })).json()).answer?.offer || {};
      return { addr: o.address?.display_name || '', apt: o.is_apartment, rooms: o.rooms, floor: o.floor, max: o.max_floor, price: o.price,
        space: o.space, photos: (o.photo || []).length, desc: (o.description || '').length };
    } catch (e) { return {}; }
  }

  async function run(job, it, s) {
    ui(it);
    let f = DA.toForm(it, s);
    let draft = job.draft || (location.pathname.match(/\/offers\/(\d+)/) || [])[1];
    let claimed = false;
    const fail = async (msg, extra = {}) => { stop(msg); if (claimed) await chrome.runtime.sendMessage({ type: 'release', id: it.id }); return { ok: false, draft, error: msg, ...extra }; };
    try {
      if (!draft) {
        if (!/\/offers\/new/.test(location.pathname)) { location.href = 'https://my.domclick.ru/offers/new'; return 'nav'; }
        // общая база: занять объявление и проверить лимит подписки
        const c = await chrome.runtime.sendMessage({ type: 'claim', id: it.id });
        if (c?.st === 'taken') return fail('Это объявление уже выставил другой пользователь «Для Агента» — пропускаю.', { taken: true });
        if (c?.st === 'limit') { if (extraEl) extraEl.insertAdjacentHTML('beforeend', `<div style="margin-top:6px"><a href="${esc(c.pay || 'https://dlya-agenta.github.io/pay.html?plan=sub')}" target="_blank" style="color:#0f3fa6;font-weight:600">Оформить подписку / тариф выше</a></div>`); return fail(c.message || 'Лимит подписки исчерпан', { limit: true }); }
        if (!c?.st) return fail(c?.message || c?.error || 'Нет связи с «Для Агента» — войдите на сайте и попробуйте снова', { limit: c?.error === 'need_pay' || c?.error === 'no_auth' });
        claimed = c.st === 'ok';
        log(`✓ Подписка: ${c.used ?? '?'} из ${c.limit ?? '∞'}${c.st === 'repeat' ? ' (своё повторно — не в лимит)' : ''}`);
        if (it.light) {   // из списка Авито — дочитать полностью (фото 1280, описание, параметры) в фоновой вкладке
          log('Читаю объявление Авито полностью в фоне…');
          const fr = await chrome.runtime.sendMessage({ type: 'full', id: it.id });
          if (!fr?.ok) return fail('Авито: ' + (fr?.error || 'не прочиталось'));
          it = ((await chrome.storage.local.get('queue')).queue || []).find(x => x.id === it.id) || it;
          f = DA.toForm(it, s);
          log(`✓ Прочитано: фото ${it.photos.length}`);
        }
      }
      f.notes.concat(it.notes || []).forEach(n => log('• ' + n, '#b25a00'));
      if (!draft) {
        if (!(await stepStart())) return fail(lastErr || 'не открылась форма');
        draft = await stepAddress(it); if (!draft) return fail(lastErr || 'адрес не выбран');
        await chrome.storage.local.set({ job: { ...job, draft, stage: 'fill' } });
      }
      if (!(await markFields())) return { ok: false, draft, error: lastErr };
      log('Заполняю поля (≈1,5 с на поле, не трогайте страницу)…');
      if (f.roomsK != null) await tick(f.roomsK);
      for (const [k, v] of Object.entries(f.texts)) { if (stopped) return; await setText(+k, v); }
      log('✓ Площади, этажи, цена');
      for (const k of f.ticks) { if (stopped) return; await tick(k); }
      log(`✓ Отметки: ${f.ticks.length}`);
      log(`Фото: ${f.photos.length}…`);
      const ph = await photos(f.photos, s.cropBottom !== false);
      log(`✓ Фото загружено ${ph.n}${s.cropBottom !== false ? ' (низ обрезан на 1/20)' : ''}${ph.errs.length ? `, не скачались: ${ph.errs.join(', ')}` : ''}${it.skippedVideo ? `, превью видео пропущено: ${it.skippedVideo}` : ''}`);
      const ta = [...document.querySelectorAll('textarea')].find(t => (t.placeholder || '').startsWith('Расскажите'));
      if (ta && f.desc) { ta.focus(); ta.dispatchEvent(new FocusEvent('focusin', { bubbles: true })); setNative(ta, f.desc); await sleep(500);
        ta.blur(); ta.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); log('✓ Описание'); }
      // проверка через API ДомКлика
      let o = {};
      // ДомКлик грузит фото по одному: ~3–5 с на фото. Ждём, пока все загрузятся, до 4 минут;
      // если число не растёт 45 с подряд — дальше не ждём.
      log('Жду, пока ДомКлик примет фото…');
      let last = -1, still = 0, retried = false;
      for (let t = 0; t < 100; t++) {
        if (stopped) return;
        await sleep(3000); o = await api(draft);
        if ((o.photos ?? 0) >= ph.n && o.desc) break;
        if (o.photos === last) {
          still += 3;
          if (still >= 45 && !retried && ph.n && !(o.photos > 0)) {   // ДомКлик не принял ни одного — загрузить ещё раз
            retried = true; still = 0; log('ДомКлик не принял фото — загружаю ещё раз…', '#b25a00');
            await sleep(1000); putFiles(lastFiles);
          } else if (still >= 45) break;
        } else { still = 0; last = o.photos; if (t % 3 === 0) log(`  принято фото ${o.photos ?? 0}/${ph.n}`); }
      }
      const pr = [];
      if (it.floor && o.floor != it.floor) pr.push('этаж');
      if (it.floors && o.max != it.floors) pr.push('этажность');
      if (f.price && o.price != f.price) pr.push('цена');
      if (f.desc && !o.desc) pr.push('описание');
      if (ph.n && o.photos < ph.n) pr.push(`фото ${o.photos ?? 0}/${ph.n}`);
      if (f.photos.length && !ph.n) pr.push('фото не скачались');
      if (o.apt != null && o.apt !== (it.kind === 'Апартаменты')) pr.push('квартира/апартаменты');
      if (it.address?.house && o.addr && !o.addr.toLowerCase().includes(it.address.house.toLowerCase())) pr.push('номер дома в адресе');
      if (/Не удалось сохранить/.test(document.body.innerText)) pr.push('ДомКлик: «Не удалось сохранить» — обновите страницу');
      log(`Проверка: ${o.addr ? o.addr.slice(-50) : ''} · ${o.price ? o.price.toLocaleString('ru') + ' ₽' : ''}${o.space ? ' · ' + Math.round(o.price / o.space).toLocaleString('ru') + ' ₽/м²' : ''} · фото ${o.photos ?? '?'}`);
      const ok = !pr.length;
      if (!ok) log('⚠️ Проверьте вручную: ' + pr.join(', '), '#c00');
      if (ok && (s.autoDraft || job.batch)) {
        const btn = byText('Сохранить как черновик', 'button')[0];
        if (btn) { press(btn); log('✓ Сохранено как черновик'); } else log('Кнопку «Сохранить как черновик» не нашёл — нажмите сами.', '#b25a00');
      }
      log(ok ? '✅ Готово. Проверьте объявление и нажмите «Опубликовать» сами.' : 'Исправьте отмеченное и опубликуйте сами.', ok ? '#138a4a' : '#b25a00');
      log('Не забудьте про комиссию и телефон для связи.', '#666');
      const q = (await chrome.storage.local.get('queue')).queue || [];
      const i = q.findIndex(x => x.id === it.id);
      if (i >= 0) { q[i].domclick = { draft, ok, problems: pr, at: new Date().toLocaleString('ru') }; await chrome.storage.local.set({ queue: q }); }
      if (!job.batch) await chrome.storage.local.remove('job');
      chrome.runtime.sendMessage({ type: 'drafted', id: it.id, draft });
      return { ok, draft, problems: pr };
    } catch (e) { stop(String(e?.message || e)); }
    return { ok: false, draft, error: lastErr || 'остановлено' };
  }

  // Пакет: после каждого объявления — следующее (фон откроет новую форму в этой же вкладке)
  async function runAndNext(job, it, s) {
    const res = await run(job, it, s);
    if (!job.batch || res === 'nav' || stopped) return;
    const out = res || { ok: false, error: lastErr || 'остановлено' };
    log(`Пакет: дальше следующее объявление через 5 с…`, '#0f3fa6');
    if (out.limit) { log('Пакет остановлен: лимит подписки.', '#c00'); chrome.runtime.sendMessage({ type: 'batchNext', res: { ok: false, error: out.error, stop: true } }); return; }
    chrome.runtime.sendMessage({ type: 'batchNext', res: { ok: !!out.ok, draft: out.draft || null, problems: out.problems || [], error: out.error || '', taken: !!out.taken } });
  }

  (async () => {
    const { job } = await chrome.storage.local.get('job');
    if (!job || Date.now() - job.at > (job.draft ? 6 : 0.5) * 3600 * 1000) return; // старое задание не трогаем (черновик — 6 ч)
    const q = (await chrome.storage.local.get('queue')).queue || [];
    const it = q.find(x => x.id === job.id);
    if (!it) { if (job.batch) chrome.runtime.sendMessage({ type: 'batchNext', res: { ok: false, error: 'объявление убрано из списка' } }); return; }
    if (job.draft && !location.pathname.includes('/offers/' + job.draft)) return; // другая страница — молчим
    const s = await DA.getSettings();
    if (job.draft) {
      // Черновик уже начат (перезагрузка, остановка) — сами не продолжаем, спрашиваем: иначе фото задвоятся, цена поменяется
      ui(it);
      extraEl.innerHTML = `<div style="margin-top:6px">Черновик ${esc(job.draft)} уже начат. Фото, загруженные раньше, останутся — лишние удалите сами.</div>
        <div style="margin-top:6px"><button data-go style="background:#138a4a;color:#fff;border:0;border-radius:8px;padding:6px 10px;cursor:pointer">Продолжить заполнение</button>
        <button data-no style="background:#f1f3f5;border:0;border-radius:8px;padding:6px 10px;cursor:pointer;margin-left:6px">Не нужно</button></div>`;
      extraEl.querySelector('[data-go]').onclick = () => { extraEl.innerHTML = ''; runAndNext(job, it, s); };
      extraEl.querySelector('[data-no]').onclick = async () => { await chrome.storage.local.remove('job'); panel.remove(); panel = null; };
      return;
    }
    if (job.batch) {
      const { batch } = await chrome.storage.local.get('batch');
      ui(it); if (batch) extraEl.innerHTML = `<div style="margin-top:4px;color:#0f3fa6"><b>Пакет: ${batch.i + 1} из ${batch.ids.length}</b> · ✕ — остановить пакет</div>`;
    }
    runAndNext(job, it, s);
  })();
})();
