// Общее для фона и вкладки ДомКлика: источники, настройки, перевод объявления в единый вид и в поля ДомКлика.
/* eslint-disable no-unused-vars */
const DA = (() => {
  // ---------- Источники ----------
  // targets: куда можно переносить. 'domclick' — форма ДомКлика, 'file' — файл для сайта «Для Агента».
  const SOURCES = {
    avito: { name: 'Авито', targets: ['domclick', 'file'],
      isItem: u => /^https:\/\/(www\.|m\.)?avito\.ru\/.+_\d{6,}\/?$/.test(u.split(/[?#]/)[0]) },
    // Циан: в рекламу (ДомКлик) не берём — на фото логотипы площадки; можно перенести в «Эксклюзивы» сайта (файлом)
    cian: { name: 'Циан', targets: ['excl', 'file'], warn: 'С Циана в рекламу не берём — на фото логотипы. Можно перенести в Эксклюзивы.',
      isItem: u => /^https:\/\/([a-z-]+\.)?cian\.ru\/sale\/flat\/\d+\/?$/.test(u.split(/[?#]/)[0]) },
    // Сайт «Для Агента»: объекты берутся пачкой со страницы (выдача, избранное, подборка)
    site: { name: 'Для Агента', targets: ['domclick', 'file'], isItem: () => false },
    // свои вторички из профиля агента — только «Эксклюзивы» сайта (файлом), не в ДомКлик
    vt: { name: 'Мои вторички', targets: ['excl'], isItem: () => false },
  };
  const sourceOf = url => Object.keys(SOURCES).find(k => SOURCES[k].isItem(url)) || null;
  // Страницы, с которых берём пачкой: свои объявления на Авито (профиль) и сайт «Для Агента»
  const listOf = url => {
    const u = url.split('#')[0];
    if (/^https:\/\/dlya-agenta\.github\.io\/(index\.html)?(\?|$)/.test(u)) return 'site';
    if (/^https:\/\/web\.ygroup\.ru\/app\/profile/.test(u)) return 'vt';
    if (/^https:\/\/(www\.)?avito\.ru\//.test(u) && !/_\d{6,}\/?(\?|$)/.test(u) && /\/(profile|user\/|brands\/)|\/kvartiry/.test(u)) return 'avito';
    if (/^https:\/\/([a-z-]+\.)?cian\.ru\//.test(u) && !/\/sale\/flat\/\d+/.test(u) && /cat\.php|kupit|prodazha|\/company\/|\/agents?\//.test(u)) return 'cian';
    return null;
  };
  const SIZES = [3, 10, 20, 30];

  // ---------- Настройки ----------
  const DEFAULTS = {
    sendVia: true,   // v0.7: отправка сообщений из сайта через WhatsApp / Telegram этого браузера
    floatingButton: true,     // кнопка «⇪ Для Агента» на странице объявления
    msgToBot: true,           // новые сообщения клиентов на ДомКлике, Авито, Циане — дублировать в бот
    batchSize: 10,            // сколько за раз по умолчанию: 3 | 10 | 20 | 30
    avitoPause: 30,           // пауза между объявлениями Авито при сборе пачкой, с (меньше 20 — риск блока IP)
    autoDraft: false,         // после заполнения сам нажимает «Сохранить как черновик»
    maxPhotos: 30,            // ДомКлик молча не принимает больше 30 за раз
    layoutsLast: true,        // планировки — в конец
    cropBottom: true,         // срезать нижнюю 1/20 фото при загрузке (как бот ~/avito-domclick)
    owners: '1',              // собственников: '1' | '2' | '3+' | ''
    ownYears: '>5',           // лет в собственности: '<3' | '3-5' | '>5' | ''
    bargain: true,            // «Торг уместен»
    online: true,             // «Готов показать онлайн»
    repairDefault: 'Косметический', // если ремонт не указан; '' — не ставить
    fiveStory: true,          // 5 этажей и нет данных: панель, потолки от 2,7, без лифта
    priceMarkupPct: 0,        // наценка к цене, %
    minPriceM2: 0,            // минимум ₽ за м² (0 — выключено)
    signature: '',            // строка в конце описания
    siteUrl: 'https://dlya-agenta.github.io/', // куда загружать файл
  };
  const getSettings = async () => ({ ...DEFAULTS, ...((await chrome.storage.local.get('settings')).settings || {}) });

  // ---------- Помощники ----------
  const num = s => { const m = String(s ?? '').replace(/ |\s/g, '').match(/\d+(?:[.,]\d+)?/); return m ? parseFloat(m[0].replace(',', '.')) : null; };
  const LAT2CYR = { a: 'а', c: 'с', e: 'е', o: 'о', p: 'р', x: 'х', y: 'у', A: 'А', E: 'Е', K: 'К', M: 'М', H: 'Н', O: 'О', P: 'Р', C: 'С', T: 'Т', X: 'Х', B: 'В' };
  // «Дoм c бaсceйном» (латиница внутри русских слов) → кириллица
  const fixHomoglyphs = t => String(t || '').replace(/[A-Za-zА-Яа-яЁё]+/g, w =>
    (/[а-яё]/i.test(w) || w.length === 1) ? w.replace(/[aceopxyAEKMHOPCTXB]/g, ch => LAT2CYR[ch]) : w);
  const has = (t, ...ws) => ws.some(w => t.includes(w));
  const P = params => (...names) => { for (const n of names) for (const k in params) if (k.toLowerCase().startsWith(n.toLowerCase())) return String(params[k]); return ''; };

  // Адрес → строка для поиска в ДомКлике + слова улицы и номер дома для выбора подсказки
  const STREET_STOP = /^(ул|улица|пр|пр-т|проспект|пер|переулок|ш|шоссе|б-р|бульвар|наб|набережная|пл|площадь|проезд|тупик|мкр|микрорайон|д|дом|корп|к|стр|г|город|край|краснодарский|россия|сочи|р-н|район|кп|пос|посёлок|поселок|пгт|с|село|снт)$/i;
  function parseAddress(full, parts) {
    full = String(full || '').replace(/\s+/g, ' ').trim();
    let street = parts?.street || '', house = parts?.house || '';
    if (!street || !house) {
      const segs = full.split(',').map(s => s.trim()).filter(Boolean);
      const hi = segs.findIndex((s, i) => i > 0 && /^(д\.?\s*)?\d+[а-яa-z]?(\s*[\/к]\s*\d+)?(\s*(корп|стр)\.?\s*\d+)?$/i.test(s));
      if (hi > 0) { house = house || segs[hi].replace(/^д\.?\s*/i, ''); street = street || segs[hi - 1]; }
      else street = street || segs.filter(s => !/край|сочи|россия|р-н|район/i.test(s)).pop() || '';
    }
    const streetWords = street.toLowerCase().replace(/ё/g, 'е').split(/[\s.,]+/).filter(w => w.length > 1 && !STREET_STOP.test(w));
    const query = ['Сочи', street, house].filter(Boolean).join(', ');
    return { full, street, house, streetWords, query };
  }

  // ---------- Авито → единый вид (порт mapping.py бота ~/avito-domclick) ----------
  function fromAvito(raw) {
    const params = {};
    for (const line of raw.params || []) { const i = line.indexOf(':'); if (i > 0) params[line.slice(0, i).trim()] = line.slice(i + 1).trim().replace(/ /g, ' '); }
    const p = P(params), notes = [];
    const title = raw.title || '', desc = fixHomoglyphs(raw.description || ''), dl = desc.toLowerCase();
    const tl = title.toLowerCase();
    // комнаты
    let rooms = '';
    const rv = p('Количество комнат').toLowerCase();
    if (rv.includes('студ') || tl.includes('студ')) rooms = 'Студия';
    else { const m = rv.match(/\d+/) || title.match(/(\d+)-к/); if (m) { const n = +(m[1] || m[0]); rooms = n >= 5 ? '5+' : String(n); } }
    // этаж
    let floor = null, floors = null;
    const fm = p('Этаж').match(/(\d+)\s*из\s*(\d+)/);
    if (fm) { floor = +fm[1]; floors = +fm[2]; } else { floor = num(p('Этаж')); floors = num(p('Этажей в доме')); }
    // площади: при расхождении с описанием — меньшая
    let total = num(p('Общая площадь')); const living = num(p('Жилая площадь')), kitchen = num(p('Площадь кухни'));
    if (total == null) { const m = title.match(/(\d+(?:[.,]\d+)?)\s*м²/); if (m) total = parseFloat(m[1].replace(',', '.')); }
    const dm = dl.match(/общ\S*\s+площад\S*[^0-9]{0,15}(\d+(?:[.,]\d+)?)/) || dl.match(/площад\S*[^0-9]{0,15}(\d+(?:[.,]\d+)?)\s*(?:кв\.?\s?м|м²|м2|м\.?\s?кв)/);
    if (total && dm) { const d = parseFloat(dm[1].replace(',', '.')); if (d >= 12 && Math.abs(d - total) > 0.5) { notes.push(`Площадь: в параметрах ${total}, в описании ${d} м² — взял меньшую`); total = Math.min(total, d); } }
    if (kitchen != null && kitchen <= 5 && total >= 30) notes.push(`Проверьте: кухня ${kitchen} м² при общей ${total} м²`);
    // санузел
    const bath = p('Санузел').toLowerCase();
    const bathV = !bath ? null : (/[2-9]/.test(bath) || (bath.includes('совм') && bath.includes('разд'))) ? 'Более одного' : bath.includes('разд') ? 'Раздельный' : bath.includes('совм') ? 'Совмещённый' : null;
    // балкон
    const balc = p('Балкон или лоджия', 'Балкон').toLowerCase();
    let balcV = null;
    if (balc) { if (balc.includes('нет')) balcV = 'Нет'; else { const m = balc.match(/\d+/); const n = m ? +m[0] : balc.split(',').filter(x => x.trim()).length; balcV = n >= 3 ? '3+' : String(Math.max(n, 1)); } }
    // ремонт
    const rep = (p('Ремонт') || p('Отделка')).toLowerCase();
    let repV = null;
    if (rep) repV = rep.includes('дизайн') ? 'Дизайнерский' : rep.includes('евро') ? 'Евро' : rep.includes('косм') ? 'Косметический' : (rep.includes('требует') || rep.includes('без')) ? 'Без ремонта' : rep.includes('чистов') ? 'Косметический' : null;
    // вид из окна
    const win = (p('Окна') + ' ' + p('Вид из окон')).toLowerCase(), views = [];
    for (const [k, v] of [['двор', 'Двор'], ['улиц', 'Улица'], ['мор', 'Водоём'], ['вод', 'Водоём'], ['рек', 'Водоём'], ['парк', 'Парк'], ['лес', 'Лес']]) if (win.includes(k) && !views.includes(v)) views.push(v);
    // дом
    const ht = p('Тип дома').toLowerCase();
    const houseV = [['монолит', 'Монолитный'], ['кирпич', 'Кирпичный'], ['панел', 'Панельный'], ['блоч', 'Блочный']].find(([k]) => ht.includes(k))?.[1] || null;
    const ch = (raw.chips || []).join(' | ').toLowerCase(); // плашки «Особенности»
    let lp = p('Пассажирский лифт').toLowerCase(), lg = p('Грузовой лифт').toLowerCase();
    if (!lp) { const m = ch.match(/(\d+)\s*пассаж/); if (m) lp = m[1]; }
    if (!lg) { const m = ch.match(/(\d+)\s*грузов/); if (m) lg = m[1]; }
    let lift = null; if (lp && !lp.includes('нет')) { const m = lp.match(/\d+/); const n = m ? +m[0] : 1; lift = n >= 3 ? '3+' : String(n); }
    const cargo = !!(lg && !lg.includes('нет')); if (!lift && cargo) lift = '1';
    const inHouse = p('В доме').toLowerCase() + ' ' + ch, yard = p('Двор').toLowerCase() + ' ' + ch.replace('закрытый двор', 'закрытая территория'), park = p('Парковка').toLowerCase() + ' ' + ch;
    const sale = (p('Способ продажи') + ' ' + p('Вид сделки') + ' ' + p('Тип сделки')).toLowerCase();
    const ym = p('Год постройки', 'Год сдачи').match(/(19|20)\d\d/);
    const rawPhotos = raw.photos || [];
    // 12.11: фото Авито бывают и на c60…c90.img.avito.st (раньше там были только превью видео) — берём все,
    // фон расширения качает без CORS, что не скачалось — пропускается при загрузке
    const photos = rawPhotos;
    const address = parseAddress(raw.address || raw.addressAlt);
    if (!address.house) notes.push('В адресе нет номера дома — выберите подсказку в ДомКлике сами');
    return {
      source: 'avito', id: 'avito-' + ((raw.url || '').match(/_(\d{6,})/)?.[1] || Date.now()), url: raw.url, takenAt: new Date().toISOString(),
      title, price: +(String(raw.price || '').replace(/\D/g, '')) || null, description: desc, address, photos,
      rooms, total, living, kitchen, floor, floors,
      kind: (tl.includes('апартамент') || p('Статус', 'Тип жилья').toLowerCase().includes('апартамент')) ? 'Апартаменты' : 'Квартира',
      bath: bathV, balcony: balcV, repair: repV, views, year: ym ? ym[0] : (ch.match(/(19|20)\d\d\s*г/)?.[0].slice(0, 4) || null),
      ceiling: num(p('Высота потолков')) || num(ch.match(/потолки\s*[\d.,]+/)?.[0]), house: houseV, lift, cargo,
      gas: inHouse.includes('газ') || null, chute: inHouse.includes('мусоропровод') || null,
      security: [has(inHouse + dl, 'консьерж') && 'Консьерж', has(yard + dl, 'закрытая территория', 'закрытой территори', 'огороженная территория') && 'Закрытая территория', has(inHouse + dl, 'домофон') && 'Домофон', has(inHouse + dl, 'кодов') && 'Кодовая дверь'].filter(Boolean),
      parking: [(park.includes('подзем') || (dl.includes('подземн') && dl.includes('паркинг'))) && 'Подземная', (park.includes('во дворе') || park.includes('открытая')) && 'Во дворе', park.includes('шлагбаум') && 'Со шлагбаумом', park.includes('охраня') && 'Охраняемая', dl.includes('гараж') && 'Есть гараж'].filter(Boolean),
      improvement: [has(yard + dl, 'детская площадка', 'детской площадк', 'детские площадк') && 'Детская площадка', has(yard + dl, 'спортивная площадка', 'спортивной площадк', 'спортплощадк') && 'Спортивная площадка'].filter(Boolean),
      infra: infraFrom(dl),
      deal: sale.includes('переуступ') ? 'Переуступка' : sale.includes('альтерн') ? 'Альтернативная' : 'Прямая',
      params, notes, skippedVideo: rawPhotos.length - photos.length,
    };
  }
  function infraFrom(dl) {
    dl = dl.replace(/«[^»]*»|"[^"]*"/g, ' '); // названия ЖК в кавычках («Светлана Парк») — не инфраструктура
    return [dl.includes('школ') && 'Школа', has(dl, 'детский сад', 'детсад', 'детского сада', 'детские сады') && 'Детский сад',
      has(dl, 'торговый центр', 'торгового центра', ' тц', 'тц ') && 'Торговый центр', /(^|[^а-я])парк(а|е|ом|у|и|ов)?([^а-я]|$)/.test(dl) && 'Парк', dl.includes('фитнес') && 'Фитнес'].filter(Boolean);
  }

  // ---------- Циан → единый вид (window._cianConfig['frontend-offer-card'] → defaultState.offerData) ----------
  function fromCian(raw) {
    const o = raw.offer || {}, b = o.building || {}, notes = [];
    const params = {};
    for (const g of raw.features || []) for (const f of g.features || []) params[f.label] = f.value;
    for (const f of raw.factoids || []) if (!(f.title in params) && (f.value ?? f.text) != null) params[f.title] = f.value ?? f.text;   // в выдаче — text
    const p = P(params), desc = fixHomoglyphs(o.description || ''), dl = desc.toLowerCase();
    const n = v => (v == null || v === '' ? null : num(v));
    const rc = +o.roomsCount || 0;
    const rooms = (o.flatType === 'studio' || /студ/i.test(p('Количество комнат'))) ? 'Студия' : rc ? (rc >= 5 ? '5+' : String(rc)) : '';
    const wcC = +o.combinedWcsCount || 0, wcS = +o.separateWcsCount || 0;
    let bath = (wcC + wcS > 1) ? 'Более одного' : wcS ? 'Раздельный' : wcC ? 'Совмещённый' : null;
    if (!bath) { const t = p('Санузел').toLowerCase(); bath = !t ? null : (/[2-9]/.test(t) || (t.includes('совм') && t.includes('разд'))) ? 'Более одного' : t.includes('разд') ? 'Раздельный' : t.includes('совм') ? 'Совмещённый' : null; }
    const bc = (+o.balconiesCount || 0) + (+o.loggiasCount || 0);
    const balcony = bc ? (bc >= 3 ? '3+' : String(bc)) : ('balconiesCount' in o || 'loggiasCount' in o) ? 'Нет' : null;
    const REP = { no: 'Без ремонта', cosmetic: 'Косметический', euro: 'Евро', design: 'Дизайнерский' };
    let repair = REP[o.repairType] || null;
    if (!repair) { const t = (p('Ремонт') || p('Отделка')).toLowerCase(); repair = t.includes('дизайн') ? 'Дизайнерский' : t.includes('евро') ? 'Евро' : t.includes('косм') ? 'Косметический' : /без|черн|предчист/.test(t) ? 'Без ремонта' : t.includes('чистов') ? 'Косметический' : null; }
    const VIEW = { yard: ['Двор'], street: ['Улица'], yardAndStreet: ['Двор', 'Улица'] };
    const views = [...(VIEW[o.windowsViewType] || [])];
    if (/мор/.test(p('Вид из окон').toLowerCase() + ' ') && !views.includes('Водоём')) views.push('Водоём');
    const MAT = { monolith: 'Монолитный', monolithBrick: 'Монолитный', brick: 'Кирпичный', panel: 'Панельный', block: 'Блочный', aerocreteBlock: 'Блочный', foamConcreteBlock: 'Блочный', gasSilicateBlock: 'Блочный' };
    const lifts = +(b.passengerLiftsCount ?? o.passengerLiftsCount) || 0, cargoN = +b.cargoLiftsCount || 0;
    const geo = (o.geo?.address || []);
    const street = geo.find(a => a.type === 'street')?.fullName || '';
    const house = geo.find(a => a.type === 'house')?.fullName || '';
    const full = geo.map(a => a.fullName).join(', ') || o.geo?.userInput || '';
    const address = parseAddress(full, { street, house });
    if (!house) notes.push('В адресе нет номера дома — выберите подсказку в ДомКлике сами');
    const st = o.bargainTerms?.saleType || '';
    const ph = (o.photos || []).filter(x => x.fullUrl);
    const photos = ph.filter(x => !x.isLayout).map(x => x.fullUrl);
    const layouts = ph.filter(x => x.isLayout).map(x => x.fullUrl);
    const price = +(o.bargainTerms?.prices?.rur || o.priceTotalRur || o.bargainTerms?.price) || null;
    const parkT = (p('Парковка') || '').toLowerCase();
    const terr = (p('Придомовая территория') || '').toLowerCase(); // «Шлагбаум», «Огороженная», «Закрытая»…
    const district = geo.filter(a => /raion|mikroraion|okrug/.test(a.type)).map(a => a.fullName).join(', ');
    const zk = o.newbuilding?.name || o.geo?.jk?.displayName || o.geo?.jk?.name || '';
    return {
      source: 'cian', id: 'cian-' + (o.cianId || o.id || Date.now()), url: raw.url, takenAt: new Date().toISOString(), district, zk,
      title: raw.title || '', price, description: desc, address, photos, layouts,
      rooms, total: n(o.totalArea ?? b.totalArea), living: n(o.livingArea), kitchen: n(o.kitchenArea),
      floor: n(o.floorNumber), floors: n(b.floorsCount),
      kind: o.isApartments ? 'Апартаменты' : 'Квартира',
      bath, balcony, repair, views,
      year: String(b.buildYear || b.deadline?.year || '').match(/(19|20)\d\d/)?.[0] || null,
      ceiling: n(b.ceilingHeight), house: MAT[b.materialType || b.houseMaterialType] || null,
      lift: lifts ? (lifts >= 3 ? '3+' : String(lifts)) : (cargoN ? '1' : null), cargo: cargoN > 0,
      gas: /газ/.test(p('Газоснабжение').toLowerCase()) || null, chute: /есть|да/.test(p('Мусоропровод').toLowerCase()) || null,
      security: [has(dl, 'консьерж') && 'Консьерж', (has(dl, 'закрытая территория', 'закрытой территори') || has(terr, 'огорож', 'закрыт')) && 'Закрытая территория', dl.includes('домофон') && 'Домофон', dl.includes('кодов') && 'Кодовая дверь'].filter(Boolean),
      parking: [(parkT.includes('подзем') || (dl.includes('подземн') && dl.includes('паркинг'))) && 'Подземная', (parkT.includes('наземн') || parkT.includes('открыт')) && 'Во дворе', terr.includes('шлагбаум') && 'Со шлагбаумом', has(terr + parkT, 'охран') && 'Охраняемая'].filter(Boolean),
      improvement: [has(dl, 'детская площадка', 'детской площадк') && 'Детская площадка', has(dl, 'спортивная площадка', 'спортивной площадк') && 'Спортивная площадка'].filter(Boolean),
      infra: infraFrom(dl),
      deal: st === 'alternative' ? 'Альтернативная' : /dupt|dzhsk|fz214|reassign/i.test(st) ? 'Переуступка' : 'Прямая',
      params, notes, skippedVideo: 0,
    };
  }

  // ---------- Сайт «Для Агента» → единый вид (объект из items страницы + адреса фото) ----------
  function fromSite(x) {
    const notes = [], d = fixHomoglyphs(x.descr || ''), dl = d.toLowerCase();
    const kindL = String(x.kind || '').toLowerCase();
    const rc = +x.rooms || 0;
    const rooms = (/студ/.test(kindL + ' ' + (x.what || '').toLowerCase()) || rc === 0) ? 'Студия' : rc >= 5 ? '5+' : String(rc);
    const fin = [].concat(x.finish || []); // на сайте — список: ['designer','modern','clean']
    const repair = (fin.includes('designer') || /ремонт дизайнерск|дизайнерск\S* ремонт/.test(dl)) ? 'Дизайнерский'
      : (fin.includes('euro') || x.repair === 'modern' || fin.includes('modern')) ? 'Евро'
      : (x.repair === 'good' || fin.includes('repair') || fin.includes('clean')) ? 'Косметический'
      : (x.repair === 'none' || fin.includes('rough') || fin.includes('whitebox')) ? 'Без ремонта' : null;
    const address = parseAddress(x.address || x.street || '');
    if (!address.house) notes.push('В адресе нет номера дома — выберите подсказку в ДомКлике сами');
    return {
      source: 'site', id: 'site-' + x.num, url: 'https://dlya-agenta.github.io/#n=' + x.num, takenAt: new Date().toISOString(),
      district: [x.district, x.sub, x.mkr].filter(Boolean).join(', '), zk: x.zk || x.complex || '', modern: x.repair === 'modern',
      title: x.what || '', price: +x.price || null, description: d, address, photos: x.photos || [], layouts: [],
      rooms, total: +x.area || null, living: null, kitchen: +x.area_kitchen || null, floor: +x.floor || null, floors: +x.floors || null,
      kind: /апарт/.test(kindL + ' ' + String(x.type_name || '').toLowerCase()) ? 'Апартаменты' : 'Квартира',
      bath: null, balcony: /есть балкон|с балконом|балкон/.test(dl) ? '1' : null, repair, views: /мор/.test(dl) && /вид/.test(dl) ? ['Водоём'] : [],
      year: x.house_year ? String(x.house_year) : null, ceiling: null, house: null, lift: null, cargo: false, gas: null, chute: null,
      security: [has(dl, 'консьерж') && 'Консьерж', has(dl, 'закрытая территория', 'закрытой территори', 'закрытый двор') && 'Закрытая территория', dl.includes('домофон') && 'Домофон'].filter(Boolean),
      parking: [has(dl, 'подземн') && dl.includes('паркинг') && 'Подземная'].filter(Boolean),
      improvement: [has(dl, 'детская площадка', 'детской площадк') && 'Детская площадка'].filter(Boolean),
      infra: infraFrom(dl), deal: 'Прямая', params: { num: x.num, zk: x.zk || '', sea_m: x.sea_m || null }, notes, skippedVideo: 0,
    };
  }

  // ---------- Свои вторички (профиль) → единый вид, сразу с полями «Эксклюзивов» сайта ----------
  const DISTR6 = ['Центральный', 'Хостинский', 'Адлерский', 'Лазаревский', 'Сириус', 'Красная Поляна'];
  const distr6 = s => DISTR6.find(d => norm(s).includes(norm(d).replace(/ский$/, ''))) || null;
  function fromVt(f) {
    const d = fixHomoglyphs(f.description || ''), dl = d.toLowerCase(), nm = norm([f.name, f.complex_name].join(' '));
    const LAY = { 1: 'Студия', 2: 'Студия', 3: '1', 4: '2', 5: '3', 6: '4', 7: '5+' };
    let rooms = LAY[f.layout_type] || '';
    if (/студи/.test(dl.slice(0, 200) + nm)) rooms = 'Студия';
    const TYPE = { 1: 'квартира', 2: 'дом', 3: 'участок', 4: 'коммерция' };
    let kind = TYPE[f.type] || 'квартира';
    if (kind === 'квартира' && (/апарт/.test(dl.slice(0, 300) + nm) || /(^|\s)ак(\s|$)/.test(nm))) kind = 'апартаменты';
    const finish = /дизайнерск/.test(dl) ? 'designer' : /(черн\S* отделк|без отделк|черновая)/.test(dl) ? 'none' : /(white ?box|предчистов)/.test(dl) ? 'white'
      : /чистов/.test(dl) ? 'clean' : f.decoration_type === 6 || /ремонт|под ключ/.test(dl) ? 'repair' : null;
    const photos = (f.images || []).slice().sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).map(im => im.static_object?.path_1000px || im.static_object?.path).filter(Boolean);
    const address = parseAddress(f.address || '');
    const district = distr6(f.district?.name || f.district_name || '') || distr6(f.district_parent_name || '');
    return {
      source: 'vt', id: 'vt-' + f.id, url: location?.href || '', takenAt: new Date().toISOString(), light: false,
      title: [rooms === 'Студия' ? 'Студия' : rooms ? rooms + '-комн.' : '', kind, f.area_m2 ? f.area_m2 + ' м²' : '', f.floor ? `${f.floor}/${f.total_floors || '?'} эт.` : ''].filter(Boolean).join(' · '),
      price: +f.total_price || null, description: d, address, photos, layouts: [], rooms, total: +f.area_m2 || null, floor: +f.floor || null, floors: +f.total_floors || null,
      kind: kind === 'апартаменты' ? 'Апартаменты' : 'Квартира', district: district || '', zk: f.complex_name || '',
      excl: { kind, rooms: rooms === 'Студия' ? 0 : rooms === '5+' ? 4 : rooms ? Math.min(4, +rooms) : null, area: +f.area_m2 || null, floor: f.floor ?? null, floors: f.total_floors ?? null,
        land: f.acreage ? +f.acreage : null, price: +f.total_price || null, district, sub: null, address: f.address || '', complex: f.complex_name || '',
        finish, descr: d.slice(0, 4000), comm_pct: +f.commission_percent > 0 ? Math.round((+f.commission_percent < 1 ? +f.commission_percent * 100 : +f.commission_percent) * 100) / 100 : null,   // в профиле — доля (0.0633 = 6,33 %)
        lat: f.location?.latitude ?? null, lng: f.location?.longitude ?? null },
      params: {}, notes: [], skippedVideo: 0,
    };
  }
  // Циан → поля «Эксклюзивов»
  function exclOf(it) {
    if (it.excl) return it.excl;
    const R = { 'Студия': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5+': 4 };
    const FIN = { 'Без ремонта': 'none', 'Косметический': 'repair', 'Евро': 'repair', 'Дизайнерский': 'designer' };
    return { kind: it.kind === 'Апартаменты' ? 'апартаменты' : 'квартира', rooms: R[it.rooms] ?? null, area: it.total || null, floor: it.floor ?? null, floors: it.floors ?? null,
      land: null, price: it.price || null, district: distr6(it.district || it.address?.full || ''), sub: null, address: it.address?.full || '', complex: it.zk || '',
      finish: FIN[it.repair] || null, descr: String(it.description || '').slice(0, 4000), comm_pct: null, lat: null, lng: null };
  }
  // фото для «Эксклюзивов»: JPEG до 490 КБ, сторона до 1400 (как сжимает сайт), низ 1/20 — по настройке
  async function exclPhoto(blob, crop) {
    const bm = await createImageBitmap(blob);
    const h0 = crop ? Math.round(bm.height * 19 / 20) : bm.height;
    let side = 1400, q = 0.82, out = null;
    for (let t = 0; t < 6; t++) {
      const k = Math.min(1, side / Math.max(bm.width, h0)), c = new OffscreenCanvas(Math.round(bm.width * k), Math.round(h0 * k));
      c.getContext('2d').drawImage(bm, 0, 0, bm.width, h0, 0, 0, c.width, c.height);
      out = await c.convertToBlob({ type: 'image/jpeg', quality: q });
      if (out.size < 490_000) break;
      q -= 0.1; if (q < 0.55) { q = 0.75; side -= 300; }
    }
    const buf = new Uint8Array(await out.arrayBuffer()); let bin = '';
    for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
    return 'data:image/jpeg;base64,' + btoa(bin);
  }
  // файл «Эксклюзивов»: getBlob(url) → Blob; progress(i, n)
  async function buildExcl(items, getBlob, crop, progress = () => {}) {
    const out = [];
    for (let i = 0; i < items.length; i++) {
      const it = items[i], ph = [];
      for (const u of (it.photos || []).slice(0, 15)) { try { const b = await getBlob(u); if (b) ph.push(await exclPhoto(b, crop)); } catch (e) { /* пропуск */ } }
      out.push({ ref: it.id, ...exclOf(it), photos: ph });
      progress(i + 1, items.length);
    }
    return { format: 'dlya-agenta-excl', version: 1, createdAt: new Date().toISOString(), count: out.length, items: out };
  }

  // ---------- Единый вид → поля формы ДомКлика ----------
  // Номера полей = порядок input/textarea на шаге 2 формы (проверено в 5 переносах, октябрь 2026).
  const F = {
    rooms: { '1': 2, '2': 3, '3': 4, '4': 5, '5+': 6, 'Студия': 7 },
    total: 8, living: 9, kitchen: 10, floor: 11, floors: 12, year: 35, price: 82,
    kind: { 'Квартира': 13, 'Апартаменты': 14 },
    bath: { 'Совмещённый': 15, 'Раздельный': 16, 'Более одного': 17 },
    balcony: { '1': 18, '2': 19, '3+': 20, 'Нет': 21 },
    repair: { 'Без ремонта': 22, 'Косметический': 23, 'Евро': 24, 'Дизайнерский': 25 },
    views: { 'Двор': 27, 'Водоём': 28, 'Улица': 29, 'Парк': 30, 'Лес': 31 },
    house: { 'Кирпичный': 40, 'Монолитный': 41, 'Панельный': 43, 'Блочный': 44 },
    lift: { '1': 45, '2': 46, '3+': 47 }, cargo: 48, gas: 49, chute: 51,
    security: { 'Домофон': 53, 'Консьерж': 54, 'Закрытая территория': 55, 'Кодовая дверь': 56 },
    parking: { 'Во дворе': 57, 'Подземная': 58, 'Охраняемая': 59, 'Со шлагбаумом': 60, 'Есть гараж': 61 },
    improvement: { 'Детская площадка': 62, 'Спортивная площадка': 63 },
    infra: { 'Школа': 64, 'Детский сад': 65, 'Торговый центр': 66, 'Парк': 67, 'Фитнес': 68 },
    ownYears: { '<3': 71, '3-5': 72, '>5': 73 }, owners: { '1': 74, '2': 75, '3+': 76 },
    bargain: 83, deal: { 'Прямая': 84 }, online: 91,
  };
  // Подписи полей для проверки, что ДомКлик не поменял форму
  const EXPECT = { 7: 'Студия', 13: 'Квартира', 14: 'Апартамент', 25: 'Дизайнерск', 29: 'Улица', 35: '____', 41: 'Монолитный',
    48: 'Есть грузо', 73: 'Больше пят', 82: 'Введите це', 83: 'Торг умест', 84: 'Прямая', 91: 'Готов пока' };
  const FIELD_COUNT = 96;

  function toForm(it, s) {
    const notes = [], ticks = [], texts = {};
    const fmt = v => String(v).replace('.', ',');
    if (it.total) texts[F.total] = fmt(it.total);
    if (it.living) texts[F.living] = fmt(it.living);
    if (it.kitchen) texts[F.kitchen] = fmt(it.kitchen);
    if (it.floor) texts[F.floor] = String(it.floor);
    if (it.floors) texts[F.floors] = String(it.floors);
    if (it.year) texts[F.year] = String(it.year);
    let price = it.price || 0;
    if (price && s.priceMarkupPct) { price = Math.round(price * (1 + s.priceMarkupPct / 100) / 10000) * 10000; notes.push(`Цена с наценкой ${s.priceMarkupPct}%`); }
    if (price && s.minPriceM2 && it.total && price / it.total < s.minPriceM2) {
      price = Math.ceil(s.minPriceM2 * it.total / 10000) * 10000; notes.push(`Цена поднята до минимума ${s.minPriceM2.toLocaleString('ru')} ₽/м²`);
    }
    if (price) texts[F.price] = String(price);
    const add = (map, v) => { if (v != null && map[v] != null) ticks.push(map[v]); };
    add(F.kind, it.kind);
    add(F.bath, it.bath); add(F.balcony, it.balcony);
    add(F.repair, it.repair || s.repairDefault || null);
    if (!it.repair && s.repairDefault) notes.push(`Ремонт не указан — поставил «${s.repairDefault}»`);
    (it.views || []).forEach(v => add(F.views, v));
    const five = s.fiveStory && +it.floors === 5;
    let ceil = it.ceiling;
    if (!ceil && five) ceil = 2.7;
    if (ceil) { const c = [[4, 39], [3, 38], [2.7, 37], [2.5, 36]].find(([h]) => ceil + 1e-6 >= h); if (c) ticks.push(c[1]); }
    add(F.house, it.house || (five ? 'Панельный' : null));
    if (!(five && !it.lift)) { add(F.lift, it.lift); if (it.cargo) ticks.push(F.cargo); }
    if (it.gas) ticks.push(F.gas);
    if (it.chute) ticks.push(F.chute);
    ['security', 'parking', 'improvement', 'infra'].forEach(g => (it[g] || []).forEach(v => add(F[g], v)));
    add(F.ownYears, s.ownYears); add(F.owners, s.owners);
    if (s.bargain) ticks.push(F.bargain);
    if (F.deal[it.deal]) ticks.push(F.deal[it.deal]); else notes.push(`Тип сделки «${it.deal}» — выберите сами`);
    if (s.online) ticks.push(F.online);
    let desc = it.description || '';
    if (s.signature) desc = desc.trim() + '\n\n' + s.signature.trim();
    const lay = it.layouts || [];
    const allPh = s.layoutsLast ? [...(it.photos || []), ...lay] : [...lay, ...(it.photos || [])];
    const max = Math.min(30, s.maxPhotos || 30);
    if (allPh.length > max) notes.push(`Фото ${allPh.length} — беру первые ${max}`);
    return { roomsK: F.rooms[it.rooms] ?? null, texts, ticks: [...new Set(ticks)], price, desc, notes, photos: allPh.slice(0, max) };
  }

  // ---------- Фильтр при сборе: площадь и комнаты — всем; район, ЖК, адрес — PRO и MAX; «современный ремонт» — PRO/MAX, сайт ----------
  const FILTER0 = { areaMin: '', areaMax: '', rooms: [], district: '', zk: '', addr: '', modern: false };
  const proTier = t => t === 'pro' || t === 'max';
  const roomsOf = it => it.rooms || (() => { const t = String(it.title || '').toLowerCase(); if (/студ/.test(t)) return 'Студия'; const m = t.match(/(\d+)\s*-?\s*к/); return m ? (+m[1] >= 5 ? '5+' : m[1]) : ''; })();
  const areaOf = it => it.total || num((String(it.title || '').match(/(\d+(?:[.,]\d+)?)\s*м²/) || [])[1]);
  const norm = s => String(s || '').toLowerCase().replace(/ё/g, 'е');
  const words = s => norm(s).split(/[\s,.;]+/).filter(w => w.length > 1);
  function matchFilter(it, f, tier) {
    if (!f) return true;
    const a = areaOf(it);
    if (f.areaMin && !(a >= +f.areaMin)) return false;
    if (f.areaMax && !(a && a <= +f.areaMax)) return false;
    if (f.rooms?.length) { const r = roomsOf(it); const rr = r === '5+' ? '4+' : (+r >= 4 ? '4+' : r); if (!f.rooms.includes(rr)) return false; }
    if (proTier(tier)) {
      const hay = norm([it.address?.full, it.district, it.zk, it.title, it.description?.slice(0, 300)].join(' '));
      for (const k of ['district', 'zk', 'addr']) if (f[k] && !words(f[k]).every(w => hay.includes(w))) return false;
      if (f.modern && it.source === 'site' && !it.modern) return false;
    }
    return true;
  }
  const filterText = (f, tier) => { if (!f) return ''; const p = [];
    if (f.rooms?.length) p.push(f.rooms.join(', ') + ' к.');
    if (f.areaMin || f.areaMax) p.push(`${f.areaMin || '…'}–${f.areaMax || '…'} м²`);
    if (proTier(tier)) { if (f.district) p.push(f.district); if (f.zk) p.push('ЖК ' + f.zk); if (f.addr) p.push(f.addr); if (f.modern) p.push('совр. ремонт'); }
    return p.join(' · '); };

  // ---------- Файл для сайта «Для Агента» ----------
  const feed = items => ({ format: 'dlya-agenta-feed', version: 1, createdAt: new Date().toISOString(), count: items.length,
    items: items.map(({ params, ...rest }) => ({ ...rest, params })) });

  return { SOURCES, sourceOf, listOf, SIZES, fromSite, fromVt, exclOf, buildExcl, DISTR6, FILTER0, matchFilter, filterText, proTier, DEFAULTS, getSettings, fromAvito, fromCian, toForm, feed, F, EXPECT, FIELD_COUNT, parseAddress };
})();
if (typeof self !== 'undefined') self.DA = DA;
