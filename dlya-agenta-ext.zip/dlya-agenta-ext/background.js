// Фон расширения: читает объявление со страницы, хранит список, качает фото, открывает ДомКлик.
importScripts('common.js', 'sender.js');   // v0.7: sender.js — отправка сообщений из сайта через WhatsApp / Telegram этого браузера

// ---- Чтение страниц (выполняется в самой странице, world: MAIN — нужен доступ к данным React/Циана) ----
function extractAvito() {
  const BLOCK = /Доступ ограничен|не робот|Подтвердите, что вы|captcha|Проблема с IP/i;
  const body = document.body?.innerText || '';
  if (BLOCK.test(document.title + ' ' + body.slice(0, 400))) return { blocked: true };
  const txt = s => { const e = document.querySelector(s); return e ? e.innerText.trim() : ''; };
  const params = [];
  document.querySelectorAll('[data-marker="item-view/item-params"] li, [data-marker*="item-params"] li')
    .forEach(li => { const t = li.innerText.replace(/\s+/g, ' ').trim(); if (t && !params.includes(t)) params.push(t); });
  // Адрес: второе «Расположение\n…» (первое — блок Росреестра)
  const re = /Расположение\s*\n+([^\n]+)/g; let m; const hits = [];
  while ((m = re.exec(body)) !== null) hits.push(m[1].trim());
  const address = (hits.length > 1 ? hits[1] : '') || hits.find(h => /,/.test(h)) || hits[0] || '';
  const addrEl = document.querySelector('[itemprop="address"], [data-marker="item-view/item-address"]');
  // Блок «Особенности» (плашки: «Закрытый двор», «1 грузовой лифт», «Потолки 3 м»…)
  let chips = [];
  const fh = [...document.querySelectorAll('h2,h3')].find(h => h.innerText.trim() === 'Особенности');
  if (fh) {
    let box = fh.nextElementSibling || fh.parentElement?.nextElementSibling;
    if (box) chips = box.innerText.split('\n').map(s => s.trim()).filter(s => s && s.length < 40).slice(0, 30);
  }
  // Фото — из данных React у галереи (1280x960)
  let photos = [];
  try {
    const el = document.querySelector('[data-marker="item-view/main-gallery"]');
    const key = Object.keys(el).find(k => k.startsWith('__reactFiber'));
    let f = el[key], found = null, d = 0;
    const scan = (o, dd) => { if (!o || typeof o !== 'object' || dd > 4) return null;
      if (Array.isArray(o) && o[0] && typeof o[0] === 'object' && /1280x960|640x480/.test(JSON.stringify(o[0]))) return o;
      for (const k in o) { try { const r = scan(o[k], dd + 1); if (r) return r; } catch (e) {} } return null; };
    while (f && d < 40 && !found) { found = scan(f.memoizedProps, 0); f = f.return; d++; }
    photos = (found || []).map(x => (JSON.stringify(x).match(/"1280x960":"([^"]+)"/) || [])[1]).filter(Boolean);
  } catch (e) {}
  return {
    url: location.href.split(/[?#]/)[0], title: txt('h1'),
    price: txt('[data-marker="item-view/item-price"]') || (document.querySelector('[itemprop="price"]') || {}).content || '',
    params, description: txt('[data-marker="item-view/item-description"]'),
    address, addressAlt: addrEl ? addrEl.innerText.trim() : '', photos, chips,
  };
}

function extractCian() {
  const body = document.body?.innerText || '';
  if (/captcha|не робот|подозрительн/i.test(document.title + ' ' + body.slice(0, 300)) && !window._cianConfig) return { blocked: true };
  const card = (window._cianConfig || {})['frontend-offer-card'];
  const st = Array.isArray(card) ? card.find(x => x.key === 'defaultState')?.value : null;
  const od = st?.offerData;
  if (!od?.offer) return { error: 'Циан: данные объявления на странице не найдены (обновите страницу и попробуйте снова)' };
  const clone = v => JSON.parse(JSON.stringify(v ?? null));
  return { url: location.href.split(/[?#]/)[0], title: document.querySelector('h1')?.innerText.trim() || '',
    offer: clone(od.offer), features: clone(od.features), factoids: clone(od.factoids) };
}

// Сайт «Для Агента»: объекты, показанные на странице сейчас (выдача / избранное / подборка), по порядку карточек
function extractSiteList() {
  let m = null; try { m = items; } catch (e) {} // eslint-disable-line no-undef
  if (!m || !m.size) return { error: 'На странице нет объектов. Откройте выдачу, «Избранное» или подборку и дождитесь загрузки.' };
  const nums = [...new Set([...document.querySelectorAll('article.card[data-num]')].map(a => a.dataset.num))];
  const out = [];
  for (const n of nums) {
    const x = m.get(+n) || m.get(n); if (!x) continue;
    let photos = [], ttl = '';
    try { const k = nPhotos(x); for (let i = 0; i < k; i++) photos.push(photoUrl(x, i)); } catch (e) {} // eslint-disable-line no-undef
    try { ttl = what(x); } catch (e) {} // eslint-disable-line no-undef
    out.push({ ...JSON.parse(JSON.stringify(x)), photos: photos.filter(Boolean), what: ttl });
  }
  return { items: out };
}

// Авито: ссылки на объявления на странице профиля / «Мои объявления»
function extractAvitoLinks() {
  const BLOCK = /Доступ ограничен|не робот|Подтвердите, что вы|captcha|Проблема с IP/i;
  if (BLOCK.test(document.title + ' ' + (document.body?.innerText || '').slice(0, 400))) return { blocked: true };
  const links = [...document.querySelectorAll('a[href]')].map(a => a.href.split(/[?#]/)[0])
    .filter(h => /^https:\/\/(www\.)?avito\.ru\/[^/]+\/kvartiry\/.+_\d{6,}$/.test(h));
  return { links: [...new Set(links)] };
}

// Авито: карточки выдачи / профиля без захода внутрь (полные фото и описание — при переносе, в фоновой вкладке)
function extractAvitoList() {
  const BLOCK = /Доступ ограничен|не робот|Подтвердите, что вы|captcha|Проблема с IP/i;
  if (BLOCK.test(document.title + ' ' + (document.body?.innerText || '').slice(0, 400))) return { blocked: true };
  const out = [], seen = new Set();
  const cards = [...document.querySelectorAll('[data-marker="item"], [data-marker*="item-card"], [class*="item-card"], li[class*="item"]')];
  const pick = (root) => {
    const a = root.querySelector('a[data-marker="item-title"]') || root.querySelector('a[itemprop="url"]') || root.querySelector('a[href*="/kvartiry/"]');
    if (!a) return null;
    const url = a.href.split(/[?#]/)[0];
    if (!/^https:\/\/(www\.)?avito\.ru\/[^/]+\/kvartiry\/.+_\d{6,}$/.test(url) || seen.has(url)) return null;
    seen.add(url);
    const t = s => root.querySelector(s)?.innerText?.trim() || '';
    const price = root.querySelector('meta[itemprop="price"]')?.content || t('[data-marker="item-price"]') || '';
    const img = [...root.querySelectorAll('img')].map(i => i.currentSrc || i.src).find(u => /img\.avito\.st/.test(u)) || '';
    const loc = (t('[data-marker="item-location"]') || t('[data-marker="item-address"]')).split('\n').map(x => x.trim()).find(x => /,/.test(x)) || '';
    return { url, title: (a.innerText.trim() || (a.getAttribute('title') || '').replace(/ в [А-ЯЁ][^,]*$/, '') || t('[itemprop="name"]')).split('\n')[0], price, address: loc.replace(/\s*·\s*$/, ''), thumb: img };
  };
  for (const c of cards) { const x = pick(c); if (x) out.push(x); }
  if (!out.length) { // профиль / «Мои объявления» — разметка другая: берём ссылки
    for (const a of document.querySelectorAll('a[href*="/kvartiry/"]')) {
      const url = a.href.split(/[?#]/)[0];
      if (!/^https:\/\/(www\.)?avito\.ru\/[^/]+\/kvartiry\/.+_\d{6,}$/.test(url) || seen.has(url)) continue;
      seen.add(url);
      const box = a.closest('div[class], li') || a;
      out.push({ url, title: a.innerText.trim().split('\n')[0] || decodeURIComponent(url.split('/').pop()).replace(/_\d+$/, '').replace(/_/g, ' '), price: '', address: '', thumb: [...box.querySelectorAll('img')].map(i => i.currentSrc || i.src).find(u => /img\.avito\.st/.test(u)) || '' });
    }
  }
  return { items: out };
}

// Циан: в выдаче уже всё (описание, все фото в полном размере) — внутрь не заходим
function extractCianList() {
  const c = window._cianConfig || {};
  let offers = null;
  for (const k of Object.keys(c)) { const arr = c[k]; if (!Array.isArray(arr)) continue;
    for (const e of arr) { const v = e && e.value; const s = v && (v.results?.offers || v.offers); if (Array.isArray(s) && s.length) { offers = s; break; } }
    if (offers) break; }
  if (!offers) return { error: 'На странице Циана не нашёл объявлений. Откройте выдачу (список) и дождитесь загрузки.' };
  const ids = new Set([...document.querySelectorAll('a[href*="/sale/flat/"]')].map(a => (a.href.match(/\/sale\/flat\/(\d+)/) || [])[1]).filter(Boolean));
  return { items: JSON.parse(JSON.stringify(offers.filter(o => o.dealType === 'sale' && o.offerType === 'flat' && (!ids.size || ids.has(String(o.cianId || o.id)))))) };
}

// Свои вторички (профиль агента): список своих объявлений и карточки — через API профиля, вход — из localStorage страницы
function extractVtList() {
  let tok = null; const walk = o => { if (tok) return; if (typeof o === 'string' && /^[\w-]+\.[\w-]+\.[\w-]+$/.test(o) && o.length > 60) { tok = o; return; } if (o && typeof o === 'object') for (const k in o) walk(o[k]); };
  try { walk(JSON.parse(localStorage.getItem('auth') || '{}')); } catch (e) {}
  if (!tok) return Promise.resolve({ error: 'Войдите в свой профиль на этой площадке и обновите страницу.' });
  const seen = performance.getEntriesByType('resource').map(e => e.name).find(u => /facilities\/created-by-me/.test(u));
  const u = new URL(seen || 'https://api.ygroup.ru/v2/facilities/created-by-me/no-metrics?client_mode=false');
  u.searchParams.set('per_page', '50');
  return (async () => {
    const all = [];
    for (let p = 1; p < 40; p++) {
      u.searchParams.set('page', String(p));
      const r = await fetch(u.href, { headers: { authorization: 'Bearer ' + tok } });
      if (!r.ok) return { error: 'Профиль не ответил (' + r.status + '). Обновите страницу.' };
      const d = (await r.json()).data || {}, arr = d.facility_posts || [];
      all.push(...arr); if (!arr.length || all.length >= (d.meta?.total || 0)) break;
    }
    return { items: all };
  })();
}
function extractVtDetails(ids) {
  let tok = null; const walk = o => { if (tok) return; if (typeof o === 'string' && /^[\w-]+\.[\w-]+\.[\w-]+$/.test(o) && o.length > 60) { tok = o; return; } if (o && typeof o === 'object') for (const k in o) walk(o[k]); };
  try { walk(JSON.parse(localStorage.getItem('auth') || '{}')); } catch (e) {}
  return (async () => {
    const out = [];
    for (let i = 0; i < ids.length; i += 4) {
      const rs = await Promise.all(ids.slice(i, i + 4).map(id => fetch('https://api.ygroup.ru/v2/facilities/' + id, { headers: { authorization: 'Bearer ' + tok } }).then(r => r.ok ? r.json() : null).catch(() => null)));
      for (const j of rs) if (j?.data?.facility) out.push(j.data.facility);
    }
    return { items: JSON.parse(JSON.stringify(out)) };
  })();
}

// ---- Вход и подписка: токен сайта «Для Агента» (вход на сайте через бота) ----
const API = 'https://arojogajdamsyrrpcmso.supabase.co/functions/v1/web';
async function api(action, extra = {}) {
  const { token } = await chrome.storage.local.get('token');
  if (!token) return { error: 'no_auth', message: 'Войдите на сайте «Для Агента» (через бота) — расширение подхватит вход само.' };
  try {
    const r = await fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, auth: { token }, ...extra }) });
    const j = await r.json().catch(() => ({ error: 'server', message: 'Сервер «Для Агента» не ответил' }));
    if (['no_auth', 'kicked', 'expired', 'off', 'no_access'].includes(j.error)) await chrome.storage.local.set({ acct: { ok: false, error: j.error, message: j.message } });
    return j;
  } catch (e) { return { error: 'net', message: 'Нет связи с сервером «Для Агента»' }; }
}
async function account(fresh = true) {
  if (!fresh) { const { acct } = await chrome.storage.local.get('acct'); if (acct) return acct; }
  const r = await api('ext_me');
  const acct = r.ok ? r : { ok: false, error: r.error, message: r.message, pay: r.pay };
  await chrome.storage.local.set({ acct });
  return acct;
}
const gate = async () => { const a = await account(true); return a.ok ? null : { ok: false, gate: true, error: a.message || 'Нужен вход и подписка «Для Агента»', pay: a.pay, login: a.error === 'no_auth' || a.error === 'kicked' }; };
const srcOf = it => it.source === 'avito' ? 'avito:' + ((it.url || '').match(/_(\d{6,})/) || [])[1] : it.source === 'cian' ? 'cian:' + String(it.id).replace(/^cian-/, '') : it.source === 'site' ? 'site:' + String(it.id).replace(/^site-/, '') : null;
async function takenByOthers(srcs) { const r = await api('ext_check', { srcs }); return new Set(r.taken || []); }

// ---- Список объявлений ----
const getQueue = async () => (await chrome.storage.local.get('queue')).queue || [];
const setQueue = q => chrome.storage.local.set({ queue: q });

async function grab(tabId, url) {
  const src = DA.sourceOf(url);
  if (!src || src === 'vt') return { ok: false, error: 'Это не страница объявления Авито или Циан (квартира, продажа).' };
  const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: src === 'avito' ? extractAvito : extractCian });
  if (!result) return { ok: false, error: 'Страница не ответила — обновите её и попробуйте снова.' };
  if (result.blocked) return { ok: false, error: 'Площадка просит проверку (капча). Пройдите её сами на странице и нажмите ещё раз.' };
  if (result.error) return { ok: false, error: result.error };
  const it = src === 'avito' ? DA.fromAvito(result) : DA.fromCian(result);
  it.light = false;
  if (!it.title && !it.total) return { ok: false, error: 'Не нашёл параметры объявления — страница ещё грузится?' };
  const r = await addToQueue([it]);
  return { ok: true, item: summary(it), updated: r.updated > 0 };
}
const summary = it => ({ id: it.id, title: it.title, price: it.price, photos: it.photos.length, address: it.address.full, notes: it.notes });

async function addToQueue(list) {
  const q = await getQueue(); let added = 0, updated = 0;
  for (const it of list) {
    it.src = it.src || srcOf(it);
    const i = q.findIndex(x => x.id === it.id);
    if (i < 0 && it.on === undefined) it.on = true;   // галочка «переносить» — по умолчанию стоит
    if (i >= 0) { q[i] = { ...q[i], ...it, domclick: q[i].domclick, on: q[i].on }; updated++; } else { q.unshift(it); added++; }
  }
  await setQueue(q);
  return { added, updated };
}

// Сайт «Для Агента»: взять первые n квартир/апартаментов со страницы (снятые с продажи и уже взятые — пропускаем)
async function collectSite(tabId, n) {
  const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: extractSiteList });
  if (!result) return { ok: false, error: 'Страница не ответила — обновите её.' };
  if (result.error) return { ok: false, error: result.error };
  const have = new Set((await getQueue()).map(x => x.id));
  const flats = result.items.filter(x => /квартир|апарт|студ/i.test(x.kind || x.type_name || '') && !x.arc && !x.gone);
  const fresh = flats.filter(x => !have.has('site-' + x.num)).slice(0, n);
  const list = fresh.map(DA.fromSite);
  const r = await addToQueue(list);
  return { ok: true, ...r, skipped: result.items.length - flats.length, onPage: result.items.length };
}

// Сбор со страницы-списка (выдача Авито/Циана, профиль Авито, сайт «Для Агента») без захода в объявления.
// Объявления, которые уже выставил другой участник, пропускаются — берутся следующие по списку.
async function collect(tabId, url, n) {
  const g = await gate(); if (g) return g;
  const kind = DA.listOf(url);
  if (!kind) return { ok: false, error: 'Откройте список: выдачу Авито или Циана, свой профиль Авито или сайт «Для Агента».' };
  if (kind === 'vt') return collectVt(tabId, n);
  const func = kind === 'site' ? extractSiteList : kind === 'cian' ? extractCianList : extractAvitoList;
  const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func });
  if (!result) return { ok: false, error: 'Страница не ответила — обновите её.' };
  if (result.blocked) return { ok: false, error: 'Площадка просит проверку (капча). Пройдите её сами и нажмите ещё раз.' };
  if (result.error) return { ok: false, error: result.error };
  let list = [], skipped = 0;
  if (kind === 'site') {
    const flats = result.items.filter(x => /квартир|апарт|студ/i.test(x.kind || x.type_name || '') && !x.arc && !x.gone);
    skipped = result.items.length - flats.length;
    list = flats.map(DA.fromSite);
  } else if (kind === 'cian') {
    list = result.items.map(o => DA.fromCian({ url: (o.fullUrl || `https://sochi.cian.ru/sale/flat/${o.cianId || o.id}/`).split(/[?#]/)[0], title: o.title || o.formattedShortInfo || '', offer: o, features: [], factoids: o.factoids || [] }));
  } else {
    list = result.items.map(x => ({ source: 'avito', id: 'avito-' + (x.url.match(/_(\d{6,})$/) || [])[1], url: x.url, takenAt: new Date().toISOString(), light: true,
      title: x.title, price: +String(x.price).replace(/\D/g, '') || null, address: DA.parseAddress(x.address), photos: x.thumb ? [x.thumb] : [], layouts: [],
      description: '', notes: ['Полные фото и описание — при переносе (откроется само в фоне)'], params: {} }));
  }
  list.forEach(it => { it.src = srcOf(it); });
  // фильтр (площадь, комнаты; PRO/MAX — район, ЖК, адрес, современный ремонт)
  const { filt } = await chrome.storage.local.get('filt'); const tier = (await account(false)).tier;
  const before = list.length; list = list.filter(it => DA.matchFilter(it, filt, tier)); const filtered = before - list.length;
  const have = new Set((await getQueue()).map(x => x.id));
  const taken = await takenByOthers(list.map(x => x.src).filter(Boolean));
  const fresh = list.filter(x => !have.has(x.id) && !taken.has(x.src));
  const pickN = fresh.slice(0, n);
  const r = await addToQueue(pickN);
  return { ok: true, ...r, skipped, filtered, taken: list.filter(x => taken.has(x.src)).length, already: list.filter(x => have.has(x.id)).length, onPage: list.length, short: pickN.length < n };
}

async function collectVt(tabId, n) {
  const run = async (func, args = []) => (await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args }))[0]?.result;
  const list = await run(extractVtList);
  if (!list) return { ok: false, error: 'Страница не ответила — обновите её.' };
  if (list.error) return { ok: false, error: list.error };
  const { filt } = await chrome.storage.local.get('filt'); const tier = (await account(false)).tier;
  const pre = list.items.map(x => ({ raw: x, it: DA.fromVt(x) }));
  const ok = pre.filter(p => DA.matchFilter(p.it, filt, tier));
  const want = ok.slice(0, n === 'all' ? Infinity : n);
  const det = await run(extractVtDetails, [want.map(p => p.raw.id)]);
  const items = (det?.items || []).map(DA.fromVt);
  items.forEach(it => { it.on = true; });
  const r = await addToQueue(items);
  return { ok: true, ...r, filtered: pre.length - ok.length, onPage: pre.length, ids: items.map(x => x.id) };
}

// «Перенести свои Эксклюзивы ВТОРИЧЕК»: страница расширения собирает файл (фото, поля под фильтр сайта) и скачивает
async function exclOpen(ids) {
  const q = await getQueue();
  const list = (ids?.length ? q.filter(x => ids.includes(x.id)) : q.filter(x => x.on !== false && DA.SOURCES[x.source]?.targets.includes('excl')));
  if (!list.length) return { ok: false, error: 'Нет отмеченных объявлений для Эксклюзивов.' };
  await chrome.storage.local.set({ exclIds: list.map(x => x.id) });
  await chrome.tabs.create({ url: chrome.runtime.getURL('export.html') });
  return { ok: true, count: list.length };
}

// Открыть объявление Авито в фоновой вкладке, прочитать, закрыть (по одному — вызывает страница профиля с паузами)
function waitLoaded(tabId, ms = 45000) {
  return new Promise(res => {
    const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(f); res(false); }, ms);
    const f = (id, info) => { if (id === tabId && info.status === 'complete') { clearTimeout(t); chrome.tabs.onUpdated.removeListener(f); res(true); } };
    chrome.tabs.onUpdated.addListener(f);
  });
}
async function grabUrl(url) {
  if (DA.sourceOf(url) !== 'avito') return { ok: false, error: 'не объявление Авито' };
  const q = await getQueue();
  const ex = q.find(x => x.url === url || x.id === 'avito-' + (url.match(/_(\d{6,})/) || [])[1]);
  if (ex && !ex.light) return { ok: true, skipped: true };
  const { avitoAt = 0 } = await chrome.storage.local.get('avitoAt'), pause = Math.max(20, +(await DA.getSettings()).avitoPause || 30) * 1000;
  const wait = avitoAt + pause - Date.now(); if (wait > 0) await new Promise(s => setTimeout(s, Math.min(wait, 60000)));
  await chrome.storage.local.set({ avitoAt: Date.now() });
  const tab = await chrome.tabs.create({ url, active: false });
  try {
    await waitLoaded(tab.id);
    await new Promise(s => setTimeout(s, 3000)); // галерея и параметры догружаются
    return await grab(tab.id, url);
  } finally { chrome.tabs.remove(tab.id).catch(() => {}); }
}

// ---- Пакет в ДомКлик: по очереди в одной вкладке, каждое — «Сохранить как черновик» ----
const getBatch = async () => (await chrome.storage.local.get('batch')).batch || null;
async function batchStart(n) {
  const q = await getQueue();
  const g = await gate(); if (g) return g;
  const ids = q.filter(x => DA.SOURCES[x.source]?.targets.includes('domclick') && !x.domclick?.ok && x.on !== false).slice(0, n).map(x => x.id);
  if (!ids.length) return { ok: false, error: 'Нет объявлений для переноса: все уже в ДомКлике или список пуст.' };
  const tab = await chrome.tabs.create({ url: 'about:blank' });
  const batch = { ids, i: 0, tabId: tab.id, results: [], startedAt: Date.now() };
  await chrome.storage.local.set({ batch, job: { id: ids[0], stage: 'start', at: Date.now(), batch: true } });
  await chrome.tabs.update(tab.id, { url: 'https://my.domclick.ru/offers/new' });
  return { ok: true, count: ids.length };
}
async function batchNext(res) {
  const b = await getBatch(); if (!b) return { ok: false };
  b.results.push({ id: b.ids[b.i], ...res });
  b.i++;
  if (res.stop) b.stop = true;
  if (res.taken && !b.stop) {   // занято другим — берём следующее отмеченное из списка
    const q = await getQueue();
    const nx = q.find(x => !b.ids.includes(x.id) && DA.SOURCES[x.source]?.targets.includes('domclick') && !x.domclick?.ok && x.on !== false);
    if (nx) b.ids.push(nx.id);
  }
  if (b.i >= b.ids.length || b.stop) {
    b.done = true; await chrome.storage.local.set({ batch: b }); await chrome.storage.local.remove('job');
    return { ok: true, done: true };
  }
  await chrome.storage.local.set({ batch: b, job: { id: b.ids[b.i], stage: 'start', at: Date.now(), batch: true } });
  await new Promise(s => setTimeout(s, 5000)); // дать ДомКлику сохранить черновик
  await chrome.tabs.update(b.tabId, { url: 'https://my.domclick.ru/offers/new' }).catch(() => {});
  return { ok: true, next: b.i };
}

// ---- Фото: качаем здесь (у фона нет ограничений CORS для разрешённых сайтов) ----
async function photo(url) {
  for (let t = 0; t < 3; t++) {
    try {
      const r = await fetch(url, { credentials: 'omit' });
      if (r.ok) {
        const buf = new Uint8Array(await r.arrayBuffer());
        let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
        return { ok: true, type: r.headers.get('content-type') || 'image/jpeg', b64: btoa(bin) };
      }
    } catch (e) {}
    await new Promise(s => setTimeout(s, 800));
  }
  return { ok: false };
}
const PHOTO_HOSTS = /^https:\/\/([a-z0-9-]+\.)*(avito\.st|cdn-cian\.ru|cian\.ru|supabase\.co|twcstorage\.ru)\//;

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === 'grab') {
      { const g = await gate(); if (g) return g; }
      const tab = sender.tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      return grab(tab.id, tab.url);
    }
    if (msg.type === 'setToken') { const { token } = await chrome.storage.local.get('token'); if (msg.token && msg.token !== token) { await chrome.storage.local.set({ token: msg.token }); await account(true); } return { ok: true }; }
    if (msg.type === 'account') return account(msg.fresh !== false);
    if (msg.type === 'clientMsg') {   // новое сообщение клиента на площадке → в бот (сервер сам не шлёт одно и то же чаще раза в 30 мин)
      const s = await DA.getSettings(); if (s.msgToBot === false) return { ok: false };
      const key = msg.site + '|' + (msg.text || msg.count), { msgSeen = {} } = await chrome.storage.local.get('msgSeen');
      if (msgSeen[key] && Date.now() - msgSeen[key] < 30 * 60e3) return { ok: true, dup: true };
      msgSeen[key] = Date.now(); for (const k in msgSeen) if (Date.now() - msgSeen[k] > 864e5) delete msgSeen[k];
      await chrome.storage.local.set({ msgSeen });
      return api('ext_msg', { site: msg.site, text: msg.text, from: msg.from, url: msg.url, count: msg.count });
    }
    if (msg.type === 'sendPoll') { sendTick(true); return { ok: true }; }   // v0.7: сайт поставил задание — забрать сразу, не ждать минуту
    if (msg.type === 'sendState') { const { sendState = null, sendJob = null } = await chrome.storage.local.get(['sendState', 'sendJob']); const c = await cfg().catch(() => null);
      return { on: await sendOn(), state: sendState, job: sendJob && { svc: sendJob.svc, i: sendJob.i, n: sendJob.items.length, last: sendJob.last },
        upd: c?.ver && verNewer(c.ver, chrome.runtime.getManifest().version) ? { ver: c.ver, page: c.page, note: c.note } : null }; }
    if (msg.type === 'logout') { await chrome.storage.local.remove(['token', 'acct']); return { ok: true }; }
    if (msg.type === 'exclOpen') { const g = await gate(); if (g) return g; return exclOpen(msg.ids); }
    if (msg.type === 'collect') { const tab = msg.tabId ? await chrome.tabs.get(msg.tabId) : (sender.tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0]); return collect(tab.id, tab.url, msg.n || 10); }
    if (msg.type === 'claim') {   // перед заполнением ДомКлика: занять объявление в общей базе (и проверить лимит)
      const it = (await getQueue()).find(x => x.id === msg.id); if (!it) return { st: 'gone' };
      const r = await api('ext_take', { src: it.src || srcOf(it), target: 'domclick', title: it.title });
      if (r.st) { const a = await account(false); if (a.ok && r.used != null) await chrome.storage.local.set({ acct: { ...a, used: r.used } }); }
      return r;
    }
    if (msg.type === 'release') { const it = (await getQueue()).find(x => x.id === msg.id); if (it) await api('ext_release', { src: it.src || srcOf(it) }); return { ok: true }; }
    if (msg.type === 'drafted') { const it = (await getQueue()).find(x => x.id === msg.id); if (it) await api('ext_draft', { src: it.src || srcOf(it), draft: msg.draft }); return { ok: true }; }
    if (msg.type === 'full') {   // светлое объявление Авито (из списка) — прочитать полностью в фоновой вкладке
      const it = (await getQueue()).find(x => x.id === msg.id); if (!it) return { ok: false, error: 'объявление убрано из списка' };
      if (!it.light) return { ok: true };
      const r = await grabUrl(it.url);
      return r.ok ? { ok: true } : r;
    }
    if (msg.type === 'collectSite') {
      const tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      return collectSite(msg.tabId || tab.id, msg.n || 10);
    }
    if (msg.type === 'avitoLinks') {
      const tabId = msg.tabId || sender.tab?.id || (await chrome.tabs.query({ active: true, currentWindow: true }))[0].id;
      const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: extractAvitoLinks });
      return result || { error: 'страница не ответила' };
    }
    if (msg.type === 'grabUrl') return grabUrl(msg.url);
    if (msg.type === 'batchStart') return batchStart(msg.n || 10);
    if (msg.type === 'batchNext') return batchNext(msg.res || {});
    if (msg.type === 'batchStop') { const b = await getBatch(); if (b) { b.stop = true; b.done = true; await chrome.storage.local.set({ batch: b }); } await chrome.storage.local.remove('job'); return { ok: true }; }
    if (msg.type === 'photo') return PHOTO_HOSTS.test(msg.url) ? photo(msg.url) : { ok: false };
    if (msg.type === 'toDomclick') {
      { const g = await gate(); if (g) return g; }
      const q = await getQueue();
      const it = q.find(x => x.id === msg.id);
      if (!it) return { ok: false, error: 'Объявление не найдено' };
      if (!DA.SOURCES[it.source]?.targets.includes('domclick')) return { ok: false, error: 'Это объявление переносится только файлом на сайт «Для Агента».' };
      await chrome.storage.local.set({ job: { id: it.id, stage: 'start', at: Date.now() } });
      await chrome.tabs.create({ url: 'https://my.domclick.ru/offers/new' });
      return { ok: true };
    }
    return { ok: false, error: 'неизвестная команда' };
  })().then(reply, e => reply({ ok: false, error: String(e?.message || e) }));
  return true;
});
