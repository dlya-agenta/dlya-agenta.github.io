// Кнопки «Для Агента» на страницах:
//  • объявление Авито / Циан — «⇪ Для Агента» (одно объявление);
//  • профиль Авито («Мои объявления», /user/, /brands/) и сайт «Для Агента» — «взять 3 · 10 · 20 · 30» (пачкой).
// Авито пачкой читается по одному объявлению с паузой (по умолчанию 30 с) — иначе блок по IP.
(() => {
  const clean = u => u.split(/[?#]/)[0];
  const isItem = u => { u = clean(u); return /^https:\/\/(www\.)?avito\.ru\/.+_\d{6,}\/?$/.test(u) || /^https:\/\/([a-z-]+\.)?cian\.ru\/sale\/flat\/\d+\/?$/.test(u); };
  const listOf = url => { const u = url.split('#')[0];
    if (/^https:\/\/web\.ygroup\.ru\/app\/profile/.test(u)) return 'vt';
    if (/^https:\/\/dlya-agenta\.github\.io\/(index\.html)?(\?|$)/.test(u)) return 'site';
    if (/^https:\/\/(www\.)?avito\.ru\//.test(u) && !/_\d{6,}\/?(\?|$)/.test(u) && /\/(profile|user\/|brands\/)|\/kvartiry/.test(u)) return 'avito';
    if (/^https:\/\/([a-z-]+\.)?cian\.ru\//.test(u) && !/\/sale\/flat\/\d+/.test(u) && /cat\.php|kupit|prodazha|\/company\/|\/agents?\//.test(u)) return 'cian';
    return null; };
  const SIZES = [3, 10, 20, 30];
  const esc = s => String(s ?? '').replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
  const sleep = ms => new Promise(s => setTimeout(s, ms));
  // на сайте «Для Агента» справа внизу — его окна (оповещения, ИИ-Агент): значок — слева, чтобы не мешать
  const side = location.hostname === 'dlya-agenta.github.io' ? 'left:18px;' : 'right:18px;';
  const css = `position:fixed;${side}bottom:18px;z-index:2147483646;font:14px/1.35 -apple-system,Segoe UI,Roboto,sans-serif;`;
  let settings = {};
  function toast(html, ms = 7000) {
    const t = document.createElement('div'); t.dataset.da = '1';
    t.style.cssText = css + 'bottom:80px;max-width:330px;background:#fff;color:#121722;border:0;border-radius:14px;padding:10px 12px;box-shadow:0 1px 2px rgba(16,24,40,.06),0 8px 24px rgba(16,24,40,.18)';
    t.innerHTML = html; document.body.appendChild(t);
    if (ms) setTimeout(() => t.remove(), ms);
    return t;
  }
  const send = async m => { try { return await chrome.runtime.sendMessage(m); } catch (e) { return { ok: false, error: 'Расширение обновилось — обновите страницу.' }; } };

  // ---------- один значок «Для Агента»: счётчики и меню (взять · перенести) ----------
  const SITE_C = { head: '#0f1b2d', acc: '#1453d8', ok: '#138a4a', gold: '#f5c518' };
  let fab = null, menu = null, counts = { dc: 0, ex: 0 };
  const gateHtml = r => r?.gate ? `<br><a href="${esc(r.login ? 'https://dlya-agenta.github.io/' : (r.pay || 'https://dlya-agenta.github.io/pay.html?plan=sub'))}" target="_blank" style="color:#0f3fa6;font-weight:600">${r.login ? 'Войти в «Для Агента»' : 'Оформить подписку'}</a>` : '';
  const chip = (label, attrs, main) => `<button ${attrs} style="border:0;border-radius:10px;padding:6px 10px;margin:2px;cursor:pointer;font:600 12.5px -apple-system,Segoe UI,Roboto,sans-serif;${main ? `background:${SITE_C.acc};color:#fff` : 'background:#eef3fd;color:#1453d8'}">${label}</button>`;
  async function refreshCounts() {
    const { queue = [] } = await chrome.storage.local.get('queue');
    counts.dc = queue.filter(x => x.on !== false && !x.domclick?.ok && ['avito', 'site'].includes(x.source)).length;
    counts.ex = queue.filter(x => x.on !== false && ['cian', 'vt'].includes(x.source) && !x.exclAt).length;
    if (fab) fab.querySelector('[data-n]').textContent = counts.dc + counts.ex || '';
    if (fab) fab.querySelector('[data-n]').style.display = counts.dc + counts.ex ? 'grid' : 'none';
  }
  function mountFab() {
    if (fab) return;
    const vt = listOf(location.href) === 'vt';
    fab = document.createElement('button'); fab.dataset.da = '1';
    fab.title = 'Для Агента — перенос объявлений';
    fab.style.cssText = css + `width:48px;height:48px;border-radius:50%;border:0;padding:0;cursor:pointer;background:${SITE_C.head};box-shadow:0 4px 16px rgba(15,27,45,.35)${vt ? `,0 0 0 3px ${SITE_C.gold}` : ''};display:grid;place-items:center;opacity:.92`;
    fab.innerHTML = `<img src="${chrome.runtime.getURL('icons/48.png')}" alt="" style="width:30px;height:30px;border-radius:8px">
      <span data-n style="position:absolute;top:-4px;right:-4px;min-width:20px;height:20px;border-radius:10px;background:${SITE_C.acc};color:#fff;font:700 11px/20px -apple-system,Segoe UI,Roboto,sans-serif;display:none;place-items:center;padding:0 5px;border:2px solid #fff"></span>`;
    if (vt && !document.getElementById('da-pulse')) { const st = document.createElement('style'); st.id = 'da-pulse'; st.textContent = `@keyframes daPulse{0%,100%{box-shadow:0 4px 16px rgba(15,27,45,.35),0 0 0 3px ${SITE_C.gold}}50%{box-shadow:0 4px 16px rgba(15,27,45,.35),0 0 0 8px rgba(245,197,24,.4)}}`; document.head.appendChild(st); }
    if (vt) fab.style.animation = 'daPulse 2.2s ease-in-out infinite';
    fab.onmouseenter = () => { fab.style.opacity = '1'; }; fab.onmouseleave = () => { fab.style.opacity = '.92'; };
    fab.onclick = e => { e.stopPropagation(); menu ? closeMenu() : openMenu(); };
    document.body.appendChild(fab);
    refreshCounts();
  }
  function closeMenu() { menu?.remove(); menu = null; }
  function openMenu() {
    closeMenu();
    const kind = listOf(location.href), item = isItem(location.href), def = +settings.batchSize || 10;
    menu = document.createElement('div'); menu.dataset.da = '1';
    menu.style.cssText = css + 'bottom:76px;width:300px;background:#fff;color:#121722;border-radius:14px;box-shadow:0 1px 2px rgba(16,24,40,.06),0 10px 30px rgba(16,24,40,.22);overflow:hidden';
    let body = '';
    if (item) body += `<div style="padding:8px 10px">${chip('⇪ Взять это объявление', 'data-grab', true)}</div>`;
    if (kind === 'vt') body += `<div style="padding:8px 10px;background:#fff8dc"><b>💎 Перенести свои Эксклюзивы ВТОРИЧЕК</b><br>${[3, 10, 20, 30, 'all'].map(n => chip(n === 'all' ? 'все' : n, `data-vt="${n}"`, n === 3)).join('')}</div>`;
    else if (kind) body += `<div style="padding:8px 10px"><b>Взять со страницы</b>${kind === 'cian' ? '<div style="color:#b7791f;font-size:11.5px">С Циана — только в Эксклюзивы (логотипы на фото)</div>' : ''}<br>${DA_SIZES.map(n => chip(n, `data-n2="${n}"`, n === def)).join('')}</div>`;
    body += `<div style="padding:8px 10px;border-top:1px solid rgba(18,23,34,.08)">${chip(`✈ В ДомКлик (${counts.dc})`, 'data-dc', false)}${chip(`💎 В Эксклюзивы (${counts.ex})`, 'data-ex', false)}</div>`;
    menu.innerHTML = `<div style="background:${SITE_C.head};color:#fff;padding:8px 12px;font:16px Prata,Georgia,serif;white-space:nowrap">Для Агента</div>${body}<div style="padding:0 12px 8px;color:#6b7280;font-size:11px">Лишнее снимите в окне расширения (значок на панели браузера)</div>`;
    menu.onclick = e => e.stopPropagation();
    document.body.appendChild(menu);
    menu.querySelector('[data-grab]')?.addEventListener('click', grabOne);
    menu.querySelectorAll('[data-n2]').forEach(b => b.onclick = () => { closeMenu(); collect(kind, +b.dataset.n2); });
    menu.querySelectorAll('[data-vt]').forEach(b => b.onclick = () => { closeMenu(); collectVt(b.dataset.vt === 'all' ? 'all' : +b.dataset.vt); });
    menu.querySelector('[data-dc]').onclick = async () => { closeMenu(); const r = await send({ type: 'batchStart', n: def }); if (!r?.ok) toast('⚠️ ' + esc(r?.error || 'Не получилось') + gateHtml(r), 9000); };
    menu.querySelector('[data-ex]').onclick = async () => { closeMenu(); const r = await send({ type: 'exclOpen' }); if (!r?.ok) toast('⚠️ ' + esc(r?.error || 'Не получилось') + gateHtml(r), 9000); };
  }
  document.addEventListener('click', () => closeMenu());
  const DA_SIZES = SIZES;
  async function grabOne() {
    closeMenu();
    const t = toast('Читаю объявление…', 0);
    const r = await send({ type: 'grab' });
    if (!r?.ok) { t.innerHTML = '⚠️ ' + esc(r?.error || 'Не получилось') + gateHtml(r); setTimeout(() => t.remove(), 10000); return; }
    const it = r.item;
    t.innerHTML = `<b>${r.updated ? 'Обновлено' : 'Взято'}:</b> ${esc(it.title)}<br>${it.price ? it.price.toLocaleString('ru') + ' ₽ · ' : ''}фото: ${it.photos}${(it.notes || []).map(n => `<br><span style="color:#b7791f">• ${esc(n)}</span>`).join('')}`;
    setTimeout(() => t.remove(), 8000); refreshCounts();
  }
  async function collect(kind, n) {
    const t = toast('Беру объявления со страницы…', 0);
    const r = await send({ type: 'collect', n });
    if (!r?.ok) { t.innerHTML = '⚠️ ' + esc(r?.error || 'Не получилось') + gateHtml(r); setTimeout(() => t.remove(), 10000); return; }
    t.innerHTML = `✓ Взято: <b>${r.added}</b>${r.filtered ? ` · не подошли под фильтр: ${r.filtered}` : ''}${r.taken ? ` · уже выставили другие: ${r.taken}` : ''}${r.already ? ` · уже в списке: ${r.already}` : ''}${r.short ? '<br><span style="color:#b7791f">подходящих меньше — откройте следующую страницу</span>' : ''}`;
    setTimeout(() => t.remove(), 8000); refreshCounts();
  }
  async function collectVt(n) {
    const t = toast('Беру ваши объявления из профиля…', 0);
    const r = await send({ type: 'collect', n });
    if (!r?.ok) { t.innerHTML = '⚠️ ' + esc(r?.error || 'Не получилось') + gateHtml(r); setTimeout(() => t.remove(), 10000); return; }
    if (!r.ids?.length) { t.innerHTML = `Подходящих объявлений нет${r.filtered ? ` (не подошли под фильтр: ${r.filtered})` : ''}.`; setTimeout(() => t.remove(), 8000); return; }
    t.innerHTML = `✓ Взято ${r.ids.length}${r.filtered ? ` · не подошли под фильтр: ${r.filtered}` : ''}. Готовлю файл — откроется вкладка расширения…`;
    const x = await send({ type: 'exclOpen', ids: r.ids });
    if (!x?.ok) t.innerHTML = '⚠️ ' + esc(x?.error || 'Не получилось');
    setTimeout(() => t.remove(), 8000); refreshCounts();
  }
  chrome.storage.onChanged.addListener(ch => { if (ch.queue) refreshCounts(); });
  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m.type === 'collectHere') { collect(listOf(location.href), m.n); reply({ ok: true }); }
  });

  // значок — на объявлениях и списках площадок, в своём профиле вторичек; на сайте «Для Агента» — только если там список (не мешает его кнопкам)
  function remount() {
    closeMenu();
    const need = settings.floatingButton !== false && (isItem(location.href) || !!listOf(location.href));
    if (!need && fab) { fab.remove(); fab = null; }
    if (need && fab && (listOf(location.href) === 'vt') !== !!fab.style.animation) { fab.remove(); fab = null; }
    if (need) mountFab();
  }
  // вход: сайт «Для Агента» хранит токен в localStorage — расширение берёт его (вход на сайте — через бота)
  if (location.hostname === 'dlya-agenta.github.io') {
    const sync = () => { try { const tk = JSON.parse(localStorage.getItem('token') || 'null'); if (tk) send({ type: 'setToken', token: tk }); } catch (e) {} };
    sync(); setInterval(sync, 5000);
    // v0.7: сайт видит, что в этом браузере есть расширение (выбор «Через мой браузер»), и просит забрать задание сразу
    document.documentElement.dataset.daExt = chrome.runtime.getManifest().version;
    window.addEventListener('message', e => { if (e.origin === location.origin && e.data?.da === 'sendPoll') send({ type: 'sendPoll' }); });   // и из окна ИИ-Агента (iframe того же сайта)
  }
  chrome.storage.local.get('settings').then(({ settings: s }) => {
    settings = s || {};
    remount();
    let last = location.href;
    setInterval(() => { if (location.href !== last) { last = location.href; remount(); } }, 1500);
  });
})();
