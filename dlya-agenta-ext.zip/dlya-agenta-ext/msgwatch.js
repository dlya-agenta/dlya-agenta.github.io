// Обращения клиентов → бот «Для Агента». Работает на открытых вкладках ДомКлика, Авито, Циана (лучше закрепить вкладки сообщений).
// Признаки: счётчик в заголовке вкладки «(3) …» вырос; всплыло уведомление о новом сообщении. Своих окон расширения (data-da) не трогаем.
(() => {
  const site = /domclick\.ru$/.test(location.hostname) ? 'domclick' : /avito\.ru$/.test(location.hostname) ? 'avito' : /cian\.ru$/.test(location.hostname) ? 'cian' : null;
  if (!site || window.top !== window) return;
  const send = m => chrome.runtime.sendMessage({ type: 'clientMsg', site, url: location.href, ...m }).catch(() => {});
  const WORDS = /(нов\S* сообщени|написал|написала|обращени|откликнул|сообщение от|вам пишут|новый вопрос|ответил[аи]? в чат|непрочитанн)/i;
  const MSGURL = { domclick: 'https://my.domclick.ru/chat', avito: 'https://www.avito.ru/profile/messenger', cian: 'https://my.cian.ru/chats' };

  // 1) счётчик в заголовке
  let lastN = null;
  const titleN = () => { const m = document.title.match(/^\((\d+)\)|(\d+)\s+(?:нов|непрочит)/i); return m ? +(m[1] || m[2]) : 0; };
  const checkTitle = () => {
    const n = titleN();
    if (lastN !== null && n > lastN) send({ count: n, text: '', url: MSGURL[site] });
    lastN = n;
  };
  new MutationObserver(checkTitle).observe(document.querySelector('title') || document.head, { childList: true, subtree: true, characterData: true });
  setInterval(checkTitle, 15000);

  // 2) всплывающие уведомления (тосты) с текстом о новом сообщении
  const seen = new WeakSet();
  const isToast = el => {
    if (!(el instanceof HTMLElement) || el.closest('[data-da]') || seen.has(el)) return false;
    const t = (el.innerText || '').trim();
    if (t.length < 8 || t.length > 400 || !WORDS.test(t)) return false;
    const cs = getComputedStyle(el), r = el.getBoundingClientRect();
    const floating = /fixed|sticky/.test(cs.position) || el.closest('[role="alert"],[role="status"],[aria-live],[class*="toast" i],[class*="notif" i],[class*="snack" i],[class*="push" i]');
    return !!floating && r.width > 120 && r.height > 24 && r.height < 300;
  };
  new MutationObserver(muts => {
    for (const m of muts) for (const n of m.addedNodes) {
      if (!(n instanceof HTMLElement)) continue;
      const cand = [n, ...n.querySelectorAll('[role="alert"],[role="status"],[aria-live],[class*="toast" i],[class*="notif" i],[class*="snack" i]')].find(isToast);
      if (!cand) continue;
      seen.add(cand);
      const lines = cand.innerText.split('\n').map(s => s.trim()).filter(Boolean);
      const link = cand.querySelector('a[href]')?.href;
      send({ from: lines.length > 1 ? lines[0].slice(0, 80) : '', text: (lines.length > 1 ? lines.slice(1) : lines).join(' ').slice(0, 300), url: link || MSGURL[site], count: titleN() });
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
