// v0.7 (сайт v5.67, п. 2 Алексея): «Отправка через мой браузер» — расширение работает как свой сервер мессенджеров агента.
// Агент сам вошёл в WhatsApp Web / Telegram Web в этом браузере; ключи входа остаются в браузере, на сервер не передаются.
// Сайт (с компьютера или с телефона) ставит задание: auto own_send {via: 'ext'} / own_ext_msg. Расширение раз в минуту отмечается
// (own_ext_poll: «на связи» + где выполнен вход), берёт СВОЁ задание и шлёт по одному сообщению с паузой 25–60 с (как сервер),
// отчитывается own_ext_sent / own_ext_done; проверки ответов собственников — own_ext_read (чтение чата по номеру, ничего не пишет).
// Компьютер и браузер должны быть включены; вкладки мессенджеров расширение открывает само (закреплённые, в фоне).
// MAX (web.max.ru) — поиск по номеру: пишем, только если нашёлся ровно один человек (иначе — пропуск, чтобы не написать не тому).
const AUTO = 'https://arojogajdamsyrrpcmso.supabase.co/functions/v1/auto';
const MSGR = {
  wa: { url: 'https://web.whatsapp.com/', match: 'https://web.whatsapp.com/*', title: 'WhatsApp' },
  tg: { url: 'https://web.telegram.org/k/', match: 'https://web.telegram.org/*', title: 'Telegram' },
  max: { url: 'https://web.max.ru/', match: 'https://web.max.ru/*', title: 'MAX' },
};
const sleepS = ms => new Promise(s => setTimeout(s, ms));
// v0.7.3: «приметы» страниц мессенджеров (поля, кнопки, надписи) — с сайта (ext-config.json, раз в 30 минут), здесь — запасные.
// Мессенджер поменял кнопку — правим файл на сайте, у всех агентов работает через несколько минут без переустановки. Код с сайта не грузится (правило Chrome).
const CFG0 = {
  wa: { ok: '#side, #pane-side, [data-testid="chat-list"]', qr: 'canvas[aria-label*="QR" i], [data-ref] canvas, [data-testid="qrcode"]',
    authText: 'Используйте WhatsApp на телефоне|Use WhatsApp on your phone|Войти по номеру|Log in with phone', badText: 'недействител|invalid|не зарегистрирован|isn.t on WhatsApp',
    box: '#main footer div[contenteditable="true"]', send: '#main footer button[aria-label="Отправить"], #main footer button[aria-label="Send"], #main footer span[data-icon="send"], #main footer span[data-icon="wds-ic-send-filled"]',
    previewSend: '[aria-label*="выбранный объект"], [aria-label*="выбранных объект"], [aria-label*="selected item"], div[role="button"][aria-label="Отправить"], div[role="button"][aria-label="Send"], span[data-icon="wds-ic-send-filled"], span[data-icon="send"]',
    attach: 'button[aria-label="Прикрепить"], button[aria-label="Attach"]', photoBtn: 'button[aria-label="Фото и видео"], button[aria-label="Photos & videos"]',
    // 12.11: классов message-in/out больше нет — сообщение = [data-id] в чате, своё — с отметкой доставки
    // v0.7.30: фото внутренними функциями WhatsApp Web (без редактора и без показа вкладки) — имена модулей загрузчика страницы;
    // поменялись — правим ext-config.json; не нашлись по имени — ищем по экспортам (prepRawMedia, createFromData, findOrCreateLatestChat, createWid)
    intOn: '1', intWid: 'WAWebWidFactory', intFind: 'WAWebFindChatAction', intOd: 'WAWebMediaOpaqueData', intPrep: 'WAWebPrepRawMedia',
    msgs: '#main [data-id]', outLabel: 'Доставлено|Прочитано|Отправлено|Ожидает|Delivered|Read|Sent|Pending|^ *Вы:', pre: '[data-pre-plain-text]', text: 'span.selectable-text, .copyable-text span' },
  tg: { auth: '.auth-pages, #auth-pages, .page-signQR, .page-sign' },
  max: { search: 'input[placeholder="Найти"], input[placeholder="Найти чат или канал"], input[placeholder^="Поиск"]', authText: 'Войти|номер телефона|QR|Отсканируйте',
    allTab: '^Все(\\s|$)', findByPhone: 'Найти по номеру', notFound: 'не найден|не зарегистрирован|нет в MAX|Пользователь не найден',
    items: '.scrollable .item', cells: '.scrollable .item button.cell', composer: 'main div.contenteditable, div.contenteditable[data-placeholder="Сообщение"], main [contenteditable="true"]',
    dialogComposer: '[role="dialog"] div.contenteditable, [role="dialog"] [contenteditable="true"]', sendBtn: 'button[aria-label*="Отправить"], button[title*="Отправить"]',
    msgItems: 'main .item[data-index]', bubble: '.bubble' },
};
const CFG_URL = 'https://dlya-agenta.github.io/ext-config.json';
// «0.8.0» новее «0.7.10»: по числам
const verNewer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function cfg() {
  const { extCfg = null } = await chrome.storage.local.get('extCfg');
  if (extCfg && Date.now() - extCfg.at < 30 * 60e3) return extCfg.v;
  let v = extCfg?.v || null;
  try { const r = await fetch(CFG_URL + '?t=' + Math.floor(Date.now() / 6e5), { cache: 'no-store' }); if (r.ok) { const j = await r.json(); if (j && typeof j === 'object') v = j; } } catch { /* сайт недоступен — прежние */ }
  // не получили — не запоминаем «пусто» на 30 минут (12.11: после обновления настройки не подтянулись): попробуем на следующем такте
  if (v) await chrome.storage.local.set({ extCfg: { at: Date.now(), v } });
  return v;
}
// для мессенджера: запасные + с сайта (только строки — это данные, не код)
async function C(svc) {
  const site = (await cfg())?.[svc] || {}, out = { ...CFG0[svc] };
  for (const [k, v] of Object.entries(site)) if (typeof v === 'string' && v.length < 600) out[k] = v;
  return out;
}
async function autoApi(action, extra = {}) {
  const { token } = await chrome.storage.local.get('token');
  if (!token) return { error: 'no_auth' };
  try {
    const r = await fetch(AUTO, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, auth: { token }, ...extra }) });
    return await r.json().catch(() => ({ error: 'server' }));
  } catch { return { error: 'net' }; }
}
const sendOn = async () => (await DA.getSettings()).sendVia !== false;

// ---- вкладка мессенджера: уже открытая или новая закреплённая в фоне ----
// v0.7.22 (работа в фоне): Chrome «Экономия памяти» выгружает фоновые вкладки — выгруженная вкладка не отвечает на скрипты
// («Telegram не загрузился»). Вкладкам мессенджеров ставим autoDiscardable:false, а уже выгруженную — перезагружаем.
async function msgTab(svc, open = true) {
  let [t] = await chrome.tabs.query({ url: MSGR[svc].match });
  if (t && !open) return t;
  if (t) {
    if (t.autoDiscardable !== false) await chrome.tabs.update(t.id, { autoDiscardable: false }).catch(() => null);
    if (t.discarded || t.status === 'unloaded') { await chrome.tabs.reload(t.id).catch(() => null); await sleepS(1000); await tabLoaded(t.id); t = await chrome.tabs.get(t.id).catch(() => t); }
    return t;
  }
  if (!open) return null;
  // окно Chrome могло быть закрыто (на Mac браузер работает без окон) — тогда своё окно, свёрнутое и без фокуса
  const n = await chrome.tabs.create({ url: MSGR[svc].url, active: false, pinned: true })
    .catch(async () => (await chrome.windows.create({ url: MSGR[svc].url, focused: false, state: 'minimized' })).tabs[0]);
  await chrome.tabs.update(n.id, { autoDiscardable: false }).catch(() => null);
  await tabLoaded(n.id);
  return n;
}
async function tabLoaded(tabId, ms = 45000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return false; if (t.status === 'complete') return true; await sleepS(700); }
  return false;
}
// пользователь сейчас сам в этой вкладке (активна в окне с фокусом) — переходить в ней на другой чат нельзя: уведём его переписку
async function userIn(tabId) {
  const t = await chrome.tabs.get(tabId).catch(() => null); if (!t?.active) return false;
  const w = await chrome.windows.get(t.windowId).catch(() => null);
  return !!(w?.focused && w.state !== 'minimized');
}
// сторож: страница «замёрзла» (Chrome замораживает фоновые вкладки) — шаг не ждёт вечно; после сторожа старые шаги не продолжаются
let STOP = false;
const run = async (tabId, func, args = [], ms = 30000) => {
  if (STOP) throw new Error('stopped');
  const go = chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args }).then(([{ result } = {}]) => result, e => ({ e: String(e?.message || e) }));
  return await Promise.race([go, sleepS(ms).then(() => ({ e: 'timeout' }))]);
};

// вход в мессенджер (в странице): ok | auth (нужен вход: QR / телефон) | wait
function pageState(svc, c, act) {
  if (svc === 'max') {
    if (document.querySelector(c.search)) return 'ok';
    return new RegExp(c.authText, 'i').test(document.body?.innerText || '') && !document.querySelector(c.items) ? 'auth' : 'wait';
  }
  if (svc === 'tg') { const R = window.rootScope; if (R && R.managers && R.myId) return 'ok'; return localStorage.getItem('user_auth') ? 'wait' : (document.querySelector(c.auth) ? 'auth' : 'wait'); }
  // WhatsApp открыт в другой вкладке/окне — «Использовать здесь» (у агента бывает, если открыл WhatsApp где-то ещё)
  const here = [...document.querySelectorAll('button, [role="button"]')].find(b => new RegExp(c.useHere || 'Использовать здесь|Use here', 'i').test((b.innerText || '').trim()));
  if (here) { if (act) { here.click(); return 'wait'; } return 'other'; }   // нажимаем только при отправке, не при проверке связи
  if (document.querySelector(c.ok)) return 'ok';
  if (document.querySelector(c.qr)) return 'auth';
  return new RegExp(c.authText, 'i').test(document.body?.innerText || '') ? 'auth' : 'wait';
}
async function ready(svc, tabId, ms = 60000) {
  const t0 = Date.now(); let st = 'wait';
  const c = await C(svc);
  while (Date.now() - t0 < ms) { st = await run(tabId, pageState, [svc, c, true]); if (st === 'ok' || (st === 'auth' && Date.now() - t0 > 12000)) break; await sleepS(1500); }
  await remember(svc, st === 'ok' ? 'ok' : st === 'auth' ? 'auth' : null);
  return st;
}
async function remember(svc, st) {
  if (!st) return;
  const { msgLogin = {} } = await chrome.storage.local.get('msgLogin');
  msgLogin[svc] = { st, at: Date.now() }; await chrome.storage.local.set({ msgLogin });
}
// где выполнен вход — для сайта («Через мой браузер: WhatsApp ✓, Telegram — войдите»): открытая вкладка проверяется, иначе — последнее известное (7 дней)
async function loginStates() {
  const { msgLogin = {} } = await chrome.storage.local.get('msgLogin'), out = {};
  for (const svc of Object.keys(MSGR)) {
    const t = await msgTab(svc, false);
    if (t?.status === 'complete') { const st = await run(t.id, pageState, [svc, await C(svc)]); if (st === 'ok' || st === 'auth') { await remember(svc, st); out[svc] = st; continue; } }
    const m = msgLogin[svc]; out[svc] = m && Date.now() - m.at < 7 * 864e5 ? m.st : 'none';
  }
  return out;
}

// ---- Telegram Web K: контакт по номеру → фото с подписью / текст (тот же способ, что на сервере, worker/msg.ts tgToPhone) ----
async function tgSendPage(phone, name, text, photo) {
  const M = window.rootScope.managers; let id = 0;
  try {
    try { const r = await M.apiManager.invokeApi('contacts.importContacts', { contacts: [{ _: 'inputPhoneContact', client_id: String(Date.now()), phone, first_name: name || 'Собственник', last_name: '' }] });
      if (r && r.users && M.appUsersManager.saveApiUsers) await M.appUsersManager.saveApiUsers(r.users);
      id = r && r.imported && r.imported[0] ? r.imported[0].user_id : 0; }
    catch (e) { id = await M.appUsersManager.importContact(name || 'Собственник', '', phone).catch(() => 0); }
    if (!id) return 'NOUSER: номера нет в Telegram';
    let file = null;
    if (photo) { try { file = new File([Uint8Array.from(atob(photo), c => c.charCodeAt(0))], 'photo.jpg', { type: 'image/jpeg' }); } catch (e) { /* без фото */ } }
    let warn = photo && !file ? 'без фото: файл не собрался' : '';
    if (file) { try { if (text.length > 1000) await M.appMessagesManager.sendFile({ peerId: Number(id), file, isMedia: true });
      else { await M.appMessagesManager.sendFile({ peerId: Number(id), file, caption: text, isMedia: true }); return ''; } }
      catch (e) { const t = String(e && (e.type || e.message)); if (/FLOOD|SPAM|RESTRICTED/.test(t)) throw e; warn = 'без фото: ' + t.slice(0, 80); } }
    await M.appMessagesManager.sendText({ peerId: Number(id), text });
    return warn ? { warn } : '';
  } catch (e) { const t = String((e && (e.type || e.message)) || e || 'ошибка'); return /FLOOD|SPAM|RESTRICTED/.test(t) ? 'FLOOD: ' + t : t; }
}
async function tgReadPage(phone) {
  const M = window.rootScope.managers, digits = phone.replace(/\D/g, ''); let id = 0;
  try {
    try { const x = await M.apiManager.invokeApi('contacts.resolvePhone', { phone: digits });
      if (x && x.users && M.appUsersManager.saveApiUsers) await M.appUsersManager.saveApiUsers(x.users);
      id = x && x.peer && x.peer.user_id ? x.peer.user_id : (x && x.users && x.users[0] ? x.users[0].id : 0); }
    catch (e) { const t = String(e && (e.type || e.message)); if (/AUTH_KEY|SESSION_REVOKED|FLOOD/.test(t)) return { e: t }; }
    if (!id) return { e: 'NOUSER: нет переписки в Telegram' };
    const peerId = Number(id), h = await M.appMessagesManager.getHistory({ peerId, limit: 30 }), out = [];
    for (const mid of (h.history || []).slice(0, 30)) { const m = await M.appMessagesManager.getMessageByPeer(peerId, mid); if (!m || m._ === 'messageService') continue;
      const t = String(m.message || '').trim() || (m.media ? (m.media._ === 'messageMediaPhoto' ? '[фото]' : '[файл]') : ''); if (!t) continue;
      out.push({ who: m.pFlags && m.pFlags.out ? 'me' : 'owner', text: t.slice(0, 1000), at: new Date((m.date || 0) * 1000).toISOString() }); }
    return { msgs: out.sort((a, b) => a.at < b.at ? -1 : 1) };
  } catch (e) { return { e: String((e && (e.type || e.message)) || e || 'ошибка') }; }
}

// ---- v0.7.4: страница делает только мгновенные шаги (без своих таймеров), все ожидания — в расширении ----
// Причина (проверка 12.11 на компьютере Алексея): во вкладке, которая несколько минут в фоне, Chrome выполняет таймеры страницы раз в минуту —
// ожидания внутри страницы растягивались на минуты, и Chrome обрывал работу расширения. Таймеры расширения так не замедляются.
function pg(op, a, c) {
  const q = s => document.querySelector(s), norm = t => String(t || '').replace(/\s+/g, ' ').trim();
  const file = b64 => { const dt = new DataTransfer(); dt.items.add(new File([Uint8Array.from(atob(b64), ch => ch.charCodeAt(0))], 'photo.jpg', { type: 'image/jpeg' })); return dt; };
  const type = (el, text) => { el.focus(); String(text).split('\n').forEach((l, i) => { if (i) document.execCommand('insertLineBreak'); if (l) document.execCommand('insertText', false, l); }); };
  try {
    // WhatsApp
    if (op === 'wa_open') { const dlg = q('[role="dialog"]'); if (dlg && new RegExp(c.badText, 'i').test(dlg.innerText || '')) return 'bad'; return q(c.box) ? 'ok' : 'wait'; }
    // число сообщений на странице не растёт (WhatsApp держит в памяти часть чата, 16 → 15 после отправки) — новое = сменилось последнее
    if (op === 'wa_state') { const all = document.querySelectorAll(c.msgs); return { n: all.length, last: all.length ? all[all.length - 1].getAttribute('data-id') : '', box: norm(q(c.box)?.innerText) }; }
    // фото (12.11, проверено на компьютере Алексея): «+» → «Фото и видео» создаёт поле файла и открывает окно выбора — расширение
    // подменяет это окно и подставляет файл; видимое поле image/* на странице — для СТИКЕРОВ (фото уходило стикером)
    if (op === 'wa_attach') { const b = q(c.attach); if (!b) return 'nobtn'; b.click(); return 'clicked'; }
    if (op === 'wa_photo') { const b = q(c.photoBtn); if (!b) return 'nobtn'; const dt = file(a.pic), orig = HTMLInputElement.prototype.click;
      HTMLInputElement.prototype.click = function () { if (this.type === 'file') { HTMLInputElement.prototype.click = orig; this.files = dt.files; this.dispatchEvent(new Event('change', { bubbles: true })); return; } return orig.call(this); };
      setTimeout(() => { if (HTMLInputElement.prototype.click !== orig) HTMLInputElement.prototype.click = orig; }, 5000);
      b.click(); return 'ok'; }
    // переносы строк — Shift+Enter (insertLineBreak WhatsApp игнорирует: «строка 1строка 2»)
    if (op === 'wa_caption') { const cap = [...document.querySelectorAll('[contenteditable="true"]')].find(e => !e.closest('footer')); if (!cap) return 'nocap'; cap.focus();
      String(a.text).split('\n').forEach((l, i) => { if (i) cap.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, shiftKey: true, bubbles: true, cancelable: true })); if (l) document.execCommand('insertText', false, l); });
      return 'ok'; }
    // предпросмотр фото открылся (кнопка «Отправить 1 выбранный объект» вне поля сообщения) — только смотрит
    if (op === 'wa_pv') return [...document.querySelectorAll(c.previewSend)].some(x => !x.closest('footer'));
    if (op === 'wa_preview') { const b = [...document.querySelectorAll(c.previewSend)].find(x => !x.closest('footer')); if (!b) return 'wait'; (b.closest('[role="button"], button') || b).click(); return 'ok'; }
    if (op === 'wa_send') { const b = q(c.send); if (!b) return 'nobtn'; (b.closest('button') || b).click(); return 'ok'; }
    if (op === 'wa_read') return [...document.querySelectorAll(c.msgs)].slice(-30).map(e => {
      const x = e.querySelector(c.pre), t = e.querySelector(c.text);
      const out = [...e.querySelectorAll('[aria-label]')].some(i => new RegExp(c.outLabel, 'i').test(i.getAttribute('aria-label') || ''));
      return { out, pre: x?.getAttribute('data-pre-plain-text') || '', t: String(t?.innerText || '').trim(), media: !!e.querySelector('img, video') }; });
    // MAX
    const input = () => q(c.search);
    const set = v => { const s = input(); if (!s) return; Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(s, v); s.dispatchEvent(new Event('input', { bubbles: true })); };
    if (op === 'mx_tab') { const all = [...document.querySelectorAll('button, a, [role="tab"]')].find(b => new RegExp(c.allTab).test((b.innerText || '').trim())); if (all) all.click(); return 'ok'; }
    // вкладка «Все» перерисовывает поле поиска и стирает номер — поэтому сначала mx_tab, пауза, потом ввод (и проверка, что номер в поле)
    if (op === 'mx_search') { if (!input()) return 'nosearch'; input().focus(); set(a.phone); return location.pathname; }
    if (op === 'mx_val') return input()?.value || '';
    // «Найти по номеру» — в списке результатов или где угодно на странице (кнопка / пункт с ровно этим текстом)
    const findAct = () => [...document.querySelectorAll(c.items)].find(e => new RegExp(c.findByPhone, 'i').test(e.innerText || ''))
      || [...document.querySelectorAll('button, [role="button"], li, a')].find(e => new RegExp('^\\s*(' + c.findByPhone + ')\\s*$', 'i').test(e.innerText || ''));
    // найденные чаты; один человек бывает дважды (чат и контакт) — считаем по имени
    const people = () => [...new Set([...document.querySelectorAll(c.cells)].map(e => norm((e.innerText || '').split('\n')[0])).filter(Boolean))];
    if (op === 'mx_found') return { act: !!findAct(), cells: document.querySelectorAll(c.cells).length, people: people(), dbg: norm(q('.scrollable')?.innerText).slice(0, 160) };
    if (op === 'mx_pick') {   // «Найти по номеру» — точный поиск; иначе — единственный найденный чат
      const act = findAct();
      if (act) { (act.querySelector('button') || act).click(); return 'act'; }
      const cells = document.querySelectorAll(c.cells), ppl = people();
      if (cells.length && ppl.length === 1) { cells[0].click(); return 'cell'; }
      return cells.length ? 'many' : 'none';
    }
    if (op === 'mx_chat') return location.pathname !== a.was && /^\/-?\d+/.test(location.pathname) && !!q(c.composer) ? 'ok' : new RegExp(c.notFound, 'i').test(document.body.innerText.slice(0, 5000)) ? 'none' : 'wait';
    if (op === 'mx_clear') { set(''); return 'ok'; }
    if (op === 'mx_has') { const head = norm(a.text).slice(0, 24); return [...document.querySelectorAll(c.msgItems)].slice(-3).some(e => norm(e.innerText).includes(head)); }
    if (op === 'mx_paste') { const box = q(c.composer); if (!box) return 'nobox'; box.focus(); box.dispatchEvent(new ClipboardEvent('paste', { clipboardData: file(a.pic), bubbles: true, cancelable: true })); return 'ok'; }
    const tgt = () => (a.dialog && q(c.dialogComposer)) || q(c.composer);
    if (op === 'mx_type') { const t = tgt(); if (!t) return 'nobox'; type(t, a.text); return 'ok'; }
    // кнопка «Отправить» появляется после ввода (вместо микрофона) — её ждёт расширение; нет — Enter
    if (op === 'mx_sendbtn') { const t = tgt(); const btn = t && (t.closest('[role="dialog"]') || q('main') || document).querySelector(c.sendBtn); if (!btn) return 'wait'; btn.click(); return 'ok'; }
    if (op === 'mx_enter') { const t = tgt(); t?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); return 'ok'; }
    if (op === 'mx_wipe') { const t = tgt(); if (!t) return 'nobox'; t.focus(); const r = document.createRange(); r.selectNodeContents(t); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(r);
      document.execCommand('delete'); if (norm(t.innerText)) { t.innerHTML = ''; t.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' })); } return norm(t.innerText); }
    if (op === 'mx_dbg') return { box: norm(tgt()?.innerText).slice(0, 60), last: [...document.querySelectorAll(c.msgItems)].slice(-1).map(e => norm(e.innerText).slice(-70))[0] || '',
      btns: [...(q('main') || document).querySelectorAll('button')].map(b => b.getAttribute('aria-label') || '').filter(Boolean).slice(-4).join('|') };
    if (op === 'mx_box') return norm(((a.dialog && q(c.dialogComposer)) || q(c.composer))?.innerText);
    if (op === 'mx_read') {
      const main = q('main')?.getBoundingClientRect(), mid = main ? main.left + main.width / 2 : innerWidth / 2;
      return [...document.querySelectorAll(c.msgItems)].slice(-30).map(e => {
        const b = e.querySelector(c.bubble); if (!b) return null;
        const cls = String(e.className || '') + ' ' + String(b.className || ''), r = b.getBoundingClientRect();
        const own = /(^|[\s_-])(out|outgoing|own|self|mine|isOwn|my)([\s_-]|$)/i.test(cls) || (!/(^|[\s_-])(in|incoming)([\s_-]|$)/i.test(cls) && r.left + r.width / 2 > mid + 20);
        const full = String(b.innerText || '').trim(), hm = /(\d{1,2}):(\d{2})\s*$/.exec(full);
        let at = new Date(); if (hm) { at.setHours(+hm[1], +hm[2], 0, 0); if (at.getTime() > Date.now() + 5 * 60e3) at = new Date(at.getTime() - 864e5); }
        return { who: own ? 'me' : 'owner', text: full.replace(/\s*(ред\.\s*)?\d{1,2}:\d{2}\s*$/, '').trim().slice(0, 1000), at: at.toISOString() };
      }).filter(x => x && x.text);
    }
    return 'unknown';
  } catch (e) { return { e: String(e?.message || e) }; }
}
const P = (tabId, op, a, c) => run(tabId, pg, [op, a || {}, c]);
// ждать (в расширении), пока шаг страницы не вернёт подходящее
async function until(fn, ok, ms, step = 700) { const t0 = Date.now(); let v; while (Date.now() - t0 < ms) { v = await fn(); if (ok(v)) return v; await sleepS(step); } return v; }

// «[15:30, 03.11.2026] Имя: » → время ISO (браузер агента — в его часовом поясе, время из строки — местное)
function waTimeLocal(pre) {
  const m = /\[(\d{1,2}):(\d{2})(?:\s*([AP]M))?,\s*(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})\]/i.exec(pre || '');
  if (!m) return new Date().toISOString();
  let h = +m[1]; if (m[3]) h = h % 12 + (/p/i.test(m[3]) ? 12 : 0);
  const a = +m[4], b = +m[5], c = +m[6], [y, mo, d] = a > 999 ? [a, b, c] : pre.includes('/') ? [c, a, b] : [c, b, a];
  return new Date(y < 100 ? 2000 + y : y, mo - 1, d, h, +m[2]).toISOString();
}
// WhatsApp: send?phone=&text= — чат с готовым текстом
async function waGo(tabId, phone, text, c) {
  const d = phone.replace(/\D/g, '');
  await chrome.tabs.update(tabId, { url: `https://web.whatsapp.com/send?phone=${d}${text ? `&text=${encodeURIComponent(text)}` : ''}` });
  await sleepS(1500); await tabLoaded(tabId);
  const st = await ready('wa', tabId, 60000);
  if (st !== 'ok') {
    if (st === 'auth') return 'AUTH: войдите в WhatsApp Web в этом браузере';
    const t = await chrome.tabs.get(tabId).catch(() => null);
    const txt = await run(tabId, () => String(document.body?.innerText || '').replace(/\s+/g, ' ').slice(0, 160));
    return `NET: WhatsApp не загрузился [${(t?.url || '').slice(0, 60)} · ${t?.status || ''} · ${typeof txt === 'string' ? txt : JSON.stringify(txt).slice(0, 100)}]`;
  }
  const o = await until(() => P(tabId, 'wa_open', {}, c), v => v === 'ok' || v === 'bad', 45000, 1000);
  return o === 'bad' ? 'NOUSER: номера нет в WhatsApp' : o === 'ok' ? '' : 'чат не открылся';
}
// ---- v0.7.30: фото с подписью внутренними функциями WhatsApp Web (12.11, проверено на WhatsApp Алексея) ----
// MediaOpaqueData.createFromData(File) → prepRawMedia(od, {}) → MediaPrep.waitForPrep() → MediaPrep.sendToChat({chat, options: {caption}}),
// чат — FindChatAction.findOrCreateLatestChat(WidFactory.createWid('7…@c.us')).chat. Редактор фото не нужен — работает в скрытой вкладке.
// Страница запускает отправку и сразу возвращается (таймеры фоновой вкладки замедлены); ход — window.__daInt, его опрашивает расширение.
function waInt(op, a, c) {
  try {
    if (op === 'st') { const x = window.__daInt; return x && x.key === a.key ? { st: x.st, why: x.why, ack: x.ack, type: x.type, cap: x.cap, ms: x.ms } : { st: 'none' }; }
    const req = window.require; if (typeof req !== 'function') return { st: 'err', why: 'нет загрузчика модулей' };
    const R = n => { try { return req(n); } catch { return null; } };
    const has = (n, f) => { const m = R(n); return m && typeof m[f] === 'function' ? m : null; };
    // по имени из настроек; не нашлось — перебор модулей WAWeb* по экспортам
    let map = null; try { map = req('__debug')?.modulesMap; } catch { /* нет карты */ }
    const pick = (names, f) => { for (const n of String(names || '').split(',').map(x => x.trim()).filter(Boolean)) { const m = has(n, f); if (m) return m; }
      if (!map) return null; for (const n of Object.keys(map)) { if (!/^WAWeb/.test(n) || /pb$|Protobuf|react$/i.test(n)) continue; const m = map[n]?.exports; if (m && typeof m[f] === 'function') return R(n) || m; } return null; };
    const W = pick(c.intWid, 'createWid'), F = pick(c.intFind, 'findOrCreateLatestChat'), OD = pick(c.intOd, 'createFromData'), PR = pick(c.intPrep, 'prepRawMedia');
    const miss = [!W && 'createWid', !F && 'findOrCreateLatestChat', !OD && 'createFromData', !PR && 'prepRawMedia'].filter(Boolean);
    if (miss.length) return { st: 'err', why: 'нет функций: ' + miss.join(', ') };
    if (op === 'probe') return { st: 'ok' };
    const S = window.__daInt = { key: a.key, st: 'run', t0: Date.now() };
    (async () => {
      const r = await F.findOrCreateLatestChat(W.createWid(String(a.phone).replace(/\D/g, '') + '@c.us'));
      const chat = r?.chat || r; if (!chat?.id) throw new Error('чат не найден');
      const last0 = chat.msgs?.last?.()?.id?.id;
      const file = new File([Uint8Array.from(atob(a.pic), ch => ch.charCodeAt(0))], 'photo.jpg', { type: 'image/jpeg' });
      const od = await OD.createFromData(file, 'image/jpeg');
      const mp = PR.prepRawMedia(od, {});
      if (typeof mp?.waitForPrep === 'function') await mp.waitForPrep();
      if (typeof mp?.sendToChat !== 'function') throw new Error('нет sendToChat');
      S.st = 'sending';
      const res = await mp.sendToChat({ chat, options: a.text ? { caption: a.text } : {} });
      S.res = String(res?.messageSendResult ?? res ?? '');
      // ушло ли — по чату: последнее сообщение новое, своё, картинка; ack ≥ 1 — сервер WhatsApp принял
      const chk = () => { const L = chat.msgs?.last?.(); if (L && L.id?.id !== last0 && L.id?.fromMe && L.type === 'image') { S.type = L.type; S.ack = L.ack; S.cap = String(L.caption || '').slice(0, 40); return L.ack >= 1; } return false; };
      S.chk = chk; S.st = chk() ? 'ok' : 'wait'; S.ms = Date.now() - S.t0;
    })().catch(e => { S.st = 'err'; S.why = String(e?.message || e).slice(0, 160); });
    return { st: 'started' };
  } catch (e) { return { st: 'err', why: String(e?.message || e).slice(0, 160) }; }
}
// опрос хода (в странице без таймеров): «wait» — перепроверить ack
function waIntPoll(key) { const x = window.__daInt; if (!x || x.key !== key) return { st: 'none' }; if (x.st === 'wait' && x.chk && x.chk()) { x.st = 'ok'; x.ms = Date.now() - x.t0; }
  return { st: x.st, why: x.why, ack: x.ack, type: x.type, cap: x.cap, ms: x.ms, res: x.res }; }
async function waPhotoInt(tabId, it, pic, c) {
  if (c.intOn === '0') return { why: 'внутренний путь выключен' };
  const withCap = it.text.length <= 1000, key = Date.now() + ':' + Math.random();
  const s0 = await run(tabId, waInt, ['send', { key, phone: it.phone, pic, text: withCap ? it.text : '' }, c]);
  if (s0?.st !== 'started') return { why: 'внутренний путь: ' + (s0?.why || s0?.e || 'не запустился') };
  const r = await until(() => run(tabId, waIntPoll, [key]), v => v?.st === 'ok' || v?.st === 'err' || v?.e, 45000, 1000);
  if (r?.st === 'ok') return { ok: true, caption: withCap, how: `внутренний путь, ${r.ms} мс, ack ${r.ack}` };
  // запущено, но подтверждения нет — повторять нельзя (будет два фото)
  if (r?.st === 'wait' || r?.st === 'sending') return { sent: true, why: 'внутренний путь: нет подтверждения за 45 с (' + r.st + ')' };
  return { why: 'внутренний путь: ' + (r?.why || r?.e || r?.st || 'нет ответа') };
}
// Chrome сейчас на экране (окно с фокусом не свёрнуто) — только тогда можно запасной путь с показом вкладки
async function chromeOnScreen() { const w = await chrome.windows.getLastFocused().catch(() => null); return !!(w?.focused && w.state !== 'minimized'); }
// фото с подписью одним сообщением: чат без текста → «+» → «Фото и видео» (подмена окна выбора) → подпись → «Отправить» → новое сообщение в чате
// В фоне (скрытая вкладка) настоящий WhatsApp фото не отправляет (12.11, 0.7.22: «Отправить» нажато, после перечитывания чата фото нет),
// поэтому фото сверяется с чатом: не появилось — уходит текст с пометкой «без фото», повторного фото нет. Вкладка видна, пока фото не появится (до ~30 с).
async function waPhoto(tabId, it, pic, c) {
  const e = await waGo(tabId, it.phone, '', c); if (e) return { e };
  const dbg = /\[dbg\]/.test(it.text), how = [];
  let r;
  const tab = await chrome.tabs.get(tabId), win = await chrome.windows.get(tab.windowId).catch(() => null);
  if (dbg) { const lf = await chrome.windows.getLastFocused({ populate: true }).catch(() => null);
    how.push(`фокус: Chrome ${lf?.focused ? 'в фокусе' : 'не в фокусе (другая программа)'}, окно WhatsApp ${win?.focused ? 'с фокусом' : 'без фокуса'} ${win?.state || ''}, вкладка WhatsApp ${tab.active ? 'активна в своём окне' : 'скрыта'}, активная вкладка ${String(lf?.tabs?.find(t => t.active)?.url || '').split('/')[2] || '—'}`); }
  // 0.7.30: сначала внутренние функции — вкладка остаётся в фоне
  const ir = await waPhotoInt(tabId, it, pic, c);
  if (ir.ok || ir.sent) { if (ir.how) how.push(ir.how); if (ir.why) how.push(ir.why); return dbg || ir.sent ? { ...ir, how: how.join('; ') } : { ok: ir.ok, caption: ir.caption }; }
  how.push(ir.why);
  // Фоновая работа по умолчанию: переключение вкладки — только по явной настройке.
  if ((await DA.getSettings()).allowForegroundPhotos !== true) return { why: ir.why + '; переключение вкладки для фото не разрешено' };
  // запасной путь 0.7.27 (показ вкладки) — только если Chrome сейчас на экране; иначе — текст «без фото»
  if (!await chromeOnScreen()) return { why: ir.why + '; Chrome не на экране — без показа вкладки (' + how.join('; ') + ')' };
  // 0.7.27 (решение Главного 12.11): как в 0.7.21 — вкладка WhatsApp на время фото активна в своём окне, потом прежняя вкладка.
  // Редактор фото работает только в вкладке, видимой на экране (12.11 21:19: фото ушло, когда Алексей сам открыл WhatsApp);
  // окно без фокуса, закрытое другой программой, и отдельное окно без фокуса — не помогают. Этот запасной путь включается отдельной настройкой пользователя.
  const [prev] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
  r = await waPhotoTry(tabId, it, pic, c, async on => {
    if (on) { await chrome.tabs.update(tabId, { active: true }).catch(() => null); await sleepS(1200); }
    else if (prev && prev.id !== tabId) await chrome.tabs.update(prev.id, { active: true }).catch(() => null);
  });
  how.push(win?.focused ? 'вкладка в окне с фокусом' : 'вкладка в окне без фокуса');
  if (r.sent && !r.ok) r = await waPhotoSeen(tabId, it, c);
  return r.ok || r.sent ? (dbg ? { ...r, how: how.join('; ') } : r) : { why: r.why + ' (' + how.join('; ') + ')' };
}
// фото с подписью уже в чате? (после перезагрузки чата — то, что WhatsApp действительно отправил)
async function waPhotoSeen(tabId, it, c) {
  const e = await waGo(tabId, it.phone, '', c); if (e) return { sent: true, why: 'чат не открылся для проверки' };
  await until(() => P(tabId, 'wa_state', {}, c), v => v?.n > 0, 10000, 500); await sleepS(1500);
  const raw = await P(tabId, 'wa_read', {}, c), head = normT(it.text).slice(0, 30);
  const hit = (Array.isArray(raw) ? raw : []).slice(-6).some(x => x.out && x.media && normT(x.t).includes(head));
  return hit ? { ok: true, caption: it.text.length <= 1000 } : { why: 'фото не появилось в чате' };   // не ушло — можно пробовать запасной путь
}
async function waPhotoTry(tabId, it, pic, c, show) {
  let shown = false;
  try {
    const l0 = (await P(tabId, 'wa_state', {}, c))?.last ?? '';
    if (show) { await show(true); shown = true; }
    if (await P(tabId, 'wa_attach', {}, c) !== 'clicked') return { why: 'нет «+»' };
    if (await until(() => P(tabId, 'wa_photo', { pic }, c), v => v === 'ok', 4000, 500) !== 'ok') return { why: 'нет «Фото и видео»' };
    // редактор фото открывается несколько секунд; кнопка отправки видна раньше, чем он готов принять подпись — ждём, как в 0.7.21 (там фото уходило)
    await sleepS(9000);
    if (await until(() => P(tabId, 'wa_pv', {}, c), v => v === true, 4000, 400) !== true) return { why: 'не открылся предпросмотр' };
    const withCap = it.text.length <= 1000;
    if (withCap && await P(tabId, 'wa_caption', { text: it.text }, c) !== 'ok') return { why: 'нет поля подписи' };
    await sleepS(400);
    if (await until(() => P(tabId, 'wa_preview', {}, c), v => v === 'ok', 6000, 400) !== 'ok') return { why: 'нет кнопки отправки фото' };
    // фото догружается, только пока вкладка видна (12.11: возврат сразу после «Отправить» — фото не ушло), поэтому ждём появления в чате
    const st = await until(() => P(tabId, 'wa_state', {}, c), v => v?.last && v.last !== l0, 20000, 1000);
    if (!(st?.last && st.last !== l0)) return { why: 'фото не появилось в чате', sent: true };   // нажато — повторять нельзя (будет два фото)
    return { ok: true, caption: withCap };
  } finally {
    if (shown) await show(false).catch(() => null);
  }
}
async function waSend(tabId, it, pic, c) {
  let warn = '';
  if (pic) {
    const ph = await waPhoto(tabId, it, pic, c);
    if (ph.e) return ph.e;
    if (ph.ok && ph.caption) return ph.how ? { warn: 'dbg фото: ' + ph.how } : '';   // фото с подписью — всё ушло одним сообщением
    if (ph.sent && !ph.ok) return { warn: 'фото отправлено, но в чате не появилось за 20 с — проверьте чат' };   // текст не дублируем
    if (!ph.ok) warn = `без фото: ${ph.why}`;
    else if (ph.how) warn = 'dbg фото: ' + ph.how;
  }
  const e = await waGo(tabId, it.phone, it.text, c); if (e) return e;
  await sleepS(800);
  const s2 = await P(tabId, 'wa_state', {}, c);
  if (await P(tabId, 'wa_send', {}, c) !== 'ok') return 'нет кнопки «Отправить»';
  const s3 = await until(() => P(tabId, 'wa_state', {}, c), v => v?.last !== s2.last && !v.box, 10000, 800);
  if (s3?.last === s2.last && s3?.box?.length > 3) return 'сообщение не ушло';
  return warn ? { warn } : '';
}
// MAX: поиск по номеру → «Найти по номеру» (точный) или единственный чат
async function maxOpen(phone) {
  const tab = await msgTab('max'), c = await C('max');
  const st = await ready('max', tab.id);
  if (st !== 'ok') return { e: st === 'auth' ? 'AUTH: войдите в MAX (web.max.ru) в этом браузере' : 'NET: MAX не загрузился' };
  // открыт чат — сначала к списку чатов (иначе «Найти по номеру» с этим же человеком не меняет адрес, а при ненайденном номере
  // осталcя бы открытым прежний чат — и сообщение ушло бы не тому)
  const t0 = await chrome.tabs.get(tab.id);
  if (!/^https:\/\/web\.max\.ru\/?(\?|#|$)/.test(t0.url || '')) {
    await chrome.tabs.update(tab.id, { url: 'https://web.max.ru/' }); await sleepS(1500); await tabLoaded(tab.id);
    if (await ready('max', tab.id) !== 'ok') return { e: 'NET: MAX не загрузился' };
  }
  await P(tab.id, 'mx_tab', {}, c); await sleepS(900);
  const was = await P(tab.id, 'mx_search', { phone }, c);
  if (typeof was === 'string' && was !== 'nosearch' && /^\/-?\d+/.test(was)) return { e: 'NET: MAX не вернулся к списку чатов' };
  await sleepS(600);
  if ((await P(tab.id, 'mx_val', {}, c)) !== phone) { await P(tab.id, 'mx_search', { phone }, c); await sleepS(600); }
  if ((await P(tab.id, 'mx_val', {}, c)) !== phone) return { e: 'NET: номер не вводится в поиск MAX' };
  if (was === 'nosearch' || typeof was !== 'string') return { e: 'NET: нет поиска в MAX' };
  // сначала ждём «Найти по номеру» (появляется позже первых результатов); нет его за 7 с — смотрим найденные чаты
  const f = await until(() => P(tab.id, 'mx_found', {}, c), v => v?.act, 7000, 500);
  if (!f?.act) await sleepS(500);
  const how = await P(tab.id, 'mx_pick', {}, c);
  if (how === 'many' || how === 'none') {
    const seen = await P(tab.id, 'mx_found', {}, c);   // что видно в поиске — в ошибку (агенту и для починки)
    await P(tab.id, 'mx_clear', {}, c);
    return { e: (how === 'many' ? 'NOUSER: по номеру нашлось несколько чатов' : 'NOUSER: номера нет в MAX') + (seen?.people?.length ? ` (${seen.people.slice(0, 4).join('; ').slice(0, 120)})` : '') + (seen?.dbg ? ` [${seen.dbg}]` : '') };
  }
  const ch = await until(() => P(tab.id, 'mx_chat', { was }, c), v => v === 'ok' || v === 'none', 9000, 500);
  await P(tab.id, 'mx_clear', {}, c);
  return ch === 'ok' ? { tab, c } : { e: 'NOUSER: номера нет в MAX' };
}
async function maxSend(it, pic) {
  const o = await maxOpen(it.phone); if (o.e) return o.e;
  const { tab, c } = o;
  await sleepS(1200);
  const had = await P(tab.id, 'mx_has', { text: it.text }, c);
  let dialog = false;
  if (pic && await P(tab.id, 'mx_paste', { pic }, c) === 'ok') { await sleepS(2500); dialog = true; }
  if (!dialog) await P(tab.id, 'mx_wipe', {}, c);   // в поле мог остаться черновик — иначе он ушёл бы вместе с нашим текстом
  if (await P(tab.id, 'mx_type', { text: it.text, dialog }, c) !== 'ok') return 'в этот чат нельзя писать';
  if (await until(() => P(tab.id, 'mx_sendbtn', { dialog }, c), v => v === 'ok', 4000, 400) !== 'ok') await P(tab.id, 'mx_enter', { dialog }, c);
  const ok = await until(async () => had ? !(await P(tab.id, 'mx_box', { dialog: false }, c)) : await P(tab.id, 'mx_has', { text: it.text }, c), v => v === true, 10000, 700);
  if (ok === true) return '';
  const d = await P(tab.id, 'mx_dbg', { dialog }, c);
  const left = await P(tab.id, 'mx_wipe', { dialog }, c);   // не ушло — черновик убираем, чтобы потом не ушёл случайно
  return `сообщение не ушло [поле: ${d?.box || '—'} · последнее: ${d?.last || '—'} · кнопки: ${d?.btns || '—'}${left ? ' · черновик не стёрся' : ''}]`;
}

// фото к сообщению качает расширение (у WhatsApp / MAX / Telegram строгие правила страницы — оттуда наше хранилище не открыть),
// в страницу уходит base64; страница сама собирает файл
async function photoB64(u) {
  if (!u || !/^https:\/\/([a-z0-9-]+\.)*supabase\.co\//.test(u)) return '';
  try { const r = await fetch(u); if (!r.ok) return ''; const b = new Uint8Array(await r.arrayBuffer()); if (b.length > 4e6) return '';
    let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000)); return btoa(s); } catch { return ''; }
}

// ---- одно сообщение ----
async function sendOne(svc, it) {
  if (!MSGR[svc]) return { ok: false, error: 'неизвестный мессенджер' };
  const pic = await photoB64(it.photo);
  // WhatsApp и MAX открывают чат в той же вкладке: пользователь сам в ней — ждём (задание не теряется, следующая попытка через 30 с)
  if (svc !== 'tg') { const t = await msgTab(svc, false); if (t && await userIn(t.id)) return { defer: true }; }
  if (svc === 'max') { const e = await maxSend(it, pic); return e ? { ok: false, error: e } : { ok: true }; }
  const tab = await msgTab(svc);
  if (svc === 'tg') {
    const st = await ready('tg', tab.id);
    if (st !== 'ok') return { ok: false, error: st === 'auth' ? 'AUTH: войдите в Telegram Web в этом браузере' : 'NET: Telegram не загрузился' };
    const e = await run(tab.id, tgSendPage, [it.phone, it.name || '', it.text, pic], 90000);
    return e?.warn ? { ok: true, warn: e.warn } : e ? { ok: false, error: typeof e === 'string' ? e : e.e || 'ошибка' } : { ok: true };
  }
  const e = await waSend(tab.id, it, pic, await C('wa'));
  return typeof e === 'object' ? { ok: true, warn: e.warn } : e ? { ok: false, error: e } : { ok: true };
}
async function readOne(svc, phone) {
  if (svc !== 'tg') { const t = await msgTab(svc, false); if (t && await userIn(t.id)) return { ok: false, defer: true, error: 'NET: пользователь сейчас в мессенджере' }; }
  if (svc === 'max') { const o = await maxOpen(phone); if (o.e) return { ok: false, error: o.e };
    await sleepS(1500); const msgs = await P(o.tab.id, 'mx_read', {}, o.c); return Array.isArray(msgs) && msgs.length ? { ok: true, msgs } : { ok: false, error: 'NET: история чата MAX не загрузилась' }; }
  const tab = await msgTab(svc);
  if (svc === 'tg') {
    const st = await ready('tg', tab.id);
    if (st !== 'ok') return { ok: false, error: st === 'auth' ? 'AUTH: вход в Telegram закончился' : 'NET: Telegram не загрузился' };
    const r = await run(tab.id, tgReadPage, [phone], 60000);
    if (r?.e) return { ok: false, error: /^NOUSER/.test(r.e) ? r.e : /AUTH_KEY|SESSION_REVOKED/.test(r.e) ? 'AUTH: ' + r.e : /FLOOD/.test(r.e) ? 'FLOOD: ' + r.e : 'NET: ' + r.e.slice(0, 160) };
    return { ok: true, msgs: r?.msgs || [] };
  }
  const c = await C('wa');
  const e = await waGo(tab.id, phone, '', c);
  if (e) return { ok: false, error: /^(AUTH|NOUSER)/.test(e) ? e : 'NET: ' + e };
  await until(() => P(tab.id, 'wa_state', {}, c), v => v?.n > 0, 10000, 500); await sleepS(1500);
  const raw = await P(tab.id, 'wa_read', {}, c);
  const msgs = (Array.isArray(raw) ? raw : []).map(x => ({ who: x.out ? 'me' : 'owner', text: (x.t || (x.media ? '[файл]' : '')).slice(0, 1000), at: waTimeLocal(x.pre) })).filter(m => m.text);
  return msgs.length ? { ok: true, msgs } : { ok: false, error: 'NET: история чата WhatsApp не загрузилась' };
}

// ---- такт (будильник раз в 30 с): одно сообщение задания или опрос сервера; работа — под замком ----
// v0.7.22: замок помнит, какой экземпляр service worker его взял (BOOT). Chrome усыпил/убил прежний посреди отправки — замок
// сразу считается свободным (раньше ждали 4 минуты), а недоотправленное сообщение сначала проверяется в чате, чтобы не отправить дважды.
const BOOT = Math.random().toString(36).slice(2);
const lockFree = b => !b || (typeof b === 'number' ? Date.now() - b > 4 * 60e3 : (b.boot !== BOOT || Date.now() - b.at > 4 * 60e3));
const lockTake = () => chrome.storage.session.set({ sendBusy: { at: Date.now(), boot: BOOT } });
const normT = t => String(t || '').replace(/\s+/g, ' ').trim();
// сообщение уже есть в чате (наше, начало текста совпадает)? true | false | null — не удалось прочитать
async function alreadySent(svc, it) {
  const r = await readOne(svc, it.phone).catch(() => null);
  if (!r?.ok) return null;
  const head = normT(it.text).slice(0, 40);
  return r.msgs.some(m => m.who === 'me' && normT(m.text).includes(head));
}
async function sendItem(svc, it) {
  // сторож: одно сообщение — не дольше 3 минут; после него шаги «зависшей» отправки останавливаются (STOP), чтобы не шли параллельно со следующей
  let to = null;
  const work = sendOne(svc, it).catch(e => ({ ok: false, error: String(e?.message || e) }));
  const r = await Promise.race([work, new Promise(res => { to = setTimeout(() => res(null), 180000); })]);
  clearTimeout(to);
  if (r) return r;
  STOP = true; await Promise.race([work, sleepS(30000)]); STOP = false;
  return { ok: false, error: 'NET: мессенджер не ответил за 3 минуты' };
}
// ---- 03.4 E: доказательство отправки по чату (страница — один мгновенный шаг, повторы — из расширения) ----
// Telegram: своё сообщение с тем же текстом/подписью, с серверным номером (mid), не раньше начала попытки.
async function tgProofPage(phone, text, armed) {
  const M = window.rootScope && window.rootScope.managers, digits = String(phone).replace(/\D/g, ''), norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  if (!M) return { miss: 'tg:no_managers' };
  // номер чата запоминаем: повторные contacts.resolvePhone Telegram быстро ограничивает (FLOOD)
  const P = window.__daPeers = window.__daPeers || {};
  let id = P[digits] || 0;
  if (!id) { try { const x = await M.apiManager.invokeApi('contacts.resolvePhone', { phone: digits }); id = x && x.peer && x.peer.user_id ? x.peer.user_id : (x && x.users && x.users[0] ? x.users[0].id : 0); } catch (e) { return { miss: 'tg:resolve:' + String((e && (e.type || e.message)) || e).slice(0, 60) }; } }
  if (!id) return { miss: 'tg:resolve:no_user' }; P[digits] = id;
  const peerId = Number(id), want = norm(text), h = await M.appMessagesManager.getHistory({ peerId, limit: 10 }).catch(() => null);
  let out = 0, late = 0, diff = 0;
  for (const mid of ((h && h.history) || [])) { const m = await M.appMessagesManager.getMessageByPeer(peerId, mid);
    if (m && m.pFlags && m.pFlags.out) { out++; if ((m.date || 0) < armed) late++; else if (norm(m.message) !== want) diff++; }
    if (!m || !m.pFlags || !m.pFlags.out || m.pFlags.is_outgoing || !Number.isInteger(m.mid) || m.mid <= 0 || (m.date || 0) < armed) continue;
    if (norm(m.message) === want) return { kind: 'chat_observed', message_key: 'tg:' + peerId + ':' + m.mid, media: m.media && m.media._ === 'messageMediaPhoto' ? 'photo_and_text' : 'text', observed_at: new Date(m.date * 1000).toISOString() }; }
  return { miss: `tg:msg:hist${((h && h.history) || []).length}:out${out}:old${late}:diff${diff}` };
}
// WhatsApp: модель чата — своё сообщение с тем же текстом/подписью, не раньше начала попытки, принятое сервером (ack ≥ 1)
async function waProofPage(phone, text, armed, c) {
  try {
    const req = window.require; if (typeof req !== 'function') return { miss: 'wa:no_require' };
    const R = n => { try { return req(n); } catch { return null; } }, norm = s => String(s || '').replace(/\s+/g, ' ').trim();
    const W = String((c && c.intWid) || 'WAWebWidFactory').split(',').map(n => R(n.trim())).find(m => m && typeof m.createWid === 'function');
    const Col = R('WAWebCollections'); if (!W || !Col || !Col.Chat) return { miss: 'wa:no_modules' };
    const wid = W.createWid(String(phone).replace(/\D/g, '') + '@c.us');
    // 03.4 G: чат бывает записан под новым адресом (@lid) — Chat.get(номер@c.us) его не видит; тот же поиск, что у отправки с фото
    let chat = Col.Chat.get(wid), via = 'get';
    if (!chat || !chat.msgs) { const F = String((c && c.intFind) || 'WAWebFindChatAction').split(',').map(n => R(n.trim())).find(m => m && typeof m.findOrCreateLatestChat === 'function');
      if (F) { const r = await F.findOrCreateLatestChat(wid).catch(() => null); chat = r && (r.chat || r); via = 'find'; } }
    if (!chat || !chat.msgs) return { miss: 'wa:chat_' + via };
    const want = norm(text); let out = 0, old = 0, noack = 0, diff = 0;
    for (const m of chat.msgs.getModelsArray().slice(-15).reverse()) {
      if (m && m.id && m.id.fromMe) { out++; if ((m.t || 0) < armed) old++; else if (!(m.ack >= 1)) noack++; else if (norm(m.type === 'chat' ? m.body : m.caption) !== want) diff++; }
      if (!m || !m.id || !m.id.fromMe || (m.t || 0) < armed || !(m.ack >= 1)) continue;
      if (norm(m.type === 'chat' ? m.body : m.caption) === want) return { kind: 'provider_ack', message_key: String(m.id._serialized || m.id.id), ack: Number(m.ack), media: m.type === 'image' ? 'photo_and_text' : 'text', observed_at: new Date(m.t * 1000).toISOString(), via };
    }
    return { miss: `wa:msg:${via}:out${out}:old${old}:noack${noack}:diff${diff}` };
  } catch (e) { return { miss: 'wa:err:' + String((e && e.message) || e).slice(0, 60) }; }
}
// MAX: номера сообщения нет — без доказательства (результат «не подтверждён», агент проверяет чат)
async function p2Proof(svc, it, armedMs) {
  // допуск 2 минуты: часы компьютера могут спешить относительно мессенджера («своё», серверный номер и весь текст — обязательны)
  const armed = Math.floor(armedMs / 1000) - 120;
  if (svc === 'max') return null;
  const tab = await msgTab(svc, false); if (!tab) { p2Proof.miss = svc + ':no_tab'; return null; }
  p2Proof.miss = '';
  for (let k = 0; k < 4; k++) {
    const pr = svc === 'tg' ? await run(tab.id, tgProofPage, [it.phone, it.text, armed], 20000) : await run(tab.id, waProofPage, [it.phone, it.text, armed, await C('wa')], 10000);
    if (pr && pr.kind) return pr;
    p2Proof.miss = (pr && (pr.miss || pr.e)) ? String(pr.miss || pr.e).slice(0, 120) : 'empty';
    await sleepS(1500);
  }
  return null;
}
// ---- протокол 2 (03.4) ----
// Разрешение на каждое сообщение (own_ext_begin) → отправка → результат сохраняется в chrome.storage до ответа сайту → подтверждение (own_ext_finish).
// Общая машина состояний — dispatch-flow.js (байт в байт как у сервера). Потеря ответа сайта повторяет только подтверждение;
// Chrome остановил расширение посреди отправки — «не подтверждено, проверьте чат» (без повтора и без поиска текста в неполной истории).
const P2K = key => 'dsp:' + key;
// только явные состояния протокола; лимит частоты, истёкший вход и т. п. — ошибка (повтор позже), а не «состояние»
const P2_KNOWN = new Set(['claimed', 'ready', 'sent', 'failed', 'unknown', 'busy', 'stale', 'stopped', 'invalid', 'missing', 'forbidden', 'conflict']);
const P2_DROP = new Set(['sent', 'failed', 'unknown', 'stale', 'missing', 'forbidden', 'conflict', 'not_found']);   // снимок больше не нужен
async function p2Call(action, body) {
  const r = await autoApi(action, body);
  if (r && P2_KNOWN.has(r.state)) return r;
  if (r?.error === 'update_required' || r?.error === 'not_found') return { state: r.error };
  throw new Error(r?.message || r?.error || 'нет связи с сайтом');
}
// старый ответ отправки → протокол 2: «не отправлено» — только то, что точно случилось ДО отправки; остальное без доказательства — unknown
function p2Result(r) {
  if (!r || r.defer) return { defer: true };
  if (r.ok) return { ok: true, proof: r.proof, parts: r.parts, warn: r.warn };
  if (r.unknown) return { ok: false, unknown: true, warn: r.warn };
  const e = String(r.error || '');
  const code = /^AUTH/.test(e) ? 'AUTH' : /^NOUSER/.test(e) ? 'NOUSER' : r.pre || /^FLOOD/.test(e) ? 'PRECHECK' : '';
  return code ? { ok: false, proof: { kind: 'not_sent', code }, warn: r.warn } : { ok: false, unknown: true, warn: r.warn };
}
// ключ — логин + задание + сообщение: другой агент в этом же Chrome не трогает чужие снимки
function p2Opts(j, it, send) {
  const key = `ext:${j.login}:${j.id}:${it.num}`;
  return { key, send,
    persist: v => chrome.storage.local.set({ [P2K(key)]: v }),
    begin: attempt => p2Call('own_ext_begin', { protocol: 2, id: j.id, num: it.num, attempt }),
    finish: (attempt, result) => p2Call('own_ext_finish', { protocol: 2, id: j.id, num: it.num, attempt, ...result }) };
}
async function p2Item(j, it) {
  let raw = null;
  const o = p2Opts(j, it, async () => {
    const armed = Date.now();
    raw = await sendItem(j.svc, it);
    if (raw?.ok && !raw.proof) { const proof = await p2Proof(j.svc, it, armed).catch(() => null); raw = proof ? { ...raw, proof } : { ...raw, ok: false, unknown: true, warn: [raw.warn, 'проверка: ' + (p2Proof.miss || 'нет')].filter(Boolean).join('; ') }; }
    else if (raw && raw.ok === false && raw.error) raw = { ...raw, warn: [raw.warn, 'отправка: ' + String(raw.error).slice(0, 160)].filter(Boolean).join('; ') };   // 03.4 G: причина — в журнал
    return p2Result(raw);
  });
  const snap = (await chrome.storage.local.get(P2K(o.key)))[P2K(o.key)] || null;
  const rc = await globalThis.DA_DISPATCH_FLOW.run({ ...o, snapshot: snap });
  if (P2_DROP.has(rc.state)) await chrome.storage.local.remove(P2K(o.key));
  return { rc, raw };
}
// после перезапуска Chrome: дослать сохранённые результаты и закрыть прерванные отправки как unknown — без отправки
async function p2Recover() {
  const all = await chrome.storage.local.get(null), me = all.sendLogin;
  for (const [k, s] of Object.entries(all)) {
    const m = /^dsp:ext:([^:]+):(\d+):(\d+)$/.exec(k);
    if (!m || m[1] !== me) continue;   // снимки другого агента ждут его входа
    if (!['dispatching', 'ack', 'done'].includes(s?.phase)) { await chrome.storage.local.remove(k); continue; }
    try {
      const rc = await globalThis.DA_DISPATCH_FLOW.run({ ...p2Opts({ id: Number(m[2]), login: me }, { num: Number(m[3]) }, async () => { throw new Error('recover never sends'); }), snapshot: s });
      if (P2_DROP.has(rc.state)) await chrome.storage.local.remove(k);
    } catch { /* нет связи — в следующий раз */ }
  }
}
// одно сообщение задания по протоколу 2: что делать с заданием дальше
async function p2Step(j) {
  const it = j.items[j.i];
  const { rc, raw } = await p2Item(j, it);
  const st = rc.state, err = String(raw?.error || '');
  if (st === 'ready' || raw?.defer) {   // пользователь сам в мессенджере / проверка до отправки — ждём, как раньше
    j.waitFrom = j.waitFrom || Date.now(); j.next = Date.now() + 30000;
    if (Date.now() - j.waitFrom > 4 * 60e3) return { drop: true, note: 'Вы были в мессенджере — отправка ждёт, продолжу позже' };
    return { wait: true };
  }
  j.waitFrom = 0; j.i++;
  j.last = { num: it.num, state: st, error: err || null };
  if (['stopped', 'missing', 'forbidden', 'not_found', 'update_required'].includes(st)) return { drop: true, done: st === 'stopped' ? ['stopped', 'Остановлено'] : null };
  if (st === 'failed' && /^AUTH/.test(err)) return { done: ['error', `Вход в ${MSGR[j.svc]?.title || j.svc} в браузере закончился — войдите снова`] };
  if (/^FLOOD/.test(err)) return { done: ['stopped', 'Мессенджер ограничил отправку — продолжите завтра'] };
  if (st === 'sent') { j.fails = 0; j.unknowns = 0; }
  else if (st === 'failed') j.fails = /^NOUSER/.test(err) ? 0 : (j.fails || 0) + 1;
  else if (st === 'unknown') j.unknowns = (j.unknowns || 0) + 1;
  if (j.fails >= 3) return { done: ['error', 'Три ошибки подряд — отправка остановлена'] };
  if (j.unknowns >= 2) return { done: ['error', 'Результат двух сообщений подряд не подтверждён — проверьте чат, отправка остановлена'] };
  if (j.i >= j.items.length) return { done: ['done', null] };
  j.next = Date.now() + (raw ? 25000 + Math.random() * 35000 : 0);   // пауза 25–60 с, если было что отправлять
  return {};
}
// ---- конец протокола 2 ----
async function sendTick(force = false) {
  if (!(await sendOn())) return;
  const { sendBusy = 0 } = await chrome.storage.session.get('sendBusy');
  if (!lockFree(sendBusy)) return;
  await lockTake();
  const beat = setInterval(lockTake, 20000);   // замок живой, пока идёт работа
  try {
    let { sendJob: j = null, sendPollAt = 0, sendBack = 0 } = await chrome.storage.local.get(['sendJob', 'sendPollAt', 'sendBack']);
    if (j && j.protocol === 2 && j.i < j.items.length) {
      if (Date.now() < j.next) return;
      const r = await p2Step(j);
      if (r.wait) { await chrome.storage.local.set({ sendJob: j }); return; }
      if (r.done) await autoApi('own_ext_done', { id: j.id, status: r.done[0], error: r.done[1] });
      if (r.done || r.drop) { j = null; if (r.note) await chrome.storage.local.set({ sendNote: { at: Date.now(), text: r.note } }); }
      await chrome.storage.local.set({ sendJob: j });
      return;
    }
    if (j && j.i < j.items.length) {
      if (Date.now() < j.next) return;
      const it = j.items[j.i];
      let r = null;
      // прошлая попытка этого сообщения прервалась (браузер закрыли, Chrome остановил расширение) — сначала смотрим чат
      if (j.fly && j.fly.i === j.i) {
        const was = await alreadySent(j.svc, it);
        if (was === true) r = { ok: true, warn: 'отправка прервалась, но сообщение уже в чате' };
        else if (was === null) r = { ok: false, error: 'NET: отправка прервалась — проверьте чат вручную (повторно не отправляю, чтобы не задвоить)' };
      }
      if (!r) {
        j.fly = { i: j.i, at: Date.now() }; await chrome.storage.local.set({ sendJob: j });
        r = await sendItem(j.svc, it);
      }
      if (r.defer) {
        // пользователь сам в мессенджере — ждём; дольше 4 минут — отдаём задание (через 5 минут без движения сервер сайта отправит сам)
        j.fly = null; j.waitFrom = j.waitFrom || Date.now(); j.next = Date.now() + 30000;
        if (Date.now() - j.waitFrom > 4 * 60e3) { j = null; await chrome.storage.local.set({ sendJob: null, sendNote: { at: Date.now(), text: 'Вы были в мессенджере — отправку взял сервер сайта' } }); return; }
        await chrome.storage.local.set({ sendJob: j }); return;
      }
      j.waitFrom = 0;
      const s = await autoApi('own_ext_sent', { id: j.id, num: it.num, ok: r.ok, error: r.error || null, warn: r.warn || null });
      j.fly = null; j.i++; j.fails = r.ok || /^NOUSER/.test(r.error || '') ? 0 : (j.fails || 0) + 1; j.last = { num: it.num, ok: r.ok, error: r.error || null };
      let stop = null;
      if (s?.error === 'not_found') { j = null; await chrome.storage.local.set({ sendJob: null }); return; }   // задание забрал сервер (запасной путь) — дальше не шлём
      if (/^AUTH/.test(r.error || '')) stop = ['error', `Вход в ${MSGR[j.svc]?.title || j.svc} в браузере закончился — войдите снова`];
      else if (/^FLOOD/.test(r.error || '')) stop = ['stopped', 'Мессенджер ограничил отправку — продолжите завтра'];
      else if (j.fails >= 3) stop = ['error', 'Три ошибки подряд — отправка остановлена'];
      else if (s?.stop) stop = ['stopped', 'Остановлено'];
      if (stop || j.i >= j.items.length) { await autoApi('own_ext_done', { id: j.id, status: stop ? stop[0] : 'done', error: stop ? stop[1] : null }); j = null; }
      else j.next = Date.now() + 25000 + Math.random() * 35000;   // пауза 25–60 с, как у сервера
      await chrome.storage.local.set({ sendJob: j });
      return;
    }
    if (!force && Date.now() - sendPollAt < 55000) return;
    if (!force && sendBack > Date.now()) return;
    const svcs = await loginStates();
    const cr = (await cfg().catch(() => null))?.rev;   // какая редакция настроек с сайта у расширения (видно в ext_agents.ver)
    await p2Recover().catch(() => {});
    const p = await autoApi('own_ext_poll', { protocol: 2, ver: chrome.runtime.getManifest().version + (cr ? '/' + cr : ''), svcs, ua: navigator.userAgent.slice(0, 120) });
    await chrome.storage.local.set({ sendPollAt: Date.now(), sendState: { at: Date.now(), svcs, error: p.error || null, message: p.message || null } });
    if (p.error) { if (['need_pro', 'no_auth', 'kicked'].includes(p.error)) await chrome.storage.local.set({ sendBack: Date.now() + 30 * 60e3 }); return; }
    if (p.login) await chrome.storage.local.set({ sendLogin: p.login });
    if (p.job?.items?.length) { await chrome.storage.local.set({ sendJob: { ...p.job, i: 0, next: 0, fails: 0, ...(p.protocol === 2 && p.login ? { protocol: 2, login: p.login } : {}) } }); return sendTickNow(); }
    if (p.checks?.items?.length && MSGR[p.checks.svc]) {
      const items = [];
      for (const c of p.checks.items) { const r = await readOne(p.checks.svc, c.phone); if (r.defer) break; items.push({ num: c.num, ...r }); await sleepS(2500); }
      if (items.length) await autoApi('own_ext_read', { svc: p.checks.svc, items });
    }
  } finally { clearInterval(beat); await chrome.storage.session.set({ sendBusy: 0 }); }
}
const sendTickNow = () => setTimeout(() => sendTick(false), 200);
// будильники создаём, только если их нет: создание заново при каждом пробуждении service worker сдвигало срабатывание на 30 с
// (worker будят сайт, всплывающее окно, вкладки площадок — при частых пробуждениях отправка могла не начаться вовсе)
const alarmOnce = (name, periodInMinutes) => chrome.alarms.get(name).then(a => { if (!a || a.periodInMinutes !== periodInMinutes) chrome.alarms.create(name, { periodInMinutes }); });
alarmOnce('daSend', 0.5);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'daSend') sendTick(false); });
chrome.runtime.onStartup.addListener(() => sendTick(true));
chrome.runtime.onInstalled.addListener(() => { chrome.storage.local.remove('extCfg'); sendTick(true); });   // новая версия — настройки с сайта заново, сразу

// v0.7.2: самообновление распакованного расширения — файлы в папке новее (версия в manifest.json другая) → перезапуск (раз в 2 минуты).
// Магазинной версии это не нужно (её обновляет Chrome); отправка не прерывается — проверка только когда нет задания.
async function selfUpdate() {
  try {
    const { sendBusy = 0 } = await chrome.storage.session.get('sendBusy');
    if (!lockFree(sendBusy)) return;   // идёт отправка — после неё; задание сохранено и продолжится после перезапуска
    const m = await (await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })).json();
    if (m.version && m.version !== chrome.runtime.getManifest().version) chrome.runtime.reload();
  } catch { /* нет */ }
}
alarmOnce('daSelfUpd', 2);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'daSelfUpd') selfUpdate(); });
