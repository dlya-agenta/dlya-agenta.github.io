// v0.7 (сайт v5.67, п. 2 Алексея): «Отправка через мой браузер» — расширение работает как свой сервер мессенджеров агента.
// Агент сам вошёл в WhatsApp Web / Telegram Web в этом браузере; ключи входа остаются в браузере, на сервер не передаются.
// Сайт (с компьютера или с телефона) ставит задание: auto own_send {via: 'ext'} / own_ext_msg. Расширение раз в минуту отмечается
// (own_ext_poll: «на связи» + где выполнен вход), берёт СВОЁ задание и шлёт по одному сообщению с паузой 25–60 с (как сервер),
// отчитывается own_ext_sent / own_ext_done; проверки ответов собственников — own_ext_read (чтение чата по номеру, ничего не пишет).
// Компьютер и браузер должны быть включены; вкладки мессенджеров расширение открывает само (закреплённые, в фоне).
// MAX (web.max.ru) — поиск по номеру: пишем, только если нашёлся ровно один человек (иначе — пропуск, чтобы не написать не тому).
const AUTO = 'https://arojogajdamsyrrpcmso.supabase.co/functions/v1/auto';
const MSGR = {
  wa: { url: 'https://web.whatsapp.com/', match: 'https://web.whatsapp.com/*', title: 'WhatsApp' },
  tg: { url: 'https://web.telegram.org/k/', match: 'https://web.telegram.org/*', title: 'Telegram' },
  max: { url: 'https://web.max.ru/', match: 'https://web.max.ru/*', title: 'MAX' },
};
const sleepS = ms => new Promise(s => setTimeout(s, ms));
// v0.7.3: «приметы» страниц мессенджеров (поля, кнопки, надписи) — с сайта (ext-config.json, раз в 30 минут), здесь — запасные.
// Мессенджер поменял кнопку — правим файл на сайте, у всех агентов работает через несколько минут без переустановки. Код с сайта не грузится (правило Chrome).
const CFG0 = {
  wa: { ok: '#side, #pane-side, [data-testid="chat-list"]', qr: 'canvas[aria-label*="QR" i], [data-ref] canvas, [data-testid="qrcode"]',
    authText: 'Используйте WhatsApp на телефоне|Use WhatsApp on your phone|Войти по номеру|Log in with phone', badText: 'недействител|invalid|не зарегистрирован|isn.t on WhatsApp',
    box: '#main footer div[contenteditable="true"]', send: '#main footer button[aria-label="Отправить"], #main footer button[aria-label="Send"], #main footer span[data-icon="send"], #main footer span[data-icon="wds-ic-send-filled"]',
    previewSend: 'div[role="button"][aria-label="Отправить"], div[role="button"][aria-label="Send"], span[data-icon="wds-ic-send-filled"], span[data-icon="send"]',
    msgs: '#main div.message-in, #main div.message-out', out: 'message-out', pre: '[data-pre-plain-text]', text: 'span.selectable-text, .copyable-text span' },
  tg: { auth: '.auth-pages, #auth-pages, .page-signQR, .page-sign' },
  max: { search: 'input[placeholder="Найти"], input[placeholder="Найти чат или канал"], input[placeholder^="Поиск"]', authText: 'Войти|номер телефона|QR|Отсканируйте',
    allTab: '^Все(\\s|$)', findByPhone: 'Найти по номеру', notFound: 'не найден|не зарегистрирован|нет в MAX|Пользователь не найден',
    items: '.scrollable .item', cells: '.scrollable .item button.cell', composer: 'main div.contenteditable, div.contenteditable[data-placeholder="Сообщение"], main [contenteditable="true"]',
    dialogComposer: '[role="dialog"] div.contenteditable, [role="dialog"] [contenteditable="true"]', sendBtn: 'button[aria-label*="Отправить"], button[title*="Отправить"]',
    msgItems: 'main .item[data-index]', bubble: '.bubble' },
};
const CFG_URL = 'https://dlya-agenta.github.io/ext-config.json';
// «0.8.0» новее «0.7.10»: по числам
const verNewer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function cfg() {
  const { extCfg = null } = await chrome.storage.local.get('extCfg');
  if (extCfg && Date.now() - extCfg.at < 30 * 60e3) return extCfg.v;
  let v = extCfg?.v || null;
  try { const r = await fetch(CFG_URL + '?t=' + Math.floor(Date.now() / 6e5), { cache: 'no-store' }); if (r.ok) { const j = await r.json(); if (j && typeof j === 'object') v = j; } } catch { /* сайт недоступен — прежние */ }
  await chrome.storage.local.set({ extCfg: { at: Date.now(), v } });
  return v;
}
// для мессенджера: запасные + с сайта (только строки — это данные, не код)
async function C(svc) {
  const site = (await cfg())?.[svc] || {}, out = { ...CFG0[svc] };
  for (const [k, v] of Object.entries(site)) if (typeof v === 'string' && v.length < 600) out[k] = v;
  return out;
}
async function autoApi(action, extra = {}) {
  const { token } = await chrome.storage.local.get('token');
  if (!token) return { error: 'no_auth' };
  try {
    const r = await fetch(AUTO, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, auth: { token }, ...extra }) });
    return await r.json().catch(() => ({ error: 'server' }));
  } catch { return { error: 'net' }; }
}
const sendOn = async () => (await DA.getSettings()).sendVia !== false;

// ---- вкладка мессенджера: уже открытая или новая закреплённая в фоне ----
async function msgTab(svc, open = true) {
  const [t] = await chrome.tabs.query({ url: MSGR[svc].match });
  if (t || !open) return t || null;
  const n = await chrome.tabs.create({ url: MSGR[svc].url, active: false, pinned: true });
  await tabLoaded(n.id);
  return n;
}
async function tabLoaded(tabId, ms = 45000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return false; if (t.status === 'complete') return true; await sleepS(700); }
  return false;
}
const run = async (tabId, func, args = []) => { const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args }).catch(e => [{ result: { e: String(e?.message || e) } }]); return result; };

// вход в мессенджер (в странице): ok | auth (нужен вход: QR / телефон) | wait
function pageState(svc, c) {
  if (svc === 'max') {
    if (document.querySelector(c.search)) return 'ok';
    return new RegExp(c.authText, 'i').test(document.body?.innerText || '') && !document.querySelector(c.items) ? 'auth' : 'wait';
  }
  if (svc === 'tg') { const R = window.rootScope; if (R && R.managers && R.myId) return 'ok'; return localStorage.getItem('user_auth') ? 'wait' : (document.querySelector(c.auth) ? 'auth' : 'wait'); }
  if (document.querySelector(c.ok)) return 'ok';
  if (document.querySelector(c.qr)) return 'auth';
  return new RegExp(c.authText, 'i').test(document.body?.innerText || '') ? 'auth' : 'wait';
}
async function ready(svc, tabId, ms = 60000) {
  const t0 = Date.now(); let st = 'wait';
  const c = await C(svc);
  while (Date.now() - t0 < ms) { st = await run(tabId, pageState, [svc, c]); if (st === 'ok' || (st === 'auth' && Date.now() - t0 > 12000)) break; await sleepS(1500); }
  await remember(svc, st === 'ok' ? 'ok' : st === 'auth' ? 'auth' : null);
  return st;
}
async function remember(svc, st) {
  if (!st) return;
  const { msgLogin = {} } = await chrome.storage.local.get('msgLogin');
  msgLogin[svc] = { st, at: Date.now() }; await chrome.storage.local.set({ msgLogin });
}
// где выполнен вход — для сайта («Через мой браузер: WhatsApp ✓, Telegram — войдите»): открытая вкладка проверяется, иначе — последнее известное (7 дней)
async function loginStates() {
  const { msgLogin = {} } = await chrome.storage.local.get('msgLogin'), out = {};
  for (const svc of Object.keys(MSGR)) {
    const t = await msgTab(svc, false);
    if (t?.status === 'complete') { const st = await run(t.id, pageState, [svc, await C(svc)]); if (st === 'ok' || st === 'auth') { await remember(svc, st); out[svc] = st; continue; } }
    const m = msgLogin[svc]; out[svc] = m && Date.now() - m.at < 7 * 864e5 ? m.st : 'none';
  }
  return out;
}

// ---- Telegram Web K: контакт по номеру → фото с подписью / текст (тот же способ, что на сервере, worker/msg.ts tgToPhone) ----
async function tgSendPage(phone, name, text, photo) {
  const M = window.rootScope.managers; let id = 0;
  try {
    try { const r = await M.apiManager.invokeApi('contacts.importContacts', { contacts: [{ _: 'inputPhoneContact', client_id: String(Date.now()), phone, first_name: name || 'Собственник', last_name: '' }] });
      if (r && r.users && M.appUsersManager.saveApiUsers) await M.appUsersManager.saveApiUsers(r.users);
      id = r && r.imported && r.imported[0] ? r.imported[0].user_id : 0; }
    catch (e) { id = await M.appUsersManager.importContact(name || 'Собственник', '', phone).catch(() => 0); }
    if (!id) return 'NOUSER: номера нет в Telegram';
    let file = null;
    if (photo) { try { file = new File([Uint8Array.from(atob(photo), c => c.charCodeAt(0))], 'photo.jpg', { type: 'image/jpeg' }); } catch (e) { /* без фото */ } }
    if (file) { try { if (text.length > 1000) await M.appMessagesManager.sendFile({ peerId: Number(id), file, isMedia: true });
      else { await M.appMessagesManager.sendFile({ peerId: Number(id), file, caption: text, isMedia: true }); return ''; } }
      catch (e) { if (/FLOOD|SPAM|RESTRICTED/.test(String(e && (e.type || e.message)))) throw e; } }
    await M.appMessagesManager.sendText({ peerId: Number(id), text });
    return '';
  } catch (e) { const t = String((e && (e.type || e.message)) || e || 'ошибка'); return /FLOOD|SPAM|RESTRICTED/.test(t) ? 'FLOOD: ' + t : t; }
}
async function tgReadPage(phone) {
  const M = window.rootScope.managers, digits = phone.replace(/\D/g, ''); let id = 0;
  try {
    try { const x = await M.apiManager.invokeApi('contacts.resolvePhone', { phone: digits });
      if (x && x.users && M.appUsersManager.saveApiUsers) await M.appUsersManager.saveApiUsers(x.users);
      id = x && x.peer && x.peer.user_id ? x.peer.user_id : (x && x.users && x.users[0] ? x.users[0].id : 0); }
    catch (e) { const t = String(e && (e.type || e.message)); if (/AUTH_KEY|SESSION_REVOKED|FLOOD/.test(t)) return { e: t }; }
    if (!id) return { e: 'NOUSER: нет переписки в Telegram' };
    const peerId = Number(id), h = await M.appMessagesManager.getHistory({ peerId, limit: 30 }), out = [];
    for (const mid of (h.history || []).slice(0, 30)) { const m = await M.appMessagesManager.getMessageByPeer(peerId, mid); if (!m || m._ === 'messageService') continue;
      const t = String(m.message || '').trim() || (m.media ? (m.media._ === 'messageMediaPhoto' ? '[фото]' : '[файл]') : ''); if (!t) continue;
      out.push({ who: m.pFlags && m.pFlags.out ? 'me' : 'owner', text: t.slice(0, 1000), at: new Date((m.date || 0) * 1000).toISOString() }); }
    return { msgs: out.sort((a, b) => a.at < b.at ? -1 : 1) };
  } catch (e) { return { e: String((e && (e.type || e.message)) || e || 'ошибка') }; }
}

// ---- v0.7.4: страница делает только мгновенные шаги (без своих таймеров), все ожидания — в расширении ----
// Причина (проверка 12.11 на компьютере Алексея): во вкладке, которая несколько минут в фоне, Chrome выполняет таймеры страницы раз в минуту —
// ожидания внутри страницы растягивались на минуты, и Chrome обрывал работу расширения. Таймеры расширения так не замедляются.
function pg(op, a, c) {
  const q = s => document.querySelector(s), norm = t => String(t || '').replace(/\s+/g, ' ').trim();
  const file = b64 => { const dt = new DataTransfer(); dt.items.add(new File([Uint8Array.from(atob(b64), ch => ch.charCodeAt(0))], 'photo.jpg', { type: 'image/jpeg' })); return dt; };
  const type = (el, text) => { el.focus(); String(text).split('\n').forEach((l, i) => { if (i) document.execCommand('insertLineBreak'); if (l) document.execCommand('insertText', false, l); }); };
  try {
    // WhatsApp
    if (op === 'wa_open') { const dlg = q('[role="dialog"]'); if (dlg && new RegExp(c.badText, 'i').test(dlg.innerText || '')) return 'bad'; return q(c.box) ? 'ok' : 'wait'; }
    if (op === 'wa_state') return { n: document.querySelectorAll(c.msgs).length, box: norm(q(c.box)?.innerText) };
    if (op === 'wa_paste') { const box = q(c.box); if (!box) return 'nobox'; box.focus(); box.dispatchEvent(new ClipboardEvent('paste', { clipboardData: file(a.pic), bubbles: true, cancelable: true })); return 'ok'; }
    if (op === 'wa_preview') { const b = [...document.querySelectorAll(c.previewSend)].find(x => !x.closest('footer')); if (!b) return 'wait'; (b.closest('[role="button"], button') || b).click(); return 'ok'; }
    if (op === 'wa_send') { const b = q(c.send); if (!b) return 'nobtn'; (b.closest('button') || b).click(); return 'ok'; }
    if (op === 'wa_read') return [...document.querySelectorAll(c.msgs)].slice(-30).map(e => {
      const x = e.querySelector(c.pre), t = e.querySelector(c.text);
      return { out: e.classList.contains(c.out), pre: x?.getAttribute('data-pre-plain-text') || '', t: String(t?.innerText || '').trim(), media: !!e.querySelector('img, video') }; });
    // MAX
    const input = () => q(c.search);
    const set = v => { const s = input(); if (!s) return; Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(s, v); s.dispatchEvent(new Event('input', { bubbles: true })); };
    if (op === 'mx_tab') { const all = [...document.querySelectorAll('button, a, [role="tab"]')].find(b => new RegExp(c.allTab).test((b.innerText || '').trim())); if (all) all.click(); return 'ok'; }
    // вкладка «Все» перерисовывает поле поиска и стирает номер — поэтому сначала mx_tab, пауза, потом ввод (и проверка, что номер в поле)
    if (op === 'mx_search') { if (!input()) return 'nosearch'; input().focus(); set(a.phone); return location.pathname; }
    if (op === 'mx_val') return input()?.value || '';
    // «Найти по номеру» — в списке результатов или где угодно на странице (кнопка / пункт с ровно этим текстом)
    const findAct = () => [...document.querySelectorAll(c.items)].find(e => new RegExp(c.findByPhone, 'i').test(e.innerText || ''))
      || [...document.querySelectorAll('button, [role="button"], li, a')].find(e => new RegExp('^\\s*(' + c.findByPhone + ')\\s*$', 'i').test(e.innerText || ''));
    // найденные чаты; один человек бывает дважды (чат и контакт) — считаем по имени
    const people = () => [...new Set([...document.querySelectorAll(c.cells)].map(e => norm((e.innerText || '').split('\n')[0])).filter(Boolean))];
    if (op === 'mx_found') return { act: !!findAct(), cells: document.querySelectorAll(c.cells).length, people: people(), dbg: norm(q('.scrollable')?.innerText).slice(0, 160) };
    if (op === 'mx_pick') {   // «Найти по номеру» — точный поиск; иначе — единственный найденный чат
      const act = findAct();
      if (act) { (act.querySelector('button') || act).click(); return 'act'; }
      const cells = document.querySelectorAll(c.cells), ppl = people();
      if (cells.length && ppl.length === 1) { cells[0].click(); return 'cell'; }
      return cells.length ? 'many' : 'none';
    }
    if (op === 'mx_chat') return location.pathname !== a.was && /^\/-?\d+/.test(location.pathname) && !!q(c.composer) ? 'ok' : new RegExp(c.notFound, 'i').test(document.body.innerText.slice(0, 5000)) ? 'none' : 'wait';
    if (op === 'mx_clear') { set(''); return 'ok'; }
    if (op === 'mx_has') { const head = norm(a.text).slice(0, 24); return [...document.querySelectorAll(c.msgItems)].slice(-3).some(e => norm(e.innerText).includes(head)); }
    if (op === 'mx_paste') { const box = q(c.composer); if (!box) return 'nobox'; box.focus(); box.dispatchEvent(new ClipboardEvent('paste', { clipboardData: file(a.pic), bubbles: true, cancelable: true })); return 'ok'; }
    const tgt = () => (a.dialog && q(c.dialogComposer)) || q(c.composer);
    if (op === 'mx_type') { const t = tgt(); if (!t) return 'nobox'; type(t, a.text); return 'ok'; }
    // кнопка «Отправить» появляется после ввода (вместо микрофона) — её ждёт расширение; нет — Enter
    if (op === 'mx_sendbtn') { const t = tgt(); const btn = t && (t.closest('[role="dialog"]') || q('main') || document).querySelector(c.sendBtn); if (!btn) return 'wait'; btn.click(); return 'ok'; }
    if (op === 'mx_enter') { const t = tgt(); t?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); return 'ok'; }
    if (op === 'mx_wipe') { const t = tgt(); if (!t) return 'nobox'; t.focus(); const r = document.createRange(); r.selectNodeContents(t); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(r);
      document.execCommand('delete'); if (norm(t.innerText)) { t.innerHTML = ''; t.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' })); } return norm(t.innerText); }
    if (op === 'mx_dbg') return { box: norm(tgt()?.innerText).slice(0, 60), last: [...document.querySelectorAll(c.msgItems)].slice(-1).map(e => norm(e.innerText).slice(-70))[0] || '',
      btns: [...(q('main') || document).querySelectorAll('button')].map(b => b.getAttribute('aria-label') || '').filter(Boolean).slice(-4).join('|') };
    if (op === 'mx_box') return norm(((a.dialog && q(c.dialogComposer)) || q(c.composer))?.innerText);
    if (op === 'mx_read') {
      const main = q('main')?.getBoundingClientRect(), mid = main ? main.left + main.width / 2 : innerWidth / 2;
      return [...document.querySelectorAll(c.msgItems)].slice(-30).map(e => {
        const b = e.querySelector(c.bubble); if (!b) return null;
        const cls = String(e.className || '') + ' ' + String(b.className || ''), r = b.getBoundingClientRect();
        const own = /(^|[\s_-])(out|outgoing|own|self|mine|isOwn|my)([\s_-]|$)/i.test(cls) || (!/(^|[\s_-])(in|incoming)([\s_-]|$)/i.test(cls) && r.left + r.width / 2 > mid + 20);
        const full = String(b.innerText || '').trim(), hm = /(\d{1,2}):(\d{2})\s*$/.exec(full);
        let at = new Date(); if (hm) { at.setHours(+hm[1], +hm[2], 0, 0); if (at.getTime() > Date.now() + 5 * 60e3) at = new Date(at.getTime() - 864e5); }
        return { who: own ? 'me' : 'owner', text: full.replace(/\s*(ред\.\s*)?\d{1,2}:\d{2}\s*$/, '').trim().slice(0, 1000), at: at.toISOString() };
      }).filter(x => x && x.text);
    }
    return 'unknown';
  } catch (e) { return { e: String(e?.message || e) }; }
}
const P = (tabId, op, a, c) => run(tabId, pg, [op, a || {}, c]);
// ждать (в расширении), пока шаг страницы не вернёт подходящее
async function until(fn, ok, ms, step = 700) { const t0 = Date.now(); let v; while (Date.now() - t0 < ms) { v = await fn(); if (ok(v)) return v; await sleepS(step); } return v; }

// «[15:30, 03.11.2026] Имя: » → время ISO (браузер агента — в его часовом поясе, время из строки — местное)
function waTimeLocal(pre) {
  const m = /\[(\d{1,2}):(\d{2})(?:\s*([AP]M))?,\s*(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})\]/i.exec(pre || '');
  if (!m) return new Date().toISOString();
  let h = +m[1]; if (m[3]) h = h % 12 + (/p/i.test(m[3]) ? 12 : 0);
  const a = +m[4], b = +m[5], c = +m[6], [y, mo, d] = a > 999 ? [a, b, c] : pre.includes('/') ? [c, a, b] : [c, b, a];
  return new Date(y < 100 ? 2000 + y : y, mo - 1, d, h, +m[2]).toISOString();
}
// WhatsApp: send?phone=&text= — чат с готовым текстом
async function waGo(tabId, phone, text, c) {
  const d = phone.replace(/\D/g, '');
  await chrome.tabs.update(tabId, { url: `https://web.whatsapp.com/send?phone=${d}${text ? `&text=${encodeURIComponent(text)}` : ''}` });
  await sleepS(1500); await tabLoaded(tabId);
  const st = await ready('wa', tabId, 60000);
  if (st !== 'ok') return st === 'auth' ? 'AUTH: войдите в WhatsApp Web в этом браузере' : 'NET: WhatsApp не загрузился';
  const o = await until(() => P(tabId, 'wa_open', {}, c), v => v === 'ok' || v === 'bad', 45000, 1000);
  return o === 'bad' ? 'NOUSER: номера нет в WhatsApp' : o === 'ok' ? '' : 'чат не открылся';
}
async function waSend(tabId, it, pic, c) {
  let e = await waGo(tabId, it.phone, it.text, c); if (e) return e;
  await sleepS(800);
  const s0 = await P(tabId, 'wa_state', {}, c);
  if (pic) {   // фото — вставкой и «Отправить» в окне предпросмотра; текст остаётся в поле и уходит следом
    if (await P(tabId, 'wa_paste', { pic }, c) === 'ok' && await until(() => P(tabId, 'wa_preview', {}, c), v => v === 'ok', 9000) === 'ok') {
      await until(() => P(tabId, 'wa_state', {}, c), v => v?.n > s0.n, 15000, 1000);
      const s1 = await P(tabId, 'wa_state', {}, c);
      if (!s1?.box && s0?.box) { e = await waGo(tabId, it.phone, it.text, c); if (e) return e; await sleepS(800); }   // текст пропал — откроем чат с текстом заново
    }
  }
  const s2 = await P(tabId, 'wa_state', {}, c);
  if (await P(tabId, 'wa_send', {}, c) !== 'ok') return 'нет кнопки «Отправить»';
  const s3 = await until(() => P(tabId, 'wa_state', {}, c), v => v?.n > s2.n && !v.box, 10000, 800);
  return s3?.n > s2.n && !s3.box ? '' : (s3?.box?.length > 3 ? 'сообщение не ушло' : '');
}
// MAX: поиск по номеру → «Найти по номеру» (точный) или единственный чат
async function maxOpen(phone) {
  const tab = await msgTab('max'), c = await C('max');
  const st = await ready('max', tab.id);
  if (st !== 'ok') return { e: st === 'auth' ? 'AUTH: войдите в MAX (web.max.ru) в этом браузере' : 'NET: MAX не загрузился' };
  // открыт чат — сначала к списку чатов (иначе «Найти по номеру» с этим же человеком не меняет адрес, а при ненайденном номере
  // осталcя бы открытым прежний чат — и сообщение ушло бы не тому)
  const t0 = await chrome.tabs.get(tab.id);
  if (!/^https:\/\/web\.max\.ru\/?(\?|#|$)/.test(t0.url || '')) {
    await chrome.tabs.update(tab.id, { url: 'https://web.max.ru/' }); await sleepS(1500); await tabLoaded(tab.id);
    if (await ready('max', tab.id) !== 'ok') return { e: 'NET: MAX не загрузился' };
  }
  await P(tab.id, 'mx_tab', {}, c); await sleepS(900);
  const was = await P(tab.id, 'mx_search', { phone }, c);
  if (typeof was === 'string' && was !== 'nosearch' && /^\/-?\d+/.test(was)) return { e: 'NET: MAX не вернулся к списку чатов' };
  await sleepS(600);
  if ((await P(tab.id, 'mx_val', {}, c)) !== phone) { await P(tab.id, 'mx_search', { phone }, c); await sleepS(600); }
  if ((await P(tab.id, 'mx_val', {}, c)) !== phone) return { e: 'NET: номер не вводится в поиск MAX' };
  if (was === 'nosearch' || typeof was !== 'string') return { e: 'NET: нет поиска в MAX' };
  // сначала ждём «Найти по номеру» (появляется позже первых результатов); нет его за 7 с — смотрим найденные чаты
  const f = await until(() => P(tab.id, 'mx_found', {}, c), v => v?.act, 7000, 500);
  if (!f?.act) await sleepS(500);
  const how = await P(tab.id, 'mx_pick', {}, c);
  if (how === 'many' || how === 'none') {
    const seen = await P(tab.id, 'mx_found', {}, c);   // что видно в поиске — в ошибку (агенту и для починки)
    await P(tab.id, 'mx_clear', {}, c);
    return { e: (how === 'many' ? 'NOUSER: по номеру нашлось несколько чатов' : 'NOUSER: номера нет в MAX') + (seen?.people?.length ? ` (${seen.people.slice(0, 4).join('; ').slice(0, 120)})` : '') + (seen?.dbg ? ` [${seen.dbg}]` : '') };
  }
  const ch = await until(() => P(tab.id, 'mx_chat', { was }, c), v => v === 'ok' || v === 'none', 9000, 500);
  await P(tab.id, 'mx_clear', {}, c);
  return ch === 'ok' ? { tab, c } : { e: 'NOUSER: номера нет в MAX' };
}
async function maxSend(it, pic) {
  const o = await maxOpen(it.phone); if (o.e) return o.e;
  const { tab, c } = o;
  await sleepS(1200);
  const had = await P(tab.id, 'mx_has', { text: it.text }, c);
  let dialog = false;
  if (pic && await P(tab.id, 'mx_paste', { pic }, c) === 'ok') { await sleepS(2500); dialog = true; }
  if (!dialog) await P(tab.id, 'mx_wipe', {}, c);   // в поле мог остаться черновик — иначе он ушёл бы вместе с нашим текстом
  if (await P(tab.id, 'mx_type', { text: it.text, dialog }, c) !== 'ok') return 'в этот чат нельзя писать';
  if (await until(() => P(tab.id, 'mx_sendbtn', { dialog }, c), v => v === 'ok', 4000, 400) !== 'ok') await P(tab.id, 'mx_enter', { dialog }, c);
  const ok = await until(async () => had ? !(await P(tab.id, 'mx_box', { dialog: false }, c)) : await P(tab.id, 'mx_has', { text: it.text }, c), v => v === true, 10000, 700);
  if (ok === true) return '';
  const d = await P(tab.id, 'mx_dbg', { dialog }, c);
  const left = await P(tab.id, 'mx_wipe', { dialog }, c);   // не ушло — черновик убираем, чтобы потом не ушёл случайно
  return `сообщение не ушло [поле: ${d?.box || '—'} · последнее: ${d?.last || '—'} · кнопки: ${d?.btns || '—'}${left ? ' · черновик не стёрся' : ''}]`;
}

// фото к сообщению качает расширение (у WhatsApp / MAX / Telegram строгие правила страницы — оттуда наше хранилище не открыть),
// в страницу уходит base64; страница сама собирает файл
async function photoB64(u) {
  if (!u || !/^https:\/\/([a-z0-9-]+\.)*supabase\.co\//.test(u)) return '';
  try { const r = await fetch(u); if (!r.ok) return ''; const b = new Uint8Array(await r.arrayBuffer()); if (b.length > 4e6) return '';
    let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000)); return btoa(s); } catch { return ''; }
}

// ---- одно сообщение ----
async function sendOne(svc, it) {
  if (!MSGR[svc]) return { ok: false, error: 'неизвестный мессенджер' };
  const pic = await photoB64(it.photo);
  if (svc === 'max') { const e = await maxSend(it, pic); return e ? { ok: false, error: e } : { ok: true }; }
  const tab = await msgTab(svc);
  if (svc === 'tg') {
    const st = await ready('tg', tab.id);
    if (st !== 'ok') return { ok: false, error: st === 'auth' ? 'AUTH: войдите в Telegram Web в этом браузере' : 'NET: Telegram не загрузился' };
    const e = await run(tab.id, tgSendPage, [it.phone, it.name || '', it.text, pic]);
    return e ? { ok: false, error: typeof e === 'string' ? e : 'ошибка' } : { ok: true };
  }
  const e = await waSend(tab.id, it, pic, await C('wa'));
  return e ? { ok: false, error: e } : { ok: true };
}
async function readOne(svc, phone) {
  if (svc === 'max') { const o = await maxOpen(phone); if (o.e) return { ok: false, error: o.e };
    await sleepS(1500); const msgs = await P(o.tab.id, 'mx_read', {}, o.c); return Array.isArray(msgs) && msgs.length ? { ok: true, msgs } : { ok: false, error: 'NET: история чата MAX не загрузилась' }; }
  const tab = await msgTab(svc);
  if (svc === 'tg') {
    const st = await ready('tg', tab.id);
    if (st !== 'ok') return { ok: false, error: st === 'auth' ? 'AUTH: вход в Telegram закончился' : 'NET: Telegram не загрузился' };
    const r = await run(tab.id, tgReadPage, [phone]);
    if (r?.e) return { ok: false, error: /^NOUSER/.test(r.e) ? r.e : /AUTH_KEY|SESSION_REVOKED/.test(r.e) ? 'AUTH: ' + r.e : /FLOOD/.test(r.e) ? 'FLOOD: ' + r.e : 'NET: ' + r.e.slice(0, 160) };
    return { ok: true, msgs: r?.msgs || [] };
  }
  const c = await C('wa');
  const e = await waGo(tab.id, phone, '', c);
  if (e) return { ok: false, error: /^(AUTH|NOUSER)/.test(e) ? e : 'NET: ' + e };
  await until(() => P(tab.id, 'wa_state', {}, c), v => v?.n > 0, 10000, 500); await sleepS(1500);
  const raw = await P(tab.id, 'wa_read', {}, c);
  const msgs = (Array.isArray(raw) ? raw : []).map(x => ({ who: x.out ? 'me' : 'owner', text: (x.t || (x.media ? '[файл]' : '')).slice(0, 1000), at: waTimeLocal(x.pre) })).filter(m => m.text);
  return msgs.length ? { ok: true, msgs } : { ok: false, error: 'NET: история чата WhatsApp не загрузилась' };
}

// ---- такт (будильник раз в 30 с): одно сообщение задания или опрос сервера; работа — под замком ----
async function sendTick(force = false) {
  if (!(await sendOn())) return;
  const { sendBusy = 0 } = await chrome.storage.session.get('sendBusy');
  if (Date.now() - sendBusy < 4 * 60e3) return;
  await chrome.storage.session.set({ sendBusy: Date.now() });
  try {
    let { sendJob: j = null, sendPollAt = 0, sendBack = 0 } = await chrome.storage.local.get(['sendJob', 'sendPollAt', 'sendBack']);
    if (j && j.i < j.items.length) {
      if (Date.now() < j.next) return;
      // сторож: одно сообщение — не дольше 3 минут (страница могла «замереть» в фоне), дальше — ошибка и следующее
      const it = j.items[j.i], r = await Promise.race([sendOne(j.svc, it).catch(e => ({ ok: false, error: String(e?.message || e) })), sleepS(180000).then(() => ({ ok: false, error: 'NET: мессенджер не ответил за 3 минуты' }))]);
      const s = await autoApi('own_ext_sent', { id: j.id, num: it.num, ok: r.ok, error: r.error || null });
      j.i++; j.fails = r.ok || /^NOUSER/.test(r.error || '') ? 0 : (j.fails || 0) + 1; j.last = { num: it.num, ok: r.ok, error: r.error || null };
      let stop = null;
      if (/^AUTH/.test(r.error || '')) stop = ['error', `Вход в ${MSGR[j.svc]?.title || j.svc} в браузере закончился — войдите снова`];
      else if (/^FLOOD/.test(r.error || '')) stop = ['stopped', 'Мессенджер ограничил отправку — продолжите завтра'];
      else if (j.fails >= 3) stop = ['error', 'Три ошибки подряд — отправка остановлена'];
      else if (s?.stop) stop = ['stopped', 'Остановлено'];
      if (stop || j.i >= j.items.length) { await autoApi('own_ext_done', { id: j.id, status: stop ? stop[0] : 'done', error: stop ? stop[1] : null }); j = null; }
      else j.next = Date.now() + 25000 + Math.random() * 35000;   // пауза 25–60 с, как у сервера
      await chrome.storage.local.set({ sendJob: j });
      return;
    }
    if (!force && Date.now() - sendPollAt < 55000) return;
    if (!force && sendBack > Date.now()) return;
    const svcs = await loginStates();
    const cr = (await cfg().catch(() => null))?.rev;   // какая редакция настроек с сайта у расширения (видно в ext_agents.ver)
    const p = await autoApi('own_ext_poll', { ver: chrome.runtime.getManifest().version + (cr ? '/' + cr : ''), svcs, ua: navigator.userAgent.slice(0, 120) });
    await chrome.storage.local.set({ sendPollAt: Date.now(), sendState: { at: Date.now(), svcs, error: p.error || null, message: p.message || null } });
    if (p.error) { if (['need_pro', 'no_auth', 'kicked'].includes(p.error)) await chrome.storage.local.set({ sendBack: Date.now() + 30 * 60e3 }); return; }
    if (p.job?.items?.length) { await chrome.storage.local.set({ sendJob: { ...p.job, i: 0, next: 0, fails: 0 } }); return sendTickNow(); }
    if (p.checks?.items?.length && MSGR[p.checks.svc]) {
      const items = [];
      for (const c of p.checks.items) { const r = await readOne(p.checks.svc, c.phone); items.push({ num: c.num, ...r }); await chrome.storage.session.set({ sendBusy: Date.now() }); await sleepS(2500); }
      await autoApi('own_ext_read', { svc: p.checks.svc, items });
    }
  } finally { await chrome.storage.session.set({ sendBusy: 0 }); }
}
const sendTickNow = () => setTimeout(() => sendTick(false), 200);
chrome.alarms.create('daSend', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'daSend') sendTick(false); });
chrome.runtime.onStartup.addListener(() => sendTick(true));
chrome.runtime.onInstalled.addListener(() => sendTick(true));

// v0.7.2: самообновление распакованного расширения — файлы в папке новее (версия в manifest.json другая) → перезапуск (раз в 2 минуты).
// Магазинной версии это не нужно (её обновляет Chrome); отправка не прерывается — проверка только когда нет задания.
async function selfUpdate() {
  try {
    const { sendBusy = 0 } = await chrome.storage.session.get('sendBusy');
    if (sendBusy && Date.now() - sendBusy < 4 * 60e3) return;   // идёт отправка — после неё; задание сохранено и продолжится после перезапуска
    const m = await (await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })).json();
    if (m.version && m.version !== chrome.runtime.getManifest().version) chrome.runtime.reload();
  } catch { /* нет */ }
}
chrome.alarms.create('daSelfUpd', { periodInMinutes: 2 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'daSelfUpd') selfUpdate(); });
