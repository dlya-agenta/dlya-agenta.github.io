// v0.7 (сайт v5.67, п. 2 Алексея): «Отправка через мой браузер» — расширение работает как свой сервер мессенджеров агента.
// Агент сам вошёл в WhatsApp Web / Telegram Web в этом браузере; ключи входа остаются в браузере, на сервер не передаются.
// Сайт (с компьютера или с телефона) ставит задание: auto own_send {via: 'ext'} / own_ext_msg. Расширение раз в минуту отмечается
// (own_ext_poll: «на связи» + где выполнен вход), берёт СВОЁ задание и шлёт по одному сообщению с паузой 25–60 с (как сервер),
// отчитывается own_ext_sent / own_ext_done; проверки ответов собственников — own_ext_read (чтение чата по номеру, ничего не пишет).
// Компьютер и браузер должны быть включены; вкладки мессенджеров расширение открывает само (закреплённые, в фоне).
// MAX (web.max.ru) — поиск по номеру: пишем, только если нашёлся ровно один человек (иначе — пропуск, чтобы не написать не тому).
const AUTO = 'https://arojogajdamsyrrpcmso.supabase.co/functions/v1/auto';
const MSGR = {
  wa: { url: 'https://web.whatsapp.com/', match: 'https://web.whatsapp.com/*', title: 'WhatsApp' },
  tg: { url: 'https://web.telegram.org/k/', match: 'https://web.telegram.org/*', title: 'Telegram' },
  max: { url: 'https://web.max.ru/', match: 'https://web.max.ru/*', title: 'MAX' },
};
const sleepS = ms => new Promise(s => setTimeout(s, ms));
async function autoApi(action, extra = {}) {
  const { token } = await chrome.storage.local.get('token');
  if (!token) return { error: 'no_auth' };
  try {
    const r = await fetch(AUTO, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, auth: { token }, ...extra }) });
    return await r.json().catch(() => ({ error: 'server' }));
  } catch { return { error: 'net' }; }
}
const sendOn = async () => (await DA.getSettings()).sendVia !== false;

// ---- вкладка мессенджера: уже открытая или новая закреплённая в фоне ----
async function msgTab(svc, open = true) {
  const [t] = await chrome.tabs.query({ url: MSGR[svc].match });
  if (t || !open) return t || null;
  const n = await chrome.tabs.create({ url: MSGR[svc].url, active: false, pinned: true });
  await tabLoaded(n.id);
  return n;
}
async function tabLoaded(tabId, ms = 45000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return false; if (t.status === 'complete') return true; await sleepS(700); }
  return false;
}
const run = async (tabId, func, args = []) => { const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args }).catch(e => [{ result: { e: String(e?.message || e) } }]); return result; };

// вход в мессенджер (в странице): ok | auth (нужен вход: QR / телефон) | wait
function pageState(svc) {
  if (svc === 'max') {
    if (document.querySelector('input[placeholder="Найти"], input[placeholder="Найти чат или канал"], input[placeholder^="Поиск"]')) return 'ok';
    return /Войти|номер телефона|QR|Отсканируйте/i.test(document.body?.innerText || '') && !document.querySelector('.scrollable .item') ? 'auth' : 'wait';
  }
  if (svc === 'tg') { const R = window.rootScope; if (R && R.managers && R.myId) return 'ok'; return localStorage.getItem('user_auth') ? 'wait' : (document.querySelector('.auth-pages, #auth-pages, .page-signQR, .page-sign') ? 'auth' : 'wait'); }
  if (document.querySelector('#side, #pane-side, [data-testid="chat-list"]')) return 'ok';
  if (document.querySelector('canvas[aria-label*="QR" i], [data-ref] canvas, [data-testid="qrcode"]')) return 'auth';
  return /Используйте WhatsApp на телефоне|Use WhatsApp on your phone|Войти по номеру|Log in with phone/i.test(document.body?.innerText || '') ? 'auth' : 'wait';
}
async function ready(svc, tabId, ms = 60000) {
  const t0 = Date.now(); let st = 'wait';
  while (Date.now() - t0 < ms) { st = await run(tabId, pageState, [svc]); if (st === 'ok' || (st === 'auth' && Date.now() - t0 > 12000)) break; await sleepS(1500); }
  await remember(svc, st === 'ok' ? 'ok' : st === 'auth' ? 'auth' : null);
  return st;
}
async function remember(svc, st) {
  if (!st) return;
  const { msgLogin = {} } = await chrome.storage.local.get('msgLogin');
  msgLogin[svc] = { st, at: Date.now() }; await chrome.storage.local.set({ msgLogin });
}
// где выполнен вход — для сайта («Через мой браузер: WhatsApp ✓, Telegram — войдите»): открытая вкладка проверяется, иначе — последнее известное (7 дней)
async function loginStates() {
  const { msgLogin = {} } = await chrome.storage.local.get('msgLogin'), out = {};
  for (const svc of Object.keys(MSGR)) {
    const t = await msgTab(svc, false);
    if (t?.status === 'complete') { const st = await run(t.id, pageState, [svc]); if (st === 'ok' || st === 'auth') { await remember(svc, st); out[svc] = st; continue; } }
    const m = msgLogin[svc]; out[svc] = m && Date.now() - m.at < 7 * 864e5 ? m.st : 'none';
  }
  return out;
}

// ---- Telegram Web K: контакт по номеру → фото с подписью / текст (тот же способ, что на сервере, worker/msg.ts tgToPhone) ----
async function tgSendPage(phone, name, text, photo) {
  const M = window.rootScope.managers; let id = 0;
  try {
    try { const r = await M.apiManager.invokeApi('contacts.importContacts', { contacts: [{ _: 'inputPhoneContact', client_id: String(Date.now()), phone, first_name: name || 'Собственник', last_name: '' }] });
      if (r && r.users && M.appUsersManager.saveApiUsers) await M.appUsersManager.saveApiUsers(r.users);
      id = r && r.imported && r.imported[0] ? r.imported[0].user_id : 0; }
    catch (e) { id = await M.appUsersManager.importContact(name || 'Собственник', '', phone).catch(() => 0); }
    if (!id) return 'NOUSER: номера нет в Telegram';
    let file = null;
    if (photo) { try { file = new File([Uint8Array.from(atob(photo), c => c.charCodeAt(0))], 'photo.jpg', { type: 'image/jpeg' }); } catch (e) { /* без фото */ } }
    if (file) { try { if (text.length > 1000) await M.appMessagesManager.sendFile({ peerId: Number(id), file, isMedia: true });
      else { await M.appMessagesManager.sendFile({ peerId: Number(id), file, caption: text, isMedia: true }); return ''; } }
      catch (e) { if (/FLOOD|SPAM|RESTRICTED/.test(String(e && (e.type || e.message)))) throw e; } }
    await M.appMessagesManager.sendText({ peerId: Number(id), text });
    return '';
  } catch (e) { const t = String((e && (e.type || e.message)) || e || 'ошибка'); return /FLOOD|SPAM|RESTRICTED/.test(t) ? 'FLOOD: ' + t : t; }
}
async function tgReadPage(phone) {
  const M = window.rootScope.managers, digits = phone.replace(/\D/g, ''); let id = 0;
  try {
    try { const x = await M.apiManager.invokeApi('contacts.resolvePhone', { phone: digits });
      if (x && x.users && M.appUsersManager.saveApiUsers) await M.appUsersManager.saveApiUsers(x.users);
      id = x && x.peer && x.peer.user_id ? x.peer.user_id : (x && x.users && x.users[0] ? x.users[0].id : 0); }
    catch (e) { const t = String(e && (e.type || e.message)); if (/AUTH_KEY|SESSION_REVOKED|FLOOD/.test(t)) return { e: t }; }
    if (!id) return { e: 'NOUSER: нет переписки в Telegram' };
    const peerId = Number(id), h = await M.appMessagesManager.getHistory({ peerId, limit: 30 }), out = [];
    for (const mid of (h.history || []).slice(0, 30)) { const m = await M.appMessagesManager.getMessageByPeer(peerId, mid); if (!m || m._ === 'messageService') continue;
      const t = String(m.message || '').trim() || (m.media ? (m.media._ === 'messageMediaPhoto' ? '[фото]' : '[файл]') : ''); if (!t) continue;
      out.push({ who: m.pFlags && m.pFlags.out ? 'me' : 'owner', text: t.slice(0, 1000), at: new Date((m.date || 0) * 1000).toISOString() }); }
    return { msgs: out.sort((a, b) => a.at < b.at ? -1 : 1) };
  } catch (e) { return { e: String((e && (e.type || e.message)) || e || 'ошибка') }; }
}

// ---- WhatsApp Web: send?phone=&text= открывает чат с готовым текстом; фото — вставкой (paste) отдельным сообщением перед текстом ----
async function waOpenPage() {
  for (let i = 0; i < 45; i++) {
    const dlg = document.querySelector('[role="dialog"]'), t = dlg ? dlg.innerText || '' : '';
    if (/недействител|invalid|не зарегистрирован|isn.t on WhatsApp/i.test(t)) return 'bad';
    const box = document.querySelector('#main footer div[contenteditable="true"]');
    if (box) return 'ok';
    await new Promise(s => setTimeout(s, 1000));
  }
  return 'wait';
}
async function waSendPage(photo) {
  const sleep = ms => new Promise(s => setTimeout(s, ms));
  const sendBtn = () => document.querySelector('#main footer button[aria-label="Отправить"], #main footer button[aria-label="Send"], #main footer span[data-icon="send"], #main footer span[data-icon="wds-ic-send-filled"]');
  const box = () => document.querySelector('#main footer div[contenteditable="true"]');
  const count = () => document.querySelectorAll('#main div.message-out').length;
  const before = count();
  if (photo) {   // фото: вставка картинки → окно предпросмотра → «Отправить»; не вышло — только текст
    try {
      const blob = new Blob([Uint8Array.from(atob(photo), c => c.charCodeAt(0))], { type: 'image/jpeg' });
      if (blob.size) {
        const dt = new DataTransfer(); dt.items.add(new File([blob], 'photo.jpg', { type: 'image/jpeg' }));
        const text = box().innerText; box().focus();
        box().dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        let b = null; for (let i = 0; i < 12 && !b; i++) { await sleep(700); b = document.querySelector('div[role="button"][aria-label="Отправить"], div[role="button"][aria-label="Send"], span[data-icon="wds-ic-send-filled"], span[data-icon="send"]'); if (b && b.closest('footer')) b = null; }
        if (b) { (b.closest('[role="button"], button') || b).click(); await sleep(4000); }
        if (box() && !box().innerText.trim() && text) return 'lost';   // текст пропал из поля — перезапустим с текстом
      }
    } catch (e) { /* без фото */ }
  }
  const b = sendBtn(); if (!b) return 'nobtn';
  (b.closest('button') || b).click();
  for (let i = 0; i < 10; i++) { await sleep(800); if (count() > before && !(box()?.innerText || '').trim()) return ''; }
  return (box()?.innerText || '').trim().length > 3 ? 'сообщение не ушло' : '';
}
async function waReadPage() {
  const sleep = ms => new Promise(s => setTimeout(s, ms));
  for (let i = 0; i < 20 && !document.querySelector('#main div.message-in, #main div.message-out'); i++) await sleep(500);
  await sleep(1500);
  return [...document.querySelectorAll('#main div.message-in, #main div.message-out')].slice(-30).map(e => {
    const c = e.querySelector('[data-pre-plain-text]'), t = e.querySelector('span.selectable-text, .copyable-text span');
    return { out: e.classList.contains('message-out'), pre: c?.getAttribute('data-pre-plain-text') || '', t: String(t?.innerText || '').trim(), media: !!e.querySelector('img, video') };
  });
}
// «[15:30, 03.11.2026] Имя: » → время ISO (браузер агента — в его часовом поясе, время из строки — местное)
function waTimeLocal(pre) {
  const m = /\[(\d{1,2}):(\d{2})(?:\s*([AP]M))?,\s*(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})\]/i.exec(pre || '');
  if (!m) return new Date().toISOString();
  let h = +m[1]; if (m[3]) h = h % 12 + (/p/i.test(m[3]) ? 12 : 0);
  const a = +m[4], b = +m[5], c = +m[6], [y, mo, d] = a > 999 ? [a, b, c] : pre.includes('/') ? [c, a, b] : [c, b, a];
  return new Date(y < 100 ? 2000 + y : y, mo - 1, d, h, +m[2]).toISOString();
}
async function waGo(tabId, phone, text) {
  const d = phone.replace(/\D/g, '');
  await chrome.tabs.update(tabId, { url: `https://web.whatsapp.com/send?phone=${d}${text ? `&text=${encodeURIComponent(text)}` : ''}` });
  await sleepS(1500); await tabLoaded(tabId);
  const st = await ready('wa', tabId, 60000);
  if (st !== 'ok') return st === 'auth' ? 'AUTH: войдите в WhatsApp Web в этом браузере' : 'NET: WhatsApp не загрузился';
  const o = await run(tabId, waOpenPage);
  return o === 'bad' ? 'NOUSER: номера нет в WhatsApp' : o === 'ok' ? '' : 'чат не открылся';
}

// ---- MAX: поиск по номеру → ровно один результат → вложение (вставкой) + текст; чтение пузырей (как worker/msg.ts maxToPhone / maxReadPhone) ----
async function maxFindPage(phone) {
  const sleep = ms => new Promise(s => setTimeout(s, ms));
  const all = [...document.querySelectorAll('button, a, [role="tab"]')].find(b => /^Все$/.test((b.innerText || '').trim()));
  if (all) { all.click(); await sleep(800); }
  const s = document.querySelector('input[placeholder="Найти"], input[placeholder="Найти чат или канал"], input[placeholder^="Поиск"]');
  if (!s) return 'nosearch';
  const set = v => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(s, v); s.dispatchEvent(new Event('input', { bubbles: true })); };
  s.focus(); set(''); await sleep(300); set(phone); await sleep(3500);
  const cells = document.querySelectorAll('.scrollable .item button.cell');
  if (cells.length !== 1) { set(''); return cells.length ? 'many' : 'none'; }
  cells[0].click(); await sleep(3000); set('');
  return 'ok';
}
async function maxSendPage(text, photo) {
  const sleep = ms => new Promise(s => setTimeout(s, ms));
  const box = document.querySelector('main div.contenteditable, div.contenteditable[data-placeholder="Сообщение"], main [contenteditable="true"]');
  if (!box) return 'в этот чат нельзя писать';
  const n0 = document.querySelectorAll('main .item[data-index]').length;
  const type = el => { el.focus(); const ls = String(text).split('\n'); ls.forEach((l, i) => { if (i) document.execCommand('insertLineBreak'); if (l) document.execCommand('insertText', false, l); }); };
  const enter = el => el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
  let target = box;
  if (photo) {
    try {
      const blob = new Blob([Uint8Array.from(atob(photo), c => c.charCodeAt(0))], { type: 'image/jpeg' });
      if (blob.size) { const dt = new DataTransfer(); dt.items.add(new File([blob], 'photo.jpg', { type: 'image/jpeg' })); box.focus();
        box.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); await sleep(2500);
        target = document.querySelector('[role="dialog"] div.contenteditable, [role="dialog"] [contenteditable="true"]') || box; }
    } catch (e) { /* без фото */ }
  }
  type(target); await sleep(400);
  const btn = (target.closest('[role="dialog"]') || document.querySelector('main') || document).querySelector('button[aria-label*="Отправить"], button[title*="Отправить"]');
  if (btn) btn.click(); else enter(target);
  for (let i = 0; i < 10; i++) { await sleep(700); if (document.querySelectorAll('main .item[data-index]').length > n0) return ''; }
  return 'сообщение не появилось в чате';
}
function maxReadPage() {
  const main = document.querySelector('main')?.getBoundingClientRect(), mid = main ? main.left + main.width / 2 : innerWidth / 2;
  return [...document.querySelectorAll('main .item[data-index]')].slice(-30).map(e => {
    const b = e.querySelector('.bubble'); if (!b) return null;
    const cls = String(e.className || '') + ' ' + String(b.className || ''), r = b.getBoundingClientRect();
    const own = /(^|[\s_-])(out|outgoing|own|self|mine|isOwn|my)([\s_-]|$)/i.test(cls) || (!/(^|[\s_-])(in|incoming)([\s_-]|$)/i.test(cls) && r.left + r.width / 2 > mid + 20);
    const full = String(b.innerText || '').trim(), hm = /(\d{1,2}):(\d{2})\s*$/.exec(full);
    let at = new Date(); if (hm) { at.setHours(+hm[1], +hm[2], 0, 0); if (at.getTime() > Date.now() + 5 * 60e3) at = new Date(at.getTime() - 864e5); }
    return { who: own ? 'me' : 'owner', text: full.replace(/\s*(ред\.\s*)?\d{1,2}:\d{2}\s*$/, '').trim().slice(0, 1000), at: at.toISOString() };
  }).filter(x => x && x.text);
}
async function maxOpen(phone) {
  const tab = await msgTab('max');
  const st = await ready('max', tab.id);
  if (st !== 'ok') return { e: st === 'auth' ? 'AUTH: войдите в MAX (web.max.ru) в этом браузере' : 'NET: MAX не загрузился' };
  const f = await run(tab.id, maxFindPage, [phone]);
  return f === 'ok' ? { tab } : { e: f === 'many' ? 'NOUSER: по номеру нашлось несколько чатов' : f === 'none' ? 'NOUSER: номера нет в MAX' : 'NET: нет поиска в MAX' };
}

// фото к сообщению качает расширение (у WhatsApp / MAX / Telegram строгие правила страницы — оттуда наше хранилище не открыть),
// в страницу уходит base64; страница сама собирает файл
async function photoB64(u) {
  if (!u || !/^https:\/\/([a-z0-9-]+\.)*supabase\.co\//.test(u)) return '';
  try { const r = await fetch(u); if (!r.ok) return ''; const b = new Uint8Array(await r.arrayBuffer()); if (b.length > 4e6) return '';
    let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000)); return btoa(s); } catch { return ''; }
}

// ---- одно сообщение ----
async function sendOne(svc, it) {
  if (!MSGR[svc]) return { ok: false, error: 'неизвестный мессенджер' };
  const pic = await photoB64(it.photo);
  if (svc === 'max') { const o = await maxOpen(it.phone); if (o.e) return { ok: false, error: o.e };
    const e = await run(o.tab.id, maxSendPage, [it.text, pic]); return e ? { ok: false, error: String(e) } : { ok: true }; }
  const tab = await msgTab(svc);
  if (svc === 'tg') {
    const st = await ready('tg', tab.id);
    if (st !== 'ok') return { ok: false, error: st === 'auth' ? 'AUTH: войдите в Telegram Web в этом браузере' : 'NET: Telegram не загрузился' };
    const e = await run(tab.id, tgSendPage, [it.phone, it.name || '', it.text, pic]);
    return e ? { ok: false, error: typeof e === 'string' ? e : 'ошибка' } : { ok: true };
  }
  let e = await waGo(tab.id, it.phone, it.text);
  if (e) return { ok: false, error: e };
  let r = await run(tab.id, waSendPage, [pic]);
  if (r === 'lost') { e = await waGo(tab.id, it.phone, it.text); if (e) return { ok: false, error: e }; r = await run(tab.id, waSendPage, ['']); }
  return r ? { ok: false, error: r === 'nobtn' ? 'нет кнопки «Отправить»' : String(r) } : { ok: true };
}
async function readOne(svc, phone) {
  if (svc === 'max') { const o = await maxOpen(phone); if (o.e) return { ok: false, error: o.e };
    const msgs = await run(o.tab.id, maxReadPage) || []; return msgs.length ? { ok: true, msgs } : { ok: false, error: 'NET: история чата MAX не загрузилась' }; }
  const tab = await msgTab(svc);
  if (svc === 'tg') {
    const st = await ready('tg', tab.id);
    if (st !== 'ok') return { ok: false, error: st === 'auth' ? 'AUTH: вход в Telegram закончился' : 'NET: Telegram не загрузился' };
    const r = await run(tab.id, tgReadPage, [phone]);
    if (r?.e) return { ok: false, error: /^NOUSER/.test(r.e) ? r.e : /AUTH_KEY|SESSION_REVOKED/.test(r.e) ? 'AUTH: ' + r.e : /FLOOD/.test(r.e) ? 'FLOOD: ' + r.e : 'NET: ' + r.e.slice(0, 160) };
    return { ok: true, msgs: r?.msgs || [] };
  }
  const e = await waGo(tab.id, phone, '');
  if (e) return { ok: false, error: /^(AUTH|NOUSER)/.test(e) ? e : 'NET: ' + e };
  const raw = await run(tab.id, waReadPage) || [];
  const msgs = raw.map(x => ({ who: x.out ? 'me' : 'owner', text: (x.t || (x.media ? '[файл]' : '')).slice(0, 1000), at: waTimeLocal(x.pre) })).filter(m => m.text);
  return msgs.length ? { ok: true, msgs } : { ok: false, error: 'NET: история чата WhatsApp не загрузилась' };
}

// ---- такт (будильник раз в 30 с): одно сообщение задания или опрос сервера; работа — под замком ----
async function sendTick(force = false) {
  if (!(await sendOn())) return;
  const { sendBusy = 0 } = await chrome.storage.session.get('sendBusy');
  if (Date.now() - sendBusy < 4 * 60e3) return;
  await chrome.storage.session.set({ sendBusy: Date.now() });
  try {
    let { sendJob: j = null, sendPollAt = 0, sendBack = 0 } = await chrome.storage.local.get(['sendJob', 'sendPollAt', 'sendBack']);
    if (j && j.i < j.items.length) {
      if (Date.now() < j.next) return;
      const it = j.items[j.i], r = await sendOne(j.svc, it);
      const s = await autoApi('own_ext_sent', { id: j.id, num: it.num, ok: r.ok, error: r.error || null });
      j.i++; j.fails = r.ok || /^NOUSER/.test(r.error || '') ? 0 : (j.fails || 0) + 1; j.last = { num: it.num, ok: r.ok, error: r.error || null };
      let stop = null;
      if (/^AUTH/.test(r.error || '')) stop = ['error', `Вход в ${MSGR[j.svc]?.title || j.svc} в браузере закончился — войдите снова`];
      else if (/^FLOOD/.test(r.error || '')) stop = ['stopped', 'Мессенджер ограничил отправку — продолжите завтра'];
      else if (j.fails >= 3) stop = ['error', 'Три ошибки подряд — отправка остановлена'];
      else if (s?.stop) stop = ['stopped', 'Остановлено'];
      if (stop || j.i >= j.items.length) { await autoApi('own_ext_done', { id: j.id, status: stop ? stop[0] : 'done', error: stop ? stop[1] : null }); j = null; }
      else j.next = Date.now() + 25000 + Math.random() * 35000;   // пауза 25–60 с, как у сервера
      await chrome.storage.local.set({ sendJob: j });
      return;
    }
    if (!force && Date.now() - sendPollAt < 55000) return;
    if (!force && sendBack > Date.now()) return;
    const svcs = await loginStates();
    const p = await autoApi('own_ext_poll', { ver: chrome.runtime.getManifest().version, svcs, ua: navigator.userAgent.slice(0, 120) });
    await chrome.storage.local.set({ sendPollAt: Date.now(), sendState: { at: Date.now(), svcs, error: p.error || null, message: p.message || null } });
    if (p.error) { if (['need_pro', 'no_auth', 'kicked'].includes(p.error)) await chrome.storage.local.set({ sendBack: Date.now() + 30 * 60e3 }); return; }
    if (p.job?.items?.length) { await chrome.storage.local.set({ sendJob: { ...p.job, i: 0, next: 0, fails: 0 } }); return sendTickNow(); }
    if (p.checks?.items?.length && MSGR[p.checks.svc]) {
      const items = [];
      for (const c of p.checks.items) { const r = await readOne(p.checks.svc, c.phone); items.push({ num: c.num, ...r }); await chrome.storage.session.set({ sendBusy: Date.now() }); await sleepS(2500); }
      await autoApi('own_ext_read', { svc: p.checks.svc, items });
    }
  } finally { await chrome.storage.session.set({ sendBusy: 0 }); }
}
const sendTickNow = () => setTimeout(() => sendTick(false), 200);
chrome.alarms.create('daSend', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'daSend') sendTick(false); });
chrome.runtime.onStartup.addListener(() => sendTick(true));
chrome.runtime.onInstalled.addListener(() => sendTick(true));
