(async () => {
  const s = await DA.getSettings();
  for (const [k, v] of Object.entries(s)) {
    const e = document.getElementById(k); if (!e) continue;
    if (e.type === 'checkbox') e.checked = !!v; else e.value = v;
  }
  document.getElementById('save').onclick = async () => {
    const out = {};
    for (const k of Object.keys(DA.DEFAULTS)) {
      const e = document.getElementById(k); if (!e) continue;
      out[k] = e.type === 'checkbox' ? e.checked : e.type === 'number' ? (+e.value || 0) : e.value;
    }
    out.maxPhotos = Math.min(30, Math.max(1, out.maxPhotos || 30));
    out.batchSize = +out.batchSize || 10;
    out.avitoPause = Math.max(20, out.avitoPause || 30);
    await chrome.storage.local.set({ settings: out });
    document.getElementById('ok').textContent = 'Сохранено ✓';
    setTimeout(() => (document.getElementById('ok').textContent = ''), 2000);
  };
})();
